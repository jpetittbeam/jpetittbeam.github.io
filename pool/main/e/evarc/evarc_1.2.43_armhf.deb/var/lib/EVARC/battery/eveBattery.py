#!/usr/bin/python3
import minimalmodbus
import os
import can
import cantools
import traceback
import time
import threading

# Modbus Registers [register, number_of_decimals, functioncode=3, signed], opcode=0 (normal)
# Modbus Registers [register, number_of_decimals=0, functioncode=3, signed], opcode=1 (bit-array)
# Modbus Registers [register, functionalcode=3, signed], opeocde=2 (multi-reg)
READ_REGISTERS = {
    'current': [[0, 2, 3, True], 0],  ## unit is 10mA. 1A should show as 100 so num of dec=2
    'voltage': [[1, 2, 3, False], 0],
    'SOC': [[2, 0, 3, False], 0],
    'SOH': [[3, 0, 3, False], 0],
    'remaining_capacity': [[4, 2, 3, False], 0],
    'full_capacity': [[5, 2, 3, False], 0],
    'design_capacity': [[6, 2, 3, False], 0],
    'batt_cycles': [[7, 0, 3, False], 0],
    'Warning_Flag': [[9, 0, 3, False], 1, [
        'cell_OV_warning',
        'cell_UV_warning',
        'pack_OV_warning',
        'pack_UV_warning',
        'charging_OC_warning',
        'discharging_OC_warning',
        'none',
        'none',
        'charging_high_temp_warning',
        'discharging_high_temp_warning',
        'charging_low_temp_warning',
        'discharging_low_temp_warning',
        'env_high_temp_warning',
        'env_low_temp_warning',
        'FET_high_temp_warning',
        'SOC_low_warning'
    ]],
    'Protection_Flag': [[10, 0, 3, False], 1, [
        'cell_OV_protection',
        'cell_UV_protection',
        'pack_OV_protection',
        'pack_UV_protection',
        'charging_OC_protection',
        'discharging_OC_protection',
        'short_circuit_protection',
        'charger_OV_protection',
        'charging_high_temp_protection',
        'discharging_high_temp_protection',
        'charging_low_temp_protection',
        'discharging_low_temp_protection',
        'FET_high_temp_protection',
        'env_high_temp_protection',
        'env_low_temp_protection',
        'none'
    ]],
    'Status_Flag': [[11, 0, 3, False], 1, [
        'charging_FET_fault',
        'discharging_FET_fault',
        'temp_sensor_fault',
        'none',
        'cell_fault',
        'comms_fault',
        'none',
        'none',
        'none', #'charging_flag',
        'none', #'discharging_flag',
        'none', #'charging_FET_flag',
        'none', #'discharging_FET_flag',
        'charging_limiter_flag',
        'none',
        'charger_inversed',
        'none'
    ]],
    'Balance_Flag': [[12, 0, 3, False], 1, [
        'cell_1_bal'
        'cell_2_bal',
        'cell_3_bal',
        'cell_4_bal',
        'cell_5_bal',
        'cell_6_bal',
        'cell_7_bal',
        'cell_8_bal',
        'cell_9_bal',
        'cell_10_bal',
        'cell_11_bal',
        'cell_12_bal',
        'cell_13_bal',
        'cell_14_bal',
        'cell_15_bal',
        'cell_16_bal',
    ]],
    'cell_V_1': [[15, 3, 3, False], 0],
    'cell_V_2': [[16, 3, 3, False], 0],
    'cell_V_3': [[17, 3, 3, False], 0],
    'cell_V_4': [[18, 3, 3, False], 0],
    'cell_V_5': [[19, 3, 3, False], 0],
    'cell_V_6': [[20, 3, 3, False], 0],
    'cell_V_7': [[21, 3, 3, False], 0],
    'cell_V_8': [[22, 3, 3, False], 0],
    'cell_V_9': [[23, 3, 3, False], 0],
    'cell_V_10': [[24, 3, 3, False], 0],
    'cell_V_11': [[25, 3, 3, False], 0],
    'cell_V_12': [[26, 3, 3, False], 0],
    'cell_V_13': [[27, 3, 3, False], 0],
    'cell_V_14': [[28, 3, 3, False], 0],
    'cell_V_15': [[29, 3, 3, False], 0],
    'cell_V_16': [[30, 3, 3, False], 0],
    'cell_T_1': [[31, 1, 3, True], 0],
    'cell_T_2': [[32, 1, 3, True], 0],
    'cell_T_3': [[33, 1, 3, True], 0],
    'cell_T_4': [[34, 1, 3, True], 0],
    'MOSFET_T': [[35, 1, 3, True], 0],
    'Environment_T': [[36, 1, 3, True], 0],
    'Total_Discharge_Ah': [[40, 3, False], 2],  ## .01Ah
    'Total_Discharge_kWh': [[42, 3, False], 2],  ## Wh
}

# Modbus Write Registers [register, number_of_decimals, signed, value]
WRITE_REGISTERS = {
    'pack_OV_alarm': [60, 3, False, 59.2],
    'pack_OV_protection': [61, 3, False, 58.08],
    'pack_OV_release': [62, 3, False, 54.0],
    'pack_OV_delay_time': [63, 1, False, 1.0],  # comes in .1S
    'cell_OV_alarm': [64, 3, False, 3.5],
    'cell_OV_protection': [65, 3, False, 3.6],
    'cell_OV_release': [66, 3, False, 3.42],
    'cell_OV_delay_time': [67, 1, False, 1.0],  # comes in .1S
    'pack_UV_alarm': [68, 3, False, 44.8],
    'pack_UV_protection': [69, 3, False, 43.2],
    'pack_UV_release': [70, 3, False, 48.0],
    'pack_UV_delay_time': [71, 1, False, 1.0],  # comes in .1S
    'cell_UV_alarm': [72, 3, False, 2.8],
    'cell_UV_protection': [73, 3, False, 2.7],
    'cell_UV_release': [74, 3, False, 2.9],
    'cell_UV_delay_time': [75, 1, False, 1.0],  # comes in .1S
    'charging_OC_alarm': [76, 0, False, 40],
    'charging_OC_protection': [77, 0, False, 40],
    'charging_OC_delay_time': [78, 1, False, 1.0],
    'discharge_OC_alarm': [79, 0, False, 40],  # comes in .1S
    'discharge_OC_protection': [80, 0, False, 40],
    'discharge_OC_delay_time': [81, 1, False, 1.0],
    'discharge_OC2_protection': [82, 0, False, 50],
    'discharge_OC2_delay_time': [83, 0, False, 4],  # comes in .025S
    'charging_OT_alarm': [84, 1, False, 55.0],
    'charging_OT_protection': [85, 1, False, 60.0],
    'charging_OT_release': [86, 1, False, 50.0],
    'discharging_OT_alarm': [87, 1, False, 55.0],
    'discharging_OT_protection': [88, 1, False, 60.0],
    'discharging_OT_release': [89, 1, False, 55.0],
    'charging_UT_alarm': [90, 1, True, 4.0],
    'charging_UT_protection': [91, 1, True, 2.0],
    'charging_UT_release': [92, 1, True, 4.0],
    'discharging_UT_alarm': [93, 1, True, 4.0],
    'discharging_UT_protection': [94, 1, True, 2.0],
    'discharging_UT_release': [95, 1, True, 4.0],
    'MOSFET_OT_alarm': [96, 1, False, 90.0],
    'MOSFET_OT_protection': [97, 1, False, 110.0],
    'MOSFET_OT_release': [98, 1, False, 85.0],
    'Env_OT_alarm': [99, 1, False, 55.0],
    'Env_OT_protection': [100, 1, False, 60.0],
    'Env_OT_release': [101, 1, False, 55.0],
    'Env_UT_alarm': [102, 1, True, -10.0],
    'Env_UV_protection': [103, 1, True, -15.0],
    'Env_UV_release': [104, 1, True, -10.0],
    'Balance_start_V': [105, 3, False, 3.4],
    'Balance_start_delta_V': [106, 0, False, 30],
    'Pack_full_charge_V': [107, 3, False, 54.3],
    'Pack_full_charge_A': [108, 3, False, 5.0],
    'Cell_Sleep_V': [109, 3, False, 3.1],
    'Cell_Sleep_Delay_Time': [110, 0, False, 1],  # minutes
    'Short_Circuit_Delay_Time': [111, 0, False, 12],  # uS
    'SOC_alarm_threshold': [112, 0, False, 20],
    'charging_OC2_protection': [113, 0, False, 50],
    'charging_OC2_delay_time': [114, 0, False, 4]
}

OUTPUT = [
    [3, "self.voltage[module]"],
    [4, "self.max_voltage[module]"],
    [5, "self.min_voltage[module]"],
    [7, "self.current[module]"],
    [8, "self.SOC[module]"],
    [9, "self.SOH[module]"],
    [11, "self.Status_Flag[module]"],
    [12, "self.Warning_Flag[module]"],
    [13, "self.Protection_Flag[module]"],
    [15, "self.max_temp[module]"],
    [16, "self.min_temp[module]"],
    [17, "self.Environment_T[module]"],
    [19, "('charging' if (self.Status_Flag[module] is not None and "
         +"(self.Status_Flag[module] & 0x100)) else "
         +"('discharg' if (self.Status_Flag[module] is not None and "
         +"(self.Status_Flag[module] & 0x200)) else '        '))"],
    [20, "'      ' if self.Status_Flag[module] is None else ('closed' if self.Status_Flag[module] & 0x400 else 'open  ')"],
    [21, "'      ' if self.Status_Flag[module] is None else ('closed' if self.Status_Flag[module] & 0x800 else 'open  ')"],
    [23, "self.batt_cycles[module]"]
]


BATTERY_PACK_ADDRESSES = range(8)

class Battery():
    def __init__(self, db, log, spn, conf):
        self.arc = conf['arc']
        self.dcfc_iface = conf['dcfc_iface']
        self.dcfc_id = conf['dcfc_id']
        self.port = conf['battery_iface']
        self.num_batteries = conf['num_batteries']
        self.lock = threading.Lock()
        self.type = 'EVE'
        self.batt_id = [i for i in range(1,9)]
        self.stop = False
        self.runner = None
        self.last_write = [time.time()] * 8
        self.write_interval = 15
        self.battery_count = 0
        self.missing = [0] * 8
        self.outputlen = 26
        self.rowoffset = 0
        for k in READ_REGISTERS.keys():
            exec("self.%s = [None]*8" % (k))
        self.min_voltage = [None] * 8
        self.max_voltage = [None] * 8
        self.min_temp = [None] * 8
        self.max_temp = [None] * 8
        self.faults = [None] * 8
        self.contactor = [None] * 8

        self.NON_RECOVERABLE_FAULTS = 0x7
        self.HEADER = "          " + \
"BATT1:      BATT2:      BATT3:      BATT4:      BATT5:      BATT6:      BATT7:      BATT8:                       " + \
                      (str(self.dcfc_id) + " DCFC" if self.dcfc_id is not None else " %d EVE" % (
                      self.num_batteries)) + """
---------+-----------+-----------+-----------+-----------+-----------+-----------+-----------+-----------                  ------
Volts:                                                                                                   
  max:                                                                                                   
  min:                                                                                                   

Current:                                                                                                 
SOC:                                                                                                     
SOH:                                                                                                     

Status:                                                                                                  
Warning:                                                                                                 
Protect:                                                                                                 
Temperatures:                                                                                                 
  max:                                                                                                   
  min:                                                                                                   
  env:                                                                                                   
FETs:
 state:                                                                                                   
  chrg:                                                                                                 
 disch:                                                                                                   

Cycles:                                                                                                   """
        self.db = db
        self.db.create("CREATE TABLE battery (id INTEGER PRIMARY KEY, timestamp" \
                       + " REAL, module INTEGER, n INTEGER, current REAL," \
                       + " voltage REAL, soc REAL, soh REAL, remaining_capacity" \
                       + " INTEGER, full_capacity INTEGER, design_capacity INTEGER," \
                       + " batt_cycles INTEGER, warning_flag INTEGER, protection_flag" \
                       + " INTEGER, status_flag INTEGER, balancing_status INTEGER," \
                       + " cell_v_1 REAL, cell_v_2 REAL, cell_v_3 REAL, cell_v_4 REAL," \
                       + " cell_v_5 REAL, cell_v_6 REAL, cell_v_7 REAL, cell_v_8 REAL," \
                       + " cell_v_9 REAL, cell_v_10 REAL, cell_v_11 REAL, cell_v_12" \
                       + " REAL, cell_v_13 REAL, cell_v_14 REAL, cell_v_15 REAL," \
                       + " cell_v_16 REAL, cell_t_1 REAL, cell_t_2 REAL, cell_t_3 REAL," \
                       + " cell_t_4 REAL, mosfet_t REAL, environment_t REAL," \
                       + " total_discharge_ah REAL, total_discharge_kwh INTEGER);")
        self.log = log
        self.spn = spn

    def getData(self, module):
        """collect data from batteries and save it in class"""
        # Check if battery is missing
        if (time.time() - self.missing[module]) > 60:
            try:
                for k, v in READ_REGISTERS.items():
                    value = self.readRegister(module, v[1] == 2, *v[0])
                    exec("self.%s[%s] = %s" % (k, module, (
                        (value & 0x7FFF) if k == "Protection_Flag" else value)))
                self.missing[module] = 0
            except Exception:
                for k in READ_REGISTERS.keys():
                    exec("self.%s[%s] = None" % (k, module))
                self.missing[module] = time.time()
                return False
        self.Protection_Flag[module] = (self.Protection_Flag[module] & 0x7FFF if self.Protection_Flag[module] is not None else None)
        Vs = list(filter((None).__ne__, [
            self.cell_V_1[module], self.cell_V_2[module],
            self.cell_V_3[module], self.cell_V_4[module],
            self.cell_V_5[module], self.cell_V_6[module],
            self.cell_V_7[module], self.cell_V_8[module],
            self.cell_V_9[module], self.cell_V_10[module],
            self.cell_V_11[module], self.cell_V_12[module],
            self.cell_V_13[module], self.cell_V_14[module],
            self.cell_V_15[module], self.cell_V_16[module]]))
        self.min_voltage[module] = (None if Vs == [] else min([i for i in Vs if i is not None]))
        self.max_voltage[module] = (None if Vs == [] else max([i for i in Vs if i is not None]))
        Ts = list(filter((None).__ne__, [
            self.cell_T_1[module], self.cell_T_2[module],
            self.cell_T_3[module], self.cell_T_4[module]]))
        self.min_temp[module] = (None if Ts == [] else min([i for i in Ts if i is not None]))
        self.max_temp[module] = (None if Ts == [] else max([i for i in Ts if i is not None]))
        if None not in [self.Protection_Flag[module], self.Warning_Flag[module],
                        self.Status_Flag[module]]:
            self.faults[module] = (
                    self.Protection_Flag[module] * (1 << 32) \
                    + self.Warning_Flag[module] * (1 << 16) \
                    + self.Status_Flag[module] & 0xE0FF)
        if self.Status_Flag[module] is not None:
            self.contactor[module] = 1 if (self.Status_Flag[module] & 0xC00) == 0xC00 else 0
            self.battery_count = sum([i for i in self.contactor if i is not None])
        else:
            self.contactor[module] = None
        self.spn += 1
        return True

    def saveData(self, module, group):
        """write collected data to the database"""
        t = time.time()
        data = (t, module, group,
                self.current[module], self.voltage[module],
                self.SOC[module],
                self.SOH[module],
                self.remaining_capacity[module],
                self.full_capacity[module],
                self.design_capacity[module],
                self.batt_cycles[module],
                self.Warning_Flag[module],
                self.Protection_Flag[module],
                self.Status_Flag[module],
                self.Balance_Flag[module],
                self.cell_V_1[module], self.cell_V_2[module],
                self.cell_V_3[module],
                self.cell_V_4[module], self.cell_V_5[module],
                self.cell_V_6[module],
                self.cell_V_7[module], self.cell_V_8[module],
                self.cell_V_9[module],
                self.cell_V_10[module], self.cell_V_11[module],
                self.cell_V_12[module],
                self.cell_V_13[module], self.cell_V_14[module],
                self.cell_V_15[module],
                self.cell_V_16[module], self.cell_T_1[module],
                self.cell_T_2[module],
                self.cell_T_3[module], self.cell_T_4[module],
                self.MOSFET_T[module],
                self.Environment_T[module],
                self.Total_Discharge_Ah[module],
                self.Total_Discharge_kWh[module])
        if None not in data and self.last_write[module] + self.write_interval < t:
            self.db.put(("INSERT INTO battery (timestamp, module, n, current," \
                         + " voltage, soc, soh, remaining_capacity, full_capacity," \
                         + " design_capacity, batt_cycles, warning_flag," \
                         + " protection_flag, status_flag, balancing_status," \
                         + " cell_v_1, cell_v_2 , cell_v_3, cell_v_4," \
                         + " cell_v_5, cell_v_6 , cell_v_7, cell_v_8," \
                         + " cell_v_9, cell_v_10, cell_v_11, cell_v_12," \
                         + " cell_v_13, cell_v_14, cell_v_15, cell_v_16," \
                         + " cell_t_1, cell_t_2, cell_t_3, cell_t_4," \
                         + " mosfet_t, environment_t, total_discharge_ah," \
                         + " total_discharge_kwh) VALUES (%f, %d, %d, %f," \
                         + " %f, %f, %f, %d, %d, %d, %d, %d, %d, %d, %d, %f, %f," \
                         + " %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f," \
                         + " %f, %f, %f, %f, %f, %f, %f, %f, %d);") % (data))
            self.last_write[module] = t

    def showData(self):
        """Writes collected data to outputfile"""
        ret_value = ""
        for module in range(8):
            for i in OUTPUT:
                v = eval(i[1])
                if v is not None:
                    ret_value += "\x1b[%d;%df%s" % (
                        i[0] + self.rowoffset,
                        11 + (module * 12),
                        v)
        ret_value += "\x1b[%d;%df%s" % (self.rowoffset + self.outputlen - 3, 129, self.spn)
        return ret_value + "\x1b8"

    def send_batt_results(self):
        """Send CAN data to System Controller"""
        self.log('error', 'battery', 'Ready to send CAN')
        bus = can.interface.Bus(self.dcfc_iface, bustype="socketcan")
        db = cantools.database.load_file(
            os.path.dirname(os.path.abspath(__file__)) + "/../dbc/DCFC_ARC_001.dbc")
        # Create CAN messages
        data = {"ARC_Number": self.arc,
                "Voltage": sum(
                    [self.voltage[i] for i in range(8) if self.contactor[i] and self.voltage[i] is not None]),
                "MinV_Connected": min([self.voltage[i] for i in range(8) if self.contactor[i] and self.voltage[i] is not None]),
                "Min_Voltage": min([i for i in self.voltage if i is not None]),
                "Max_Voltage": max([i for i in self.voltage if i is not None]),
                }
        msg = db.encode_message('DCFC_' + str(self.dcfc_id) + '_Voltage_Msg', data)
        self.log('error', 'battery', 'First ' + str([int(i) for i in msg]))
        bus.send(can.Message(arbitration_id=256 + self.dcfc_id, data=msg, is_extended_id=False))
        # Create CAN messages
        data = {"Batt_Count": sum([i for i in self.contactor if i is not None]),
                "Current": sum(
                    [self.current[i] for i in range(8) if self.current[i] is not None and self.contactor[i]]),
                "Min_Current": min([i for i in self.current if i is not None]),
                "Max_Current": max([i for i in self.current if i is not None]),
                "Fault_Count": sum([(1 if (i & 7) > 0 else 0) for i in self.Status_Flag if i is not None]),
                "Protect_Count": sum([i > 0 for i in self.Protection_Flag if i is not None]),
                }
        msg = db.encode_message('DCFC_' + str(self.dcfc_id) + '_Current_Msg', data)
        self.log('error', 'battery', 'Second ' + str([int(i) for i in msg]))
        bus.send(can.Message(arbitration_id=272 + self.dcfc_id, data=msg, is_extended_id=False))

    def getInvParams(self, summer):
        """Provides battery specific parameters for inverter configuration"""
        if summer:
            if self.battery_count > 6:
                return {"capacity": 800, "shutd_v": 51, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 51.5, "sl_on": 53.5}
            elif self.battery_count > 4:
                return {"capacity": 600, "shutd_v": 51, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 51.5, "sl_on": 53.8}
            elif self.battery_count > 3:
                return {"capacity": 400, "shutd_v": 51, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 51.5, "sl_on": 54}
            else:
                return {"capacity": 0, "shutd_v": 47, "restart_v": 53.6,
                        "low_bat": 47.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 59, "sl_on": 59.5}
        else:
            if self.battery_count > 6:
                return {"capacity": 800, "shutd_v": 51, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 51.5, "sl_on": 53.5}
            elif self.battery_count > 4:
                return {"capacity": 600, "shutd_v": 51, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 51.5, "sl_on": 53.8}
            elif self.battery_count > 3:
                return {"capacity": 400, "shutd_v": 51, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 51.5, "sl_on": 54}
            else:
                return {"capacity": 0, "shutd_v": 47, "restart_v": 53.6,
                        "low_bat": 47.5, "recov_v": 50, "charge_v": 54.5,
                        "sl_off": 59, "sl_on": 59.5}

    def getFaults(self):
        """decodes faults returns a list of fault strings"""
        faults = []
        for module in range(self.num_batteries):
            #self.log('warning', 'battery', "Fault checking: "+str(module))
            if self.Status_Flag[module] is not None and (
                    self.Status_Flag[module] & 0xf0ff):
                for bit in range(16):
                    if self.Status_Flag[module] & (1<<bit) and \
                       READ_REGISTERS['Status_Flag'][2][bit] != 'none':
                        faults.append("Battery " + str(module+1) + ": " +
                                              READ_REGISTERS['Status_Flag'][2][bit])
            if self.Warning_Flag[module]:
                for bit in range(16):
                    if self.Warning_Flag[module] & (1<<bit) and \
                       READ_REGISTERS['Warning_Flag'][2][bit] != 'none':
                        faults.append("Battery " + str(module+1) + ": " +
                                              READ_REGISTERS['Warning_Flag'][2][bit])
            if self.Protection_Flag[module]:
                for bit in range(16):
                    if self.Protection_Flag[module] & (1 << bit) and \
                            READ_REGISTERS['Protection_Flag'][2][bit] != 'none':
                        faults.append("Battery " + str(module+1) + ": " +
                                              READ_REGISTERS['Protection_Flag'][2][bit])
        return faults

    def getStatus(self, ignores=[]):
        """Report if any battery is in conditioning"""
        if len([i for i in self.contactor if i is not None]) < min(5,self.num_batteries):
            return ["Too few batteries"]
        else:
            for i in range(len(self.contactor)):
                if self.contactor[i] == 0 and i not in ignores:
                    return ["Open FETs"]
        return []

    def encourage(self):
        """Used with recovery to encourage batteries to close main contactor"""
        pass

    def setBusVCallback(self, func):
        """Set a callback function to callback for inverter bus voltage"""
        pass

    def sendHBBusVoltage(self):
        """start sending battery messages to the batteries to keep the bus alive"""
        raise NotImplementedError

    def sendShutdown(self, batt_id):
        """Shutdown the specified battery by battery_address"""
        pass

    def readRegister(self, module, big=False, *register):
        """read modbus register retry for several seconds"""
        repeat_count = 0
        ret_value = None
        incomplete = True
        self.lock.acquire()
        m = minimalmodbus.Instrument(self.port, module + 1)
        m.serial.baudrate = 9600
        while incomplete and repeat_count < 4:
            try:
                if big:
                    ret_value = m.read_long(*register)
                else:
                    ret_value = m.read_register(*register)
                incomplete = False
            except Exception:
                repeat_count += 1
        self.lock.release()
        return ret_value

    def start(self):
        """Launch a thread to collect, record and report the battery data"""
        self.stop = False
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()
        if self.dcfc_iface is not None:
            self.sender = threading.Thread(target=self.sendit, daemon=True)
            self.sender.start()

    def run(self):
        """Method that performs collect, record and report the battery data"""
        group = self.db.getBattIter()
        while not self.stop:
            group += 1
            try:
                for i in range(self.num_batteries):
                    if self.getData(i):
                        self.saveData(i,group)
            except Exception:
                self.log('critical', 'battery', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time()) + "\n")
                    f.write(traceback.format_exc() + "\n")
            time.sleep(2)
    def sendit(self):
        """Method that sends periodic messages"""
        time.sleep(10)
        t = time.time()
        while not self.stop:
            try:
                if time.time() > (t + 5):
                    self.send_batt_results()
                    t = time.time()
            except Exception:
                self.log('critical', 'battery', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time()) + "\n")
                    f.write(traceback.format_exc() + "\n")


def main():
    def error(device, level, msg):
        print("|%s| (%s) - %s" % (device, level, msg))

    class db:
        def create(self, s):
            pass

        def put(self, s):
            pass

    class spinner:
        def __init__(self, color):
            self.default = color
            self.i = -1
            self.j = -1
            self.v = ['o', 'O', '\x00\xb0']
            self.c = ["\x1b[38;5;160m", "\x1b[38;5;166m", "\x1b[38;5;220m",
                      "\x1b[38;5;47m", "\x1b[38;5;33m", "\x1b[38;5;93m"]

        def __add__(self, other):
            self.i = (self.i + 1) % len(self.v)
            self.j = (self.j + 1) % len(self.c)
            return self

        def __str__(self):
            return self.c[self.j] + self.v[self.i] + self.default

    b = Battery(db(), error, spinner("\x1b[38;5;33m"), {"num_batteries": 8, "dcfc_id": None,
                                                        "dcfc_iface": None, "battery_iface": "/dev/ttyM0"})
    b.fault_mask = True
    b.start()
    count = 20
    while True:
        if count >= 20:
            print("\x1bc\x1b[3J\x1b[1;1f" + b.HEADER + "\n\x1b7")
            count = 0
        count += 1
        print(b.showData(), flush=True)
        time.sleep(0.5)


if __name__ == '__main__':
    main()

