import io
import sys 
import os 
import types
import pytest
import datetime as dt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

def pytest_sessionstart(session):
    sys.modules["arcConfig"] = types.ModuleType("arcConfig")
    fake_modbus = types.ModuleType("pymodbus.client.sync")
    class modbus:
        def __init__(self, addr, port):
            _sent={32: 0}
        def read_holding_registers(self, reg):
            return [self._sent[reg]]
        def write_multiple_registers(self, reg, val):
            self._sent[reg] = val
    fake_modbus.ModbusSerialClient = modbus
    sys.modules["pymodbus.client.sync"] = fake_modbus

# FLAG FILE MOCK
@pytest.fixture
def fake_files(monkeypatch):
   """Fixture that mocks open(), os.path.*, and os.remove in-memory."""
   _files = {}
   
   def open_side_effect(file, mode='r', *args, **kwargs):
       if 'r' in mode:
           if file in _files:
               _files[file].seek(0)
               return _files[file]
           raise FileNotFoundError
       elif any([i in mode for i in ['w', 'a']]):
           _files[file] = io.StringIO()
           _files[file].close = lambda *a, **kw: None
           return _files[file]
       else:
           raise ValueError("Unsupported mode")
   
   monkeypatch.setattr("builtins.open", open_side_effect)
   monkeypatch.setattr("os.path.getsize", lambda path: _files[path].tell())
   monkeypatch.setattr("os.path.isfile", lambda path: path in _files.keys())
   monkeypatch.setattr("os.path.exists", lambda path: path in _files.keys())
   monkeypatch.setattr("os.remove", lambda path: _files.pop(path, None))

   return _files
 
@pytest.fixture
def fake_time(monkeypatch):
   """Fixture that mocks time.time and time.sleep"""
   # TIME MOCK
   _time = [100000]
   
   def time_now():
       return _time[0]

   def advance_time(seconds):
       _time[0] += seconds
       return _time[0]
   
   monkeypatch.setattr("time.time", time_now)
   monkeypatch.setattr("time.sleep", advance_time)

   return _time

@pytest.fixture
def fake_date(monkeypatch):
    """Fixture to mock datetime.datetime and datetime.datetime.now"""
    _date = []

    class fake_datetime:
        def __init__(self, *args):
            if len(args) > 1:
                self.year = args[0]
                self.month = args[1]
                self.day = args[2] if len(args) > 2 else 1
                self.hour = args[3] if len(args) > 3 else 1
                self.minute = args[4] if len(args) > 4 else 1
                self.second = args[5] if len(args) > 5 else 1
            else:
                self.year = args[0].year
                self.month = args[0].month
                self.day = args[0].day
                self.hour = args[0].hour
                self.minute = args[0].minute
                self.second = args[0].second

        def __sub__(self, other):
            self.day -= 1
            return self

        def __lt__(self, other):
            if self.year < other.year:
                return True
            if self.year == other.year:
                if self.month < other.month:
                    return True
                if self.month == other.month:
                    if self.day < other.day:
                        return True
                    if self.hour < other.hour:
                        return True
                    if self.minute < other.minute:
                        return True
                    if self.second < other.second:
                        return True
            return False

        @staticmethod
        def now():
            return fake_datetime(_date[0])

    _date.append(fake_datetime(2025, 1, 1, 12, 12, 12))
    monkeypatch.setattr("datetime.datetime", fake_datetime)

    return _date

@pytest.fixture
def fake_syscall(monkeypatch):
    _syscall = []

    def system(command):
        _syscall.append(command)
        return 0

    monkeypatch.setattr("os.system", system)

# COMPONENT MOCKS
@pytest.fixture
def fake_batt():
    class _batt():
        """
        Returns a function that creates a battery mock with default values,
        but allows overrides per test.
        """
        def __init__(self):
            self.NON_RECOVERABLE_FAULTS = 1
            self.batt_id = [None] * 5
            self.sstop = False
            self.soc = [None] * 5
            self.min_temp = [None] * 5
            self.max_temp = [None] * 5
            self.faults = [None] * 5
            self.voltage = [None] * 5 
            self.leader = None
            self.min_voltage = [None] * 5
            self.max_voltage = [None] * 5
            self.current = [None] * 5
            self.recovery = [None] * 5
            self.lf_role = [None] * 5
            self.contactor = [None] * 5
            self.type=None
            self._status = []
            self._result = False
            self._encourage_count = 0
            self._encourage_results = []
            self._recover_calls = set()
            self._shutdown = False
        def getStatus(self, i=[]):
            return [self._status[j] for j in i]
        def getFaults(self):
            return ["Battery 1 Fault"]
        def getInvParams(self, summer):
            return { 'charge_v': 57 }
        def encourage(self):
            # [([voltage], [contactor], [lf_role], leader),]
            results = [
                ([53, 53, 53, 51], [0, 0, 0, 1], ["Follower", "Follower", "Follower", "Leader"], 3),
                ([52, 52, 52, 51], [0, 0, 0, 1], ["Follower", "Follower", "Follower", "Leader"], 3),
                ([55, 53, 57, 51], [0, 0, 1, 0], ["Follower", "Follower", "Follower", "Leader"], 2),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [1, 0, 0, 1], ["Leader", "AttemptFollow", "AttemptFollow", "AttemptFollow"], 3)
            ]
            self.voltage = results[self._encourage_count][0]
            self.contactor = results[self._encourage_count][1]
            self.lf_role = results[self._encourage_count][2]
            self._encourage_count += 1
            return results[self._encourage_count-1][3]
        def recover(self, bat=0, recovery=False):
            self._recover_calls.add((bat, recovery))
            if bat == 0:
                self.contactor = [(0 if recovery else 1)] * len(self.voltage)
                self._result = False
            else:
                for i in range(len(self.batt_id)):
                    if self.batt_id[i] == bat:
                        self.contactor[i] = (0 if recovery else 1)
                        self._result = True
        def sendShutdown(self, bat=0):
            self._shutdown = True
    return _batt

@pytest.fixture
def fake_inv():
    class _inv:
        def __init__(self):
            self.MAX_CHARGE_VOLTAGE = 55.0
            self.RECOVERY_CHARGE_VOLTAGE = 50.0
            self.t_output = True
            self.t_op = True
            self.t_charge = 55.0
            self.t_current = 180
            self._current_calls = set()
            self._configured = False
        def invParams(self):
            return {"charge_v": 80}
        def forceOutputOff(self):
            self.t_output = False
        def forceOutputOn(self):
            self.t_output = True
        def shutOffInverting(self):
            self.t_op = False
        def reqChargeVoltage(self, v: float = 57.0):
            self.t_charge = v
        def reqOperatingRange(self, shutdown = 50, restart = 52, low = 50.1):
            self.t_op = True
        def reqOutputRange(self, sl_off: float = 51, sl_on: float = 53):
            self.t_output = sl_off == 51 and sl_on == 53
        def reqChargeCurrent(self, current):
            self._current_calls.add(current)
            self.t_current = current
        def reqConfigure(self, summer=False):
            self._configured = True
            self.reqChargeVoltage()
            self.reqOutputRange()
            self.reqOperatingRange()
        def getFaults(self):
            return ["Fault Inverter - Failed"]
    return _inv

@pytest.fixture
def fake_trk():
    class _trk:
        def __init__(self):
            self.servo = "trkidle"
            self.service = "off"
            self.trk_az = 180
            self.sun_el = 0
        def safe(self):
            self.service = "on"
            self.trk_az = 180
        def normal(self):
            self.service = "off"
            self.trk_az = 80.112
            self.tgt_az = 80.412
    return _trk

@pytest.fixture
def fake_wtr():
    class _wtr():
        def __init__(self):
            self._summer = True
        def summer(self):
            return self._summer
    return _wtr

@pytest.fixture
def fake_db():
    class _db:
        def __init__(self):
            self._configured = False
            self.put_calls = []
        def create(self, msg):
            self.put_calls.append(msg)
        def put(self, msg):
            self.put_calls.append(msg)
            self._configured = True
    return _db

@pytest.fixture
def fake_log(monkeypatch):
    _logs = []
    
    def fake_log(level, device, mesg):
        _logs.append(mesg)

    return (_logs, fake_log)

@pytest.fixture
def config():
    return {
        "arc": 54321,
        "battery_vend": "EVE",     # Beam, EVE, or Flux
        "num_batteries": 5,
        "light_iface": { "column": 2, "epower": 3 }, # or { "mx-dio": 0 }
        "dcfc_iface": None,     # "can0" or None
        "dcfc_id": None
    }
@pytest.fixture
def system():
    return {
        "battery_power_control": False,
    }
@pytest.fixture
def heating():
    return {
        "heater_iface": {"main": 0, "group1": 1, "group2": 2},
        "temperatureMaxDelta":  {
            "Beam": 15,  # Celcius
            "EVE": 15,   # Celcius
            "Flux": 27,  # Farenheit
        },
        "temperatureMinStart": {
            "Beam": 4,   # Celcius   |Beam is N/A since this module has no affect on heater controls in R06
            "EVE": 4,    # Celcius
            "Flux": 37,  # Farenheit
        },
        "temperatureMinStop": {
            "Beam": 5,   # Celcius
            "EVE": 5,    # Celcius
            "Flux": 40,  # Farenheit
        },
        "lowVoltageCutOff": {
            "Beam": 3.3,  # 46.2 V    - pack equivalent
            "EVE": 3.02,  # 48.32 V
            "Flux": 3.02, # 48.32 V
        },
        "partialHeatTime": [ 10, 20, 30, 90, 9999 ],
        "partialHeatBackoff": 3600,                    # Wait time after partial heat failure
        "heatingDailyFailMax": 6,                       # counts both partial and full heat failures
        "minimumSolarAngle": 10,
        "minimumChargeCurrent": 0,
    }

@pytest.fixture
def weather(): 
    return {
        "sunny_match": [ "sunny", "partly cloudy", "scattered", "slight chance", "clear" ],
        "warm": { "F": 40, "C": 4.45 },
    }

@pytest.fixture
def action_conf():
    return {
        # Runnaway Heater
        "heaterFaultTemp": 75,     # degrees Celsius
        "heaterConfirmTime": 180,  # 3 minutes
        # Overcurrent
        "overcurrentMaxAmp": 28,   # Amps
        "overcurrentDownSec": 600, # seconds (10 minutes)
        # Tracker Conditioning
        "lowVoltageWarning": {
            "Beam": 3.429,         # Low Voltage Limit for Battery Recovery
            "EVE": 3.05,
            "Flux": 3.05,
        },
        "lowVoltageClear": {
            "Beam": 3.679,         # restart_voltage / # cells
            "EVE": 3.35,
            "Flux": 3.35,
        },
        "lowTemperatureWarning": {
            "Beam": 3,
            "Flux": 37,
            "EVE": 3,
        },
        "lowTemperatureClear": {
            "Beam": 5,
            "Flux": 42,
            "EVE": 5,
        },
        # Low Voltage Conditioning
        "lowVoltageChargeCurrent": 0,
        "lowVoltagePowerControl": False,
        "lowVoltageChargeDwell": 1800,  # 30 min
        "lowVoltageLimit": { "Beam": 3.3, "EVE": 3.02, "Flux": 3.02 },
        "lowVoltageRecoveryTemp": { "Beam": 5, "EVE": 5, "Flux": 40 },
        # Cold Conditioning
        "lowTemperatureMask": {
            "Beam": 1<<5,
            "EVE": (3<<10) + (3<<26),
            "Flux": (1<<7) + (1<<22),
        },
        # Overcharge Voltage Reduction
        "overchargeHighVoltageOverage": 0.5,
        "lowerChargeVoltage": 52,
        # Battery Balancing
        "balanceStartVoltage": {
            "Beam": 56.6,
            "EVE": 54.2,
            "Flux": 54.6
        },
        "balanceStopVoltage": {
            "Beam": 3.99,
            "EVE": 3.36,
            "Flux": 3.4,
        },
        "balanceMaxSpread": {
            "Beam": 0.08,
            "EVE": 0.05,
            "Flux": 0.05,
        },
        # Tracker Revive
        "trackerReviveTimer": 600,        # Seconds (10 minutes)
        # Periodic Inverter Configuration
        "inverterConfigPeriod": 3600*24,  # Seconds
        # Periodic Database Configuration
        "databaseThinPeriod": 100, # Seconds
    }

