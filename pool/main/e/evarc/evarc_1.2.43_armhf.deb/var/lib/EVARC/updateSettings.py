import minimalmodbus
import traceback
import time
import os
from collections import OrderedDict

script_dir = os.path.dirname(os.path.abspath(__file__))
batt_settings = OrderedDict([
            # ("Year_Month",[56, 0, False]),
            # ("Day_Hour",[57, 0, False]),
            # ("Minute_Second",[58, 0, False]),
            # ("unknown_59",[59, 0, False]),
            ("pack_OV_alarm",[60, 3, False, 59.2]),
            ("pack_OV_protection",[61, 3, False, 58.08]),
            ("pack_OV_release",[62, 3, False, 54.0]),
            ("pack_OV_delay_time",[63, 1, False, 1.0]), #comes in .1S
            ("cell_OV_alarm",[64, 3, False, 3.5]),
            ("cell_OV_protection",[65, 3, False, 3.6]),
            ("cell_OV_release",[66, 3, False, 3.42]),
            ("cell_OV_delay_time",[67, 1, False, 1.0]), #comes in .1S
            ("pack_UV_alarm",[68, 3, False, 44.8]),
            ("pack_UV_protection",[69, 3, False, 43.2]),
            ("pack_UV_release",[70, 3, False, 48.0]),
            ("pack_UV_delay_time",[71, 1, False, 1.0]), #comes in .1S
            ("cell_UV_alarm",[72, 3, False, 2.8]),
            ("cell_UV_protection",[73, 3, False, 2.7]),
            ("cell_UV_release",[74, 3, False, 2.9]),
            ("cell_UV_delay_time",[75, 1, False, 1.0]), #comes in .1S
            ("charging_OC_alarm",[76, 0, False, 40]),
            ("charging_OC_protection",[77, 0, False, 40]),
            ("charging_OC_delay_time",[78, 1, False, 1.0]),
            ("discharge_OC_alarm",[79, 0, False, 40]), #comes in .1S
            ("discharge_OC_protection",[80, 0, False, 40]),
            ("discharge_OC_delay_time",[81, 1, False, 1.0]),
            ("discharge_OC2_protection",[82, 0, False, 50]),
            ("discharge_OC2_delay_time",[83, 0, False, 4]), #comes in .025S
            ("charging_OT_alarm",[84, 1, False, 55.0]),
            ("charging_OT_protection",[85, 1, False, 60.0]),
            ("charging_OT_release",[86, 1, False, 50.0]),
            ("discharging_OT_alarm",[87, 1, False, 55.0]),
            ("discharging_OT_protection",[88, 1, False, 60.0]),
            ("discharging_OT_release",[89, 1, False, 55.0]),
            ("charging_UT_alarm",[90, 1, True, 4.0]),
            ("charging_UT_protection",[91, 1, True, 2.0]),
            ("charging_UT_release",[92, 1, True, 4.0]),
            ("discharging_UT_alarm",[93, 1, True, -16.0]),
            ("discharging_UT_protection",[94, 1, True, -18.0]),
            ("discharging_UT_release",[95, 1, True, -16.0]),
            ("MOSFET_OT_alarm",[96, 1, False, 90.0]),
            ("MOSFET_OT_protection",[97, 1, False, 110.0]),
            ("MOSFET_OT_release",[98, 1, False, 85.0]),
            ("Env_OT_alarm",[99, 1, False, 55.0]),
            ("Env_OT_protection",[100, 1, False, 60.0]),
            ("Env_OT_release",[101, 1, False, 55.0]),
            ("Env_UT_alarm",[102, 1, True, -10.0]),
            ("Env_UV_protection",[103, 1, True, -15.0]),
            ("Env_UV_release",[104, 1, True, -10.0]),
            ("Balance_start_V",[105, 3, False, 3.4]),
            ("Balance_start_delta_V",[106, 0, False, 30]),
            ("Pack_full_charge_V",[107, 3, False, 54.3]),
            ("Pack_full_charge_A",[108, 3, False, 5.0]),
            ("Cell_Sleep_V",[109, 3, False, 3.1]), #minutes
            ("Cell_Sleep_Delay_Time",[110, 0, False, 1]), #minutes
            ("Short_Circuit_Delay_Time",[111, 0, False, 12]), #uS
            ("SOC_alarm_threshold",[112, 0, False, 20]),
            ("charging_OC2_protection",[113, 0, False, 50]),
            ("charging_OC2_delay_time",[114, 0, False, 4])
            # ("version_info_1",[150, 0, False]),
            # ("version_info_2",[151, 0, False]),
            # ("version_info_3",[152, 0, False]),
            # ("version_info_4",[153, 0, False]),
            # ("version_info_5",[154, 0, False]),
            # ("version_info_6",[155, 0, False]),
            # ("version_info_7",[156, 0, False]),
            # ("version_info_8",[157, 0, False]),
            # ("version_info_9",[158, 0, False]),
            # ("version_info_10",[159, 0, False]),
            # ("model_No_1",[160, 0, False]),
            # ("model_No_2",[161, 0, False]),
            # ("model_No_3",[162, 0, False]),
            # ("model_No_4",[163, 0, False]),
            # ("model_No_5",[164, 0, False]),
            # ("model_No_6",[165, 0, False]),
            # ("model_No_7",[166, 0, False]),
            # ("model_No_8",[167, 0, False]),
            # ("model_No_9",[168, 0, False]),
            # ("model_No_10",[169, 0, False]),
            # ("pack_SN_1",[170, 0, False]),
            # ("pack_SN_2",[171, 0, False]),
            # ("pack_SN_3",[172, 0, False]),
            # ("pack_SN_4",[173, 0, False]),
            # ("pack_SN_5",[174, 0, False]),
            # ("pack_SN_6",[175, 0, False]),
            # ("pack_SN_7",[176, 0, False]),
            # ("pack_SN_8",[177, 0, False]),
            # ("pack_SN_9",[178, 0, False]),
            # ("pack_SN_10",[179, 0, False])
        ])

def readRegisters(i):
    try:
        batt_dict = OrderedDict([])
        module = i + 1
        #print(module)
        instrument = minimalmodbus.Instrument("/dev/ttyM0", module) # port name, slave address (in decimal)
        time.sleep(.1)
        # this is the serial port name
        instrument.serial.baudrate = 9600   # Baud
        instrument.serial.bytesize = 8
        instrument.serial.parity   = "N"
        instrument.serial.stopbits = 1
        instrument.serial.timeout  = 2   # seconds
        for field in batt_settings:
            register = batt_settings[field][0]
            number_of_decimals = batt_settings[field][1]
            signed = batt_settings[field][2]
            functioncode = 3
            value = instrument.read_register(register, number_of_decimals=number_of_decimals, functioncode=functioncode, signed=signed)# read_registers(registeraddress, number_of_registers, functioncode=3)
            batt_dict[field] = value
        ### must sleep becuase there needs to be a pause between modules
        time.sleep(.1)
        return batt_dict
    except Exception as e:
        tb = traceback.format_exc()
        print(e)
        print(tb)
        time.sleep(.1)
        return {}

def getData(data_dict, number_of_batteries):

    try:
        settingsChanged = 0
        for i in range(number_of_batteries):
            attempts = 0
            batt_dict = OrderedDict([])
            while batt_dict == {} and attempts <= 1:
                if attempts == 1:
                    print("Error Reading Battery " + str(i + 1) + ". Trying again.\n")
                batt_dict = readRegisters(i)
                attempts = attempts + 1

            if attempts > 1:
                print("ERROR: BATTERY " + str(i + 1) + " FAILED TO READ SETTINGS")
                settingsChanged = settingsChanged + 1

            data_dict[i+1] = batt_dict

        #print(data_dict)
        for batt in data_dict:
            instrument = minimalmodbus.Instrument("/dev/ttyM0", batt) # port name, slave address (in decimal)
            time.sleep(.1)
            # this is the serial port name
            instrument.serial.baudrate = 9600   # Baud
            instrument.serial.bytesize = 8
            instrument.serial.parity   = "N"
            instrument.serial.stopbits = 1
            instrument.serial.timeout  = 2   # seconds
            for setting in data_dict[batt]:
                #print(setting, batt_settings[setting][3], (data_dict[batt][setting]))
                if batt_settings[setting][3] != data_dict[batt][setting]:
                    instrument.write_register(batt_settings[setting][0],batt_settings[setting][3], batt_settings[setting][1], signed=batt_settings[setting][2])
                    settingsChanged = settingsChanged + 1

        return settingsChanged

    except Exception as e:
        tb = traceback.format_exc()
        print(e)
        print(tb)
        pass
    return

def main(number_of_batteries=None):
    if number_of_batteries is None:
        import arcConfig
        number_of_batteries = arcConfig.config['num_batteries']
    try:
        settingsChanged = 1
        count = 0
        print("\nUpdating Battery Settings")
        while settingsChanged > 0 and count <= 2:
            data_dict = OrderedDict([])
            settingsChanged = getData(data_dict, number_of_batteries)
            count = count + 1
            print("\n")
            if settingsChanged > 0 and count <= 2:
                print("Settings Changed: " + str(settingsChanged) + ", Attempt: " + str(count))

        if settingsChanged > 0 and count > 2:
            print("ERROR: Changing Settings FAILED. Identify the issue and try again.")
        elif settingsChanged == 0:
            print("Settings Are Up To Date.\n")
    except Exception as e:
        tb = traceback.format_exc()
        print(e)
        print(tb)
        exit()


# Check if script is being ran via another script
if __name__ == '__main__':
    main()

