import time
import actions

class batt:
    def __init__(self, n):
        self.voltage = [52] * n
        self.max_voltage = [3.6] * n
        self.min_voltage = [3.55] * n
        self.max_temp = [24] * n
        self.faults = [0] * n
        self.contactor = [1] * n
        self.NON_RECOVERABLE_FAULTS = 2
        self.MIN_CELL_BAL_CHECK = 3.6

    def getFaults(self):
        results = []
        for i in range(len(self.faults)):
            if self.faults[i] != 0:
                results.append("Battery "+str(i+1)+": Failed status "
                              +str(self.faults[i]))
        return results
    def getLVRecovery(self):
        return any([i < 50 for i in self.voltage])
    def getRecovery(self):
        return all([i == 0 for i in self.contactor])
    def getInvParams(self):
        return "Inverter Params"
    def sendShutdown(self, i):
        print("Shutting off")


#========  actions/battery_balancing.py
# batt.min_voltage
# batt.max_voltage
# batt.voltage
#========  actions/battery_fault.py
# batt.getFaults()
#========  actions/battery_revive.py
# batt.getLVRecovery
# batt.getRecovery
# batt.voltage
# batt.faults[i]
# batt.NON_RECOVERABLE_FAULTS
# batt.voltage[i]
#========  actions/overcharge_voltage_reduction.py
# batt.voltage
#========  actions/overcurrent.py: 
# batt.getInvParams
#========  actions/periodic_inverter_config.py
# batt.contactor
# batt.faults 
# batt.NON_RECOVERABLE_FAULTS
#========  actions/runaway_heater.py
# batt.max_temp
# batt.sendShutdown(0)

class inv:
    def __init__(self):
        self.MAX_CHARGE_VOLTAGE = 55
        self.RECOVERY_CHARGE_VOLTAGE = 50
        self.output_A_L1 = 1
        self.output_A_L2 = 1
        self.faults = 0

    def shutOffOutput(self):
        pass
    def setChargeVoltage(self, v):
        pass
    def getFaults(self):
        if self.faults:
            return ["Inverter Fault: "+ str(self.faults)]
        return []
    def forceOutput(self, timeout, handler):
        pass
    def reduceMaxChargeVoltage(self):
        pass
    def setChargingRange(self, on, off):
        pass
    def configure(self, invParams="Inverter Params"):
        assert(invParams == "Inverter Params")
    def shutOffInverting(self):
        pass


#========  actions/battery_balancing.py
# inv.shutOffOutput()
#========  actions/battery_revive.py
# inv.shuttOffOutput()
# inv.MAX_CHARGE_VOLTAGE
# inv.setChargeVoltage
# inv.RECOVERY_CHARGE_VOLTAGE
#========  actions/inverter_fault.py
# inv.getFaults()
#========  actions/output_force.py
# inv.forceOutput(self.start + TIMEOUT, lambda: os.remove("SL_on"))
# inv.forceOutput(self.start + TIMEOUT, lambda: os.remove("SL_on"))
#========  actions/overcharge_voltage_reduction.py
# inv.MAX_CHARGE_VOLTAGE
# inv.reduceMaxChargeVoltage()
#========  actions/overcurrent.py
# inv.output_A_L1 >= MAX_LINE_CURRENT) or
# inv.output_A_L2 >= MAX_LINE_CURRENT)) or
# inv.setChargingRange(params['sl_on'], params['sl_off'])
#========  actions/periodic_inverter_config.py
# inv.configure()
#========  actions/runaway_heater.py
# inv.shutOffInverting()


class trk:
    def __init__(self):
        self.sun_el = 0
        self.latitude = None
        self.longitude = None
        self.service = "off"
    def safe(self):
        pass
    def normal(self):
        pass

#========  actions/battery_revive.py
# trk.sun_el < 30):
# trk.safe()
#========  actions/location_distribution.py
# trk.longitude
# trk.latitude
#========  actions/runaway_heater.py: 
# trk.safe()
#========  actions/tracker_revive.py
# trk.service
# trk.sun_el < 30):
# trk.normal()

class wtr:
    def __init__(self):
        self.lat = None
        self.lon = None
        self.t_sunny = False
    def sunny(self):
        return self.t_sunny

#========   actions/battery_revive.py
# wtr.sunny
#========   actions/location_distribution.py
# wtr.lon
# wtr.lat
#========   actions/tracker_revive.py
# wtr.sunny
# wtr.sunny
    
class db:
    def create(self, s):
        pass
    def put(self, s):
        pass
    
def log(level, sub, message):
    print(message)

#========   actions/__init__.py
# log('critical', 'actions', 'Thread crashed see /var/log/EVARC.log')
#========   actions/overcurrent.py
# log('error', 'EVARC', 'High current detected, L1= %sA, L2= %sA'
# log("info", 'EVARC', "Over current fault has cleared")
#========   actions/periodic_inverter_config.py
# log("info", 'EVARC', "Setting Inverter Configuration")
#========   actions/runaway_heater.py
# log("error", 'EVARC', "Over Temperature fault started")
# log("info", 'EVARC', "OT fault is clear")
# log("critical", 'EVARC',


def main():
    b = batt(4)
    i = inv()
    t = trk()
    w = wtr()
    d = db()

    with open("battBalance", 'w') as f:
       f.write(str(time.time())) 

    a = actions.Actor(b, i, t, w, d, log)
    a.start()

    print("\x1b7\x1bc"+a.HEADER+"\x1b8")
    print(a.showData())

    time.sleep(3)
    # battery_balancing.py
    b.min_voltage = [3.61] * 4
    time.sleep(3)
    #assert ("alanc" in a.status)
    
    print(a.showData())
    # battery_fault.py
    b.faults = [0, 1, 0, 0]
    time.sleep(3)
    
    print(a.showData())
    # battery_revive.py
    b.recovery = [8, 124, 124, 124]
    b.contacotr = [0, 0, 0, 0]
    time.sleep(3)

    print(a.showData())
    # inverter_fault.py
    i.faults = 1
    time.sleep(3)

    print(a.showData())
    # location_distribution.py
    trk.latitude = 123.456
    trk.logitude = 654.321
    time.sleep(3)

    print(a.showData())
    # output_force.py
    open("SL_on", 'w')
    time.sleep(3)

    print(a.showData())
    # overcharge_voltage_reduction.py
    b.voltage = [60, 60, 60, 60]
    time.sleep(3)

    print(a.showData())
    # overcurrent.py
    i.output_A_L1 = 30
    i.output_A_L2 = 28

    time.sleep(3)
    print(a.showData())
    # periodic_inverter_config.py

    time.sleep(3)
    print(a.showData())
    # runaway_heater.py
    b.max_temp = [40, 40, 40, 40]

    time.sleep(3)
    print(a.showData())
    # tracker_revive.py
    t.service = "On"
    time.sleep(3)

    print(a.showData())

if __name__ == "__main__":
    main()
