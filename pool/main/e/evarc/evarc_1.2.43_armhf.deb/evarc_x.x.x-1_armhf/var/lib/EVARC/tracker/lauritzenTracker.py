#!/usr/bin/python3
import pexpect
import time
import threading
import os
import can
import cantools
import traceback

INTERFACE = ''

def trkcmd(cmd):
    global INTERFACE
    try:
        p = pexpect.spawn("telnet "+INTERFACE)
        i = p.expect([pexpect.TIMEOUT, "Account: "])
        if i == 1:
            p.sendline("admin\r\n")
            i = p.expect([pexpect.TIMEOUT, "Password: "])
            if i == 1:
                p.sendline("1364\r\n")
                i = p.expect([pexpect.TIMEOUT, "TN_ADMIN"])
                if i == 1:
                    p.sendline("\r\n")
                    i = p.expect([pexpect.TIMEOUT, "evarc> "])
                    if i == 1:
                        p.sendline(cmd+"\r\n")
                        i = p.expect([pexpect.TIMEOUT, "evarc> "])
                        if i == 1:
                            ret_value = p.before.decode('utf-8')[len(cmd):]
                            p.sendline("quit\r\n")
                            p.close()
                            return ret_value
    except Exception:
        pass
    return None

def getField(field, data):
    strt = data.find(field)
    if strt == -1:
        raise Exception("Field %s not found." % (field))
    strt += len(field)
    while data[strt] == ' ' or data[strt] == '.':
        strt += 1
    end = data.find("\r\n", strt)
    return data[strt:end]

def getEntry(key, data, end=','):
    strt = data.find(key)
    if strt == -1:
        raise Exception("Entry %s not found in %s." % (key, data))
    strt += len(key)
    stp = data.find(end, strt)
    if stp == -1:
        return data[strt:]
    else:
        return data[strt:stp]

PARAMETERS = {
    'trkshow': {
        'sun_az': ("Solar pos", "a=", ','),
        'sun_el': ("Solar pos", "e=", ')'),
        'latitude': ("Geo loc", "lat=", ')'),
        'longitude': ("Geo loc", "lng=", ','),
        'trk_az': ("Tracker pos", "a=", ','),
        'trk_el': ("Tracker pos", "e=", ')'),
        'tgt_az': ("Tracker tgt", "a=", ','),
        'tgt_el': ("Tracker tgt", "e=", ')'),
        'storm': ("ManualStorm"),
        'clean': ("ManualClean"),
        'stopmode': ('ManStp/AdmStp'),
    },
    'sysshow': {
        'error': ("Error"),
        'motor': ("Motor"),
    },
    'info': {
        'service': ('Service mode'), 
    },
    'aux show': {
        'aux': ("AUX state"),
    },
    'srvshow': {
        'servo': ("FSM", "", "("),
    },
    'encshow': {
        'encoder': ('Encoder Counter')
    },
}


class Tracker():
    def __init__(self, db, log, spn, conf):
        global INTERFACE
        INTERFACE = conf['tracker_iface']
        self.dcfc_iface = conf['dcfc_iface']
        self.dcfc_id = conf['dcfc_id']
        self.db = db
        self.log = log
        self.spn = spn
        self.lock = threading.Lock() 
        db.create("CREATE TABLE tracking (id INTEGER PRIMARY KEY, timestamp"\
            + " CONVERT_TIMESTAMP, latitude REAL, longitude REAL, sun_az REAL,"\
            + " trk_az REAL, sun_el REAL, trk_el REAL, tgt_az REAL, servo TEXT,"\
            + " aux TEXT, storm TEXT, clean TEXT, stop TEXT, service TEXT,"\
            + " error INTEGER)")
        self.stop = False
        self.updated = False
        self.sn = None
        self.outputlen = 10
        self.rowoffset = 0
        self.columnoffset = 0
        for v in PARAMETERS.values():
            for k in v.keys():
                exec("self." + k + " = None") 
        self.HEADER = """    Tracker 

  latitude:               longitude:
sun azmuth:           sun elevation:
trk azmuth:           trk elevation:
tgt azmuth:
                            service:
      stop:                     aux:
     storm:                   clean:
     error:                   servo:"""
        self.sql = "INSERT INTO tracking (timestamp, latitude, longitude,"\
              + " sun_az, sun_el, trk_az, trk_el, tgt_az, servo, aux, storm,"\
              + " clean, error, stop, service) VALUES (%f, %f, %f, %f,"\
              + " %f, %f, %f, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')"
        
    def getData(self):
        """collect data from the tracker and save it in class"""
        # m is a command
        # l is a dict with varname as keys and parameters to find value in
        #  the commad results
        self.spn += 1
        if self.sn is None:
            self.sn = getSerialNo()
        for m, l in PARAMETERS.items():
            result = trkcmd(m)
            if result is None:
                self.updated = False
                continue
            for k, v in l.items():
                if type(v) is type(""):
                    if k == 'error':
                        exec("self.%s = %s" % (k, getField(v, result)))
                    else:
                        exec("self.%s = '%s'" % (k, getField(v, result)))
                        if k == 'service':
                            self.service = "Off" if self.service == "No" else "On"
                elif len(v) == 2:
                    exec("self.%s = %s" % (k, getEntry(v[1], getField(v[0], result))))
                elif len(v) == 3: 
                    if k == 'servo':
                        exec("self.%s = '%s'" % (k, 
                             getEntry(v[1], getField(v[0], result), v[2])))
                    else:
                        exec("self.%s = %s" % (k, 
                             getEntry(v[1], getField(v[0], result), v[2])))
                else:
                    raise Exception(v)
        if self.encoder is not None:
            if self.encoder == "0(OK)" or self.encoder == "9998546(OK)" or "NOK" in self.encoder:
                self.trk_az = None
                self.trk_el = None
        if None not in [self.dcfc_iface, self.dcfc_id, self.service, self.tgt_az]:
            try:
                bus = can.interface.Bus(self.dcfc_iface, bustype="socketcan")
                db = cantools.database.load_file(
                        os.path.dirname(os.path.abspath(__file__)) + "/../dbc/DCFC_ARC_001.dbc")
                msg = db.encode_message('DCFC_Status_Msg', {"Source": self.dcfc_id, "Device": 2,
                    "Tracker_ServiceMode": (1 if self.service.lower() == 'on' else 0), 
                    "Tracker_Trk_Azmuth": (524.287 if self.trk_az is None else self.trk_az), 
                    "Tracker_Tgt_Azmuth": self.tgt_az })
                bus.send(can.Message(arbitration_id=304, data=msg, is_extended_id=False))
            except can.CanError:
                self.log('error', 'tracker', 'Could not send can message')

    def saveData(self):
        """write tracker data to the database"""
        if self.tgt_az is not None:
            self.db.put(self.sql % (time.time(), float(self.latitude),
                  float(self.longitude), float(self.sun_az),
                  float(self.sun_el), (524.287 if self.trk_az is None else self.trk_az), 
                  (524.287 if self.trk_el is None else self.trk_el), float(self.tgt_az),
                  self.servo, self.aux, self.storm, self.clean, self.error,
                  self.stopmode, self.service))

    def showData(self):
        """Writes collected data to output"""
        ret_value = ("\x1b[%d;%df" %(self.rowoffset, self.columnoffset+14) 
                  + (self.sn if self.sn is not None else "None"))
        if self.latitude is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+2, self.columnoffset+14, self.latitude)
        if self.longitude is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+2, self.columnoffset+39, self.longitude)
        if self.sun_az is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+3, self.columnoffset+14, self.sun_az)
        if self.sun_el is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+3, self.columnoffset+39, self.sun_el)
        if self.trk_az is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+4, self.columnoffset+14, self.trk_az)
        if self.trk_el is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+4, self.columnoffset+39, self.trk_el)
        if self.tgt_az is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+5, self.columnoffset+14, self.tgt_az)
        if self.service is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+6, self.columnoffset+39, self.service)
        if self.stopmode is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+7, self.columnoffset+14, self.stopmode)
        if self.aux is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+7, self.columnoffset+39, self.aux)
        if self.storm is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+8, self.columnoffset+14, self.storm)
        if self.clean is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+8, self.columnoffset+39, self.clean)
        if self.error is not None:
            ret_value += "\x1b7\x1b[%d;%df%x\x1b8"%(self.rowoffset+9, self.columnoffset+14, self.error)
        if self.servo is not None:
            ret_value += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+9, self.columnoffset+39, self.servo)
        ret_value +=  "\x1b[%d;%df%s" % (self.rowoffset+self.outputlen, self.columnoffset+54, self.spn)
        return ret_value

    def normal(self):
        """Verify tracker is working normally"""
        if self.service is not None and self.service == "On":
            trkcmd('service 0')
        if self.stopmode is not None and self.stopmode == "On":
            trkcmd('AdminStop -clear')
            self.log('info', "tracker", "In service mode: turning service mode off")

        return True

    def safe(self):
        """Configure tracker for Northern Hemisphere sleep"""
        trkcmd('service 1')
        trkcmd('tgtgoto az 180')
        self.log('info', "tracker", "In tracker safe: suspend tracking and face South")

    def clrEncoder(self):
        """Force tracker to return to paddles and reorient"""
        trkcmd('service 1')
        trkcmd('encclr -void')
        self.log('info', "tracker", "In tracker encoder: clear known position")

    def smode(self):
        """Stop tracking until service is complete"""
        trkcmd('service 1')
        self.log('info', "tracker", "Set tracker to service mode")

    def start(self):
        """Launch a thread to collect, record and report the tracker data"""
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        """Method that performs collect, record and report the tracker data"""
        while not self.stop:
            self.updated = True
            try:
                self.getData()
                self.saveData()
                time.sleep(1.5)
            except Exception:
                self.log('critical', 'tracker', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")


def getHeading():
    """Return the heading in degrees"""
    result = trkcmd("trkshow")
    while result is None:
        time.sleep(0.5)
        result = trkcmd("trkshow")
    return int(getField("Stow Pos", result)[:-2])

def getSerialNo():
    """Return the tracker's serial number string"""
    result = trkcmd("info")
    while result is None:
        time.sleep(0.5)
        result = trkcmd("info")
    return getField("HWSerialNo", result).split(" ")[0]

if __name__ == "__main__":
    class log():
        def error(device: str, level: str, msg: str):
            print("|%s| (%s) - %s" % (device, level, msg))

    class db():
        def create(self, s):
            pass
        def put(self, s):
            pass
    t = Tracker(db(), log())
    print("\033c\033[3J\x1b7\x1b[1;1f"+t.HEADER+"\n\x1b8")
    t.start()
    time.sleep(12)
    while True:
        print(t.showData())
        time.sleep(1)
        if t.runner.is_alive():
            print("\x1b7\x1b[12;1fRUNNING")
        else:
            print("\x1b7\x1b[13;1fDIED")

