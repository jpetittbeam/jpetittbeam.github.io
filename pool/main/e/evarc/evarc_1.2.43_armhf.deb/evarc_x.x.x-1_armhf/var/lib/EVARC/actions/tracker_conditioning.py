import os
import time
import datetime
import threading
import traceback

FLAG = "/home/service/trkConditioning"
sysFLAG = "/home/service/sysConditioning"
LOW_VOLTAGE = 0
LOW_VOLT_CLEAR = 0
LOW_TEMP = 0
LOW_TEMP_CLEAR = 0

class TrackerConditioning:
    def __init__(self, batt, trk, log, config):
        global LOW_VOLTAGE, LOW_VOLT_CLEAR, LOW_TEMP, LOW_TEMP_CLEAR
        LOW_VOLTAGE = config['lowVoltageWarning'][batt.type]
        LOW_VOLT_CLEAR = config['lowVoltageClear'][batt.type]
        LOW_TEMP = config['lowTemperatureWarning'][batt.type]
        LOW_TEMP_CLEAR = config['lowTemperatureClear'][batt.type]
        self.batt = batt     # battery object
        # self.inv = inv       # inverter object
        self.trk = trk       # solar tracker object
        # self.wtr = wtr       # weather object
        self.log = log       # error logging
        self.runner = None   # thread of the runner
        self.running = False # escape boolean
        self.status = []     # single line of status for output
        self.action_mask = 1 # mask indicates changes needed for corrective actions

        # action_mask is defined as follows:
        # ----------+---------+------------------------------------
        # |bit      |device   |areas of change
        # ----------+---------+------------------------------------
        # 0      1   tracker   conditiong (service mode)
        # 1      2   batt      revive | shutdown (contactor open)
        # 2      4   batt      heating
        # 3      8   batt      reserved
        # 4      16  inverter  output control (smartload)
        # 5      32  inverter  charge voltage
        # 6-7        inverter  reserved
        # ----------+---------+------------------------------------

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if os.path.isfile(sysFLAG):
            return
        if not self.running:
            if os.path.isfile(FLAG):
                with open(FLAG, 'r') as f:
                    self.status = [f.read()]
            #perform check
            minTemp = 40
            #for i in range(len(self.batt.min_temp)):
            for i in range(len(self.batt.min_temp)):
                if (self.batt.min_temp[i] is not None and
                    self.batt.faults[i] is not None and 
                    not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS)):
                    if self.batt.min_temp[i] < minTemp:
                        minTemp = self.batt.min_temp[i]
            if minTemp < LOW_TEMP:
                self.status = ["Tracker Conditioning - Low Temperature"]
            minCellVolt = 10
            for i in range(len(self.batt.min_voltage)):
                if (self.batt.min_voltage[i] is not None and 
                    self.batt.faults[i] is not None and
                    not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS)):
                    if self.batt.min_voltage[i] < minCellVolt:
                        minCellVolt = self.batt.min_voltage[i]
            if minCellVolt < LOW_VOLTAGE:
                self.status = ["Tracker Conditioning - Low Voltage"]

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        self.start_time = time.time()
        try:
            # start tracker conditioning after 30 min
            workingOnIt = True
            while self.running and workingOnIt and \
                  "Low Temperature" not in self.status[0] and \
                        self.start_time + 1800 > time.time():
                self.status = ['Tracker Conditioning - Waiting']
                # Check for conditions to clear
                minCellVolt = 10
                for i in range(len(self.batt.min_voltage)):
                    if self.batt.min_voltage[i] is not None and not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS):
                        if self.batt.min_voltage[i] < minCellVolt:
                            minCellVolt = self.batt.min_voltage[i]
                if minCellVolt > (LOW_VOLTAGE + 0.01):
                    workingOnIt = False 
                    self.status = []
                    return
                if os.path.exists(sysFLAG):
                    return
            # Perform confirgurtaion changes
            self.trk.safe()
            time.sleep(3)
            while (self.trk.servo is None or "idle" not in self.trk.servo.lower()):
                time.sleep(4)
                self.status = ['Tracker Conditioning - Orienting South']
            if self.trk.trk_az is not None and round(self.trk.trk_az) != 180:
                self.trk.safe()
            with open(FLAG, 'w') as f:
                f.write(self.status[0])
                self.log('warning', 'action-tc', self.status[0])
            if 'Low Temperature' in self.status[0]:
                self.status = ['Tracker - Low Temp ' + datetime.datetime.now().strftime("%m/%d %H:%M")]
            else:
                self.status = ['Tracker - Low Volt ' + datetime.datetime.now().strftime("%m/%d %H:%M")]
            workingOnIt = True
            while self.running and workingOnIt:
                # Check for conditions to clear
                minTemp = 99
                for i in range(len(self.batt.min_temp)):
                    if self.batt.min_temp[i] is not None and not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS):
                        if self.batt.min_temp[i] < minTemp:
                            minTemp = self.batt.min_temp[i]
                minCellVolt = 10
                for i in range(len(self.batt.min_voltage)):
                    if self.batt.min_voltage[i] is not None and not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS):
                        if self.batt.min_voltage[i] < minCellVolt:
                            minCellVolt = self.batt.min_voltage[i]
                if minCellVolt > LOW_VOLT_CLEAR and minTemp > LOW_TEMP_CLEAR:
                    workingOnIt = False 
                    self.status = []
                if os.path.exists(sysFLAG):
                    self.status = ['Tracker Conditioning - System Revive']
                    self.running = False
            # Restore standard configuration
            if self.status == []:
                self.status = ['Tracker Conditioning - Restoring']
                self.trk.normal()
                time.sleep(3)
                while (self.trk.servo is None or "idle" not in self.trk.servo.lower()):
                    time.sleep(4)
                    self.status = ['Tracker Conditioning - '+("" if self.trk.servo is None else self.trk.servo)]
                if self.trk.trk_az is not None and\
                   self.trk.tgt_az is not None and\
                   round(self.trk.trk_az) != round(self.trk.tgt_az):
                    self.trk.normal()
                self.log('warning', 'action-tc', 'Tracker Conditioning - clear')
                try:
                    os.remove(FLAG)
                except FileNotFoundError:
                    pass
                self.status = []
                time.sleep(10)
                self.running = False
            elif self.status == ['Tracker Conditioning - System Revive']:
                self.status = []
        except Exception:
            self.log('critical', 'action-tc', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch

    # Dummy classes
    class batt:
        def __init__(self):
            self.min_voltage = [3.52, 3.52, 3.52, 3.48, 3.52]
            self.max_voltage = [3.52, 3.52, 3.52, 3.48, 3.52]
            self.min_temp = [8, 8, 8, 8, 8]
            self.max_temp = [8, 8, 8, 8, 8]
            self.faults = [0, 0, 0, 1, 0]
            self.type = "Beam"
            self.contactor = [1, 1, 1, 0, 1]
            self.NON_RECOVERABLE_FAULTS = 1
        def getLVRecovery(self):
            return any([i < 50 for i in self.voltage])
        def getRecovery(self):
            return any([i == 0 for i in self.contactor])
    
    class trk:
        def __init__(self):
            self.servo = "trkidle"
            self.service = "off"
            self.trk_az = 180
        def safe(self):
            self.service = "on"
            self.trk_az = 180.112
        def normal(self):
            self.service = "off"
            self.trk_az = 80.112
            self.tgt_az = 80.412

    def log(level, device, mesg):
        #print(mesg)
        pass

    conf = {
        "lowVoltageWarning": {
            "Beam": 3.429,         # Low Voltage Limit for Battery Recovery
            "EVE": 3.05,
            "Flux": 3.05,
            },
        "lowVoltageClear": {
            "Beam": 3.679,         # restart_voltage / # cells
            "EVE": 3.35,
            "Flux": 3.35,
            },
        "lowTemperatureWarning": {
            "Beam": 3,
            },
        "lowTemperatureClear": {
            "Beam": 5,
            },
    }

    # Setup mocks
    fake_time = [1000000]

    def advance_time(seconds):
        fake_time[0] += seconds
        return fake_time[0]

    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    with patch("os.path.isfile", side_effect=lambda path: path in fake_files), \
         patch("builtins.open", side_effect=open_side_effect), \
         patch("os.remove", side_effect=lambda path: fake_files.pop(path) if path in fake_files.keys() else 0), \
         patch("os.path.exists", side_effect=lambda path: path in fake_files), \
         patch('time.time', side_effect=lambda: advance_time(1)), \
         patch('time.sleep', side_effect=lambda x: advance_time(x)):

        b = batt()
        t = trk()

        test = TrackerConditioning(b, t, log, conf)
        test.check()
        assert test.status == [], "Expected status == [], got "+str(test.status)

        b.min_voltage = [3.428, 3.428, 3.428, 3.428, 3.430]
        test.check()
        assert test.status == ["Tracker Conditioning - Low Voltage"], "Expected active status, got "+str(test.status)

        test.do()
        time.sleep(1800)
        while t.service == "off":
            pass
        assert t.service == "on", "Expected tracker to be safe, got "+t.service

        b.min_voltage = [3.7] * 5
        b.max_voltage = [3.7] * 5
        while test.running:
            pass
        assert test.status == [], "Expected status == [], got "+str(test.status)

        b.min_temp[0] = 2
        test.check()
        assert test.status == ["Tracker Conditioning - Low Temperature"], "Expected active status, got "+str(test.status)
        assert not test.running 
        assert t.service == "off" 

        test.do()
        assert "Low Temp" in test.status[0], "Expected active status, got "+str(test.status)
        assert test.running 
        while t.service == "off":
            pass
        assert t.service == "on", "Expected tracker to be safe, got "+t.service
        assert fake_time[0] < 2002000, "Expected to this to take less time "+str(fake_time[0])
        assert os.path.exists(FLAG)

        b.min_temp[0] = 6
        while test.running:
            pass
        assert test.status == []
        assert not os.path.exists(FLAG)
        print("✅ Pass: Tracker Conditioning sequence completed")

if __name__=="__main__":
    main()
    
    


