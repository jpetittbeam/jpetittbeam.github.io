from heater import Heater, FLAG
from freezegun import freeze_time

def test_header(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, fake_files):
    batt = fake_batt()
    batt.type = "EVE"
    (fake_logs, log) = fake_log
    h = Heater(batt, fake_inv(), fake_trk(), fake_db(), log, heating)

    assert h.HEADER == "        Heating Batteries: "

def test_db(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, 
            fake_time, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    trk = fake_trk()
    db = fake_db()
    (fake_logs, log) = fake_log
    h = Heater(batt, fake_inv(), trk, db, log, heating)
    
    assert db.put_calls[0] == "CREATE TABLE heating (id INTEGER PRIMARY KEY, timestamp COVERT_TIMESTAMP, status TEXT)"

    batt.min_temp = [-3, -3, -3, -3, -3]
    trk.sun_el = 45
    fake_time[0] = h.delayed_start + 1
    h.getData()
    h.saveData()

    assert len(db.put_calls) > 1
    assert db.put_calls[1] == "INSERT INTO heating (timestamp, status) VALUE (100061.000000, ON  )"

def test_heating_files(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating,
            fake_time, fake_date, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    trk = fake_trk()
    db = fake_db()
    (fake_logs, log) = fake_log

    # TOO OLD
    open("/var/lib/EVARC/heating", 'w').write("1970/1/1, 2, 1, 1")
    h = Heater(batt, fake_inv(), trk, db, log, heating)
    assert h.partial_heat_index == 0
    assert h.failcount == 0

    # NO HEAT FAULT
    fake_files.pop("/var/lib/EVARC/heating")
    open("/var/lib/EVARC/heating", 'w').write("2025/1/1, 2, 1, 0")
    h = Heater(batt, fake_inv(), trk, db, log, heating)
    assert h.partial_heat_index == 2
    assert h.failcount == 1

    # HEAT FAULT
    fake_files.pop("/var/lib/EVARC/heating")
    open("/var/lib/EVARC/heating", 'w').write("2025/1/1, 3, 2, 1")
    h = Heater(batt, fake_inv(), trk, db, log, heating)
    assert h.partial_heat_index == 4
    assert h.failcount == 3

def test_heat_too_different(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, 
            fake_time, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    trk = fake_trk()
    db = fake_db()
    (fake_logs, log) = fake_log
    h = Heater(batt, fake_inv(), trk, db, log, heating)
    
    # No Heat Required
    for i in range(5):
        batt.min_temp[i] = 20
    fake_time[0] = h.delayed_start + 1
    h.getData()
    assert h.status == "OFF "

    for i in range(5):
        if i == 1:
            batt.min_temp[i] = 40
        else:
            batt.min_temp[i] = -3
    assert h.status == "OFF "

def test_system_revive_no_sun(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, 
            fake_time, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    trk = fake_trk()
    db = fake_db()
    (fake_logs, log) = fake_log
    batt.min_temp = [-5, -3, -3, -5, -5]
    batt.current = [-0.5] * 5
    inv = fake_inv()
    inv.grid_V_L1 = 35
    h = Heater(batt, inv, trk, db, log, heating)
    fake_time[0] = h.delayed_start + 1
    h.set_sys_revive(lambda: True)
    
    trk.sun_el = -45
    h.getData()
    assert h.status == "OFF "

def test_heat_low_voltage(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, 
            fake_time, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    batt.min_voltage = [2.51, 3.51, 3.51, 3.51, 3.51]
    batt.contactor = [1, 1, 1, 1, 1]
    batt.min_temp = [-5, -3, -3, -5, -5]
    trk = fake_trk()
    trk.sun_el = 45
    db = fake_db()
    (fake_logs, log) = fake_log
    inv = fake_inv()
    inv.grid_V_L1 = 35
    h = Heater(batt, inv, trk, db, log, heating)
    fake_time[0] = h.delayed_start + 1
    h.set_sys_revive(lambda: False)
    
    h.getData()
    assert not h.status

def test_heat_ok(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, 
            fake_time, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    batt.min_voltage = [3.54, 3.54, 3.54, 3.54, 3.54]
    batt.contactor = [1, 1, 1, 1, 1]
    batt.min_temp = [-3, -3, -3, -3, -3]
    batt.current = [3, 3, 1.4, 1.2, -1]
    trk = fake_trk()
    db = fake_db()
    (fake_logs, log) = fake_log
    h = Heater(batt, fake_inv(), trk, db, log, heating)
    fake_time[0] = h.delayed_start + 1
    h.set_sys_revive(lambda: False)

    h.getData()
    assert h.status == "ON  "

def test_heat_revive_no_sun(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, 
            fake_time, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    batt.min_voltage = [3.54, 3.54, 3.54, 3.54, 3.54]
    batt.min_temp = [-3, -3, -3, -3, -3]
    batt.contactor = [1, 1, 1, 1, 1]
    batt.current = [-0.5] * 5
    trk = fake_trk()
    trk.sun_el = -45
    db = fake_db()
    (fake_logs, log) = fake_log
    inv = fake_inv()
    inv.grid_V_L1 = 35
    h = Heater(batt, inv, trk, db, log, heating)
    fake_time[0] = h.delayed_start + 1
    h.set_sys_revive(lambda: True)
    
    h.getData()
    assert h.status == "OFF "

def test_heat_revive_partial(fake_batt, fake_inv, fake_trk, fake_db, fake_log, heating, 
            fake_time, fake_date, fake_files, fake_syscall):
    batt = fake_batt()
    batt.type = "EVE"
    batt.min_voltage = [3.54, 3.54, 3.54, 3.54, 3.54]
    batt.min_temp = [-3, -3, -3, -3, -3]
    batt.contactor = [1, 1, 1, 1, 1]
    batt.current = [3, -3, -1.4, 1.2, -1]
    inv = fake_inv()
    inv.grid_V_L1 = 35
    trk = fake_trk()
    trk.sun_el = 45
    db = fake_db()
    (fake_logs, log) = fake_log

    h = Heater(batt, inv, trk, db, log, heating)
    fake_time[0] = h.delayed_start + 1
    h.set_sys_revive(lambda: True)
    
    fake_time[0] += 45
    fake_date[0].minute = 4
    h.getData()
    assert h.status == "1of2"

    fake_time[0] += 45
    fake_date[0].minute = 9
    h.getData()
    assert h.status == "2of2"



