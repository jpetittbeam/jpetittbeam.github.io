#!/usr/bin/python3
import os
import shutil
import time
import threading

try:
    from pyModbusTCP.client import ModbusClient
except Exception:
    # for MOXA define empty ModbusClient
    class ModbusClient:
        def __init__(self, ip, port):
            pass
        def write_single_register(reg, val):
            pass


class Light():
    def __init__(self, db, log):
        """New instance of Light to control the low battery / status light"""
        self.db = db
        self.log = log
        db.create("CREATE TABLE light (id INTEGER PRIMARY KEY,"
                + "timestamp CONVERT_TIMESTAMP, state INTEGER);")
        self.getInit = None
        self.flashing = False
        self.flash_count = 1
        self.outputlen = 3
        self.rowoffset = 1
        self.columnoffset = 2
        self.HEADER = "\n    Low Battery Light:"
        self.status = ""
        self.last_check = None

    def showData(self):
        self.getValue()
        return "\x1b[%d;%df%s" % (self.rowoffset + 2, self.columnoffset + 24, self.status)

    def setInit(self, callback):
        self.getInit = callback

    def getValue(self):
        """Update low battery light"""
        # Initializing
        if self.status == "" and self.getInit is None:
            return
        # Only update value every 3 seconds
        elif self.last_check is not None and time.time() < self.last_check + 3:
            return

        outputOn = self.getInit()
        # MOXA
        if shutil.which("mx-dio-ctl"):
            proc = os.popen("mx-dio-ctl -o 0")
            on = (proc.read().strip()[-1] == '0')
        # PI / ODYSSEY
        else:
            mbcli = ModbusClient('192.168.127.254', 502)
            for i in range(8):
                on = mbcli.read_holding_registers(2, 1)
                if on is not None:
                    break
            else:
                self.log("error", "light", "Failed to get the column light state.")
                return
            on = on == [1]   #reuse on var; convert to bool
        if outputOn is not None and ("off" if outputOn else "on") == self.status.strip().lower():
            self.last_check = time.time()
            return
        elif on and not self.flashing:
            self.log("warning", "light", "Setting Light state to OFF.")
            self.turnOff()
            self.last_check = time.time()
        else:
            self.log("warning", "light", "Setting Light state to ON.")
            self.turnOn()
            self.last_check = time.time()

    def start(self):
        pass

    def turnOn(self, flash=False):
        """Turn light on (stops flashing)"""
        if not flash:
            self.flashing = False
            time.sleep(0.1)
        if shutil.which("mx-dio-ctl"):
            os.system("mx-dio-ctl -o 0 -s 0 > /dev/null")
        else:
            mbcli = ModbusClient('192.168.127.254', 502)
            while not mbcli.write_single_register(2, 1):
                time.sleep(0.1)
            while not mbcli.write_single_register(3, 1):
                time.sleep(0.1)
            mbcli.close()
        if "ON" not in self.status:
            self.db.put("INSERT into light (timestamp, state)"\
                + " VALUES (%s, 0)" % (time.time()))
            if not flash:
                self.log('info', "light", "Light is now ON")
            self.status = "ON         "

    def turnOff(self, flash=False):
        """Turn light off (stops flashing)"""
        if not flash:
            self.flashing = False
            time.sleep(0.1)
        if shutil.which("mx-dio-ctl"):
            os.system("mx-dio-ctl -o 0 -s 1 > /dev/null")
        else:
            mbcli = ModbusClient('192.168.127.254', 502)
            while not mbcli.write_single_register(2, 0):
                time.sleep(0.1)
            while not mbcli.write_single_register(3, 0):
                time.sleep(0.1)
            mbcli.close()
        if "OFF" not in self.status:
            self.db.put("INSERT into light (timestamp, state)"\
                + " VALUES (%s, 1)" % (time.time()))
            if not flash:
                self.log('info', "light", "Light is now OFF")
            self.status = "OFF        "

    def flash(self, count=0):
        """Flashes light 'count' number of times and repeats"""
        self.flash_count = count
        self.flashing = True
        self.status = "\x1b[%d;%df%s" % (2 + self.rowoffset,
                                                  15 + self.columnoffset,
                                                  "FLASHING")
        t = threading.Thread(target=self.loopFlash, daemon=True)
        t.start()


    def loopFlash(self):
        timeOfLastChange = 0
        self.log('info', "light", "Light is now Flashing")
        if self.flash_count == 0:
            while self.flashing:
                if time.time() > timeOfLastChange + 2.4:
                    self.turnOn(True)
                    timeOfLastChange = time.time()
                elif time.time() > timeOfLastChange + 1.2:
                    self.turnOff(True)
        else:
            while self.flashing:
                for i in range(self.flash_count):
                    if time.time() > timeOfLastChange + 1.4:
                        self.turnOn(True)
                        timeOfLastChange = time.time()
                    elif time.time() > timeOfLastChange + 0.7:
                        self.turnOff(True)
                timeOfLastChange = time.time() + 4

