#!/usr/bin/python3

with open("/var/lib/EVARC/arcConfig.py") as f:
    exec(f.read())

print("\x1bc\n")
print(" " * 30 + "EVARC: " + str(config["arc"]))
print(" " * 25 + "IP Address: " + system["ip_addr"])
print(" " * 24 + "--------------------------")
print(" " * 31 + "GRID: " + system['grid'])
print(" " * 24 + "Shore Power: " + system['shore_power'])
print("\n" + " " * 26 + "Chargers: " + system['chargers'])
print(" " * 28 + "Motors: " + system['motors'])
print()
