#!/usr/bin/python3
import os
import time
import socket

MIN_COLS = 131
MIN_ROWS = 53

try:
    with open('/var/lib/EVARC/bg.txt') as f:
        HEADER = f.read()
    if 'EVE' in HEADER:
        MIN_ROWS = 58
except FileNotFoundError:
    print("EVARC is not running yet.")
    exit

bg_print = 0
serv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serv.connect(('127.0.0.1', 57896))
term_size = (0,0)

try:
    while True:
        # PRINT UPDATED OUTPUT
        cols, rows = os.get_terminal_size()
        if (cols < MIN_COLS or rows < MIN_ROWS):
            # PRINT DISPLAY ERROR
            print("\x1bcYour screen is size (%d x %d) is too small!" % (rows, cols))
            print("The minimum size is (%d x %d)." % (MIN_ROWS, MIN_COLS))
            print("\nPlease increase the size of your display.")
            bg_print = 0
            time.sleep(0.5)
        else:
            # PRINT DISPLAY
            if (time.time() > bg_print + 100):
                print("\x1bc"+HEADER)
                bg_print = time.time()
                data = serv.recv(2, socket.MSG_PEEK)
                while data != b'\x1b[':
                    serv.recv(2)
                    data = serv.recv(2, socket.MSG_PEEK)
            out = serv.recv(1024)
            if b'\x04' in out:
                print("\x1b[%d;0f\x1b[38;5;255m\nbye" % (MIN_ROWS-2))
                exit()
            print(out.decode(), end="")
except KeyboardInterrupt:
    print("\x1b[%d;0f\x1b[38;5;255m\nbye" % (MIN_ROWS-2))
