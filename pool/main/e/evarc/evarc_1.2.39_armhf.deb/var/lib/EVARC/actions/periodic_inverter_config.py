import os
import time
import threading
import traceback

PERIOD = 0
FLAG = "/home/service/invConfig"

class PeriodicInverterConfig:
    def __init__(self, inv, log, config):
        global PERIOD
        PERIOD = config['inverterConfigPeriod']
        #self.batt = batt          # battery object
        self.inv = inv            # inverter object
        # self.trk = trk            # solar tracker object
        # self.wtr = wtr            # weather object
        # self.db = db              # database logging
        self.log = log            # error logging
        self.runner = None        # thread of def runner
        self.running = False      # escape boolean
        self.lastCheck = 0        # timestamp for intermittent checking
        self.status = []          # lines of status output
        self.action_mask = 48     # mask indicates changes needed for corection
        self.invParams = None     # last inverter state
        self.starting = True
        if os.path.isfile(FLAG):
            with open(FLAG, 'r') as f:
                content = f.read()
                if content is None or content == "":
                    self.lastCheck = 0
                else:
                    self.lastCheck = float(content)
        else:
            self.lastCheck = 0

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if not self.running:
            if time.time() > self.lastCheck + PERIOD:
                self.status = ['Inverter Configuration']

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if (self.runner is None):
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.log("info", 'action-inv', "Setting Inverter Configuration")
        self.running = True
        try:
            time.sleep(20)
            self.inv.reqConfigure()
            self.lastCheck = time.time()
            with open(FLAG, 'w') as f:
                f.write(str(self.lastCheck))
            self.status = []
            self.running = False
            self.runner = None
        except Exception:
            self.log('critical', 'actions-inv', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch, MagicMock

    # Fake classes
    class inv:
        def __init__(self):
            self._configured = False
        def reqConfigure(self):
            self._configured = True
    log = MagicMock()

    conf = {
        "inverterConfigPeriod": 30
    }

    # Setup mocks
    fake_files = {}
    fake_time = [1000000]

    def advance_time(sec):
        nonlocal fake_time
        fake_time[0] += sec
        return fake_time[0]

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    with patch("builtins.open", side_effect=open_side_effect), \
         patch("time.time", side_effect=lambda: advance_time(1)), \
         patch("time.sleep", side_effect=advance_time):

        # Create objects
        i = inv()
        act = PeriodicInverterConfig(i, log, conf)

        act.lastCheck = 999999
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        act.lastCheck = 90
 
        act.check()
        assert act.status == ["Inverter Configuration"], "Expected active status, got "+str(act.status)
        assert not i._configured 

        act.do()
        act.runner.join()

        log.assert_any_call('info', 'action-inv', "Setting Inverter Configuration")
        assert i._configured 
        assert act.status == [], "Expected status == [], got "+str(act.status)

        print("✅ Pass: Periodic Inverter Config sequence completed")

if __name__=="__main__":
    main()

