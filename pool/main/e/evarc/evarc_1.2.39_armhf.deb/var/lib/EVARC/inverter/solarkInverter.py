#!/usr/bin/python3
import minimalmodbus
import time
import os
import traceback
import threading
import can
import cantools

FAULT_TABLE = {
    0: "DC_Inversed_Failure",
    1: "DC_Insulation_Failure",
    2: "GFDI_Failure",
    3: "GFDI_Ground_Failure",
    4: "EEPROM_Read_Failure",
    5: "EEPROM_Write_Failure",
    6: "GFDI_Fuse_Failure",
    7: "GFDI_Relay_Failure",
    8: "IGBT_Failure",
    9: "AuxPowerBoard_Failure",
    10: "AC_MainContactor_Failure",
    11: "AC_SlaveContactor_Failure",
    12: "Working_Mode_changed",
    13: "DC_OverCurr_Fault",
    14: "SW_AC_OverCurr_Fault",
    15: "GFCI_Failure",
    16: "Tz_COM_OC_Fault",
    17: "HW_Ac_OverCurr_Fault",
    18: "Tz_Integ_Fault",
    19: "Tz_Dc_OverCurr_Fault",
    20: "Tz_GFDI_OC_Fault",
    21: "Tz_EmergStop_Fault",
    22: "Tz_GFCI_OC_Fault",
    23: "DC_Insulation_ISO_Fault",
    24: "DC_Feedback_Fault",
    25: "BusUnbalance_Fault",
    26: "DC_Insulation_Fault",
    27: "DCIOver_M1_Fault",
    28: "AC_AirSwitch_Fault",
    29: "AC_MainContactor_Fault",
    30: "AC_SlaveContactor_Fault",
    31: "DCIOver_M2_Fault",
    32: "AC_OverCurr_Fault",
    33: "AC_Overload_Fault",
    34: "AC_NoUtility_Fault",
    35: "AC_GridPhaseSeque_Fault",
    36: "AC_Volt_Unbalance_Fault",
    37: "AC_Curr_Unbalance_Fault",
    38: "INT_AC_OverCurr_Fault",
    39: "INT_DC_OverCurr_Fault",
    40: "AC_WU_OverVolt_Fault",
    41: "AC_WU_UnderVolt_Fault",
    42: "AC_VW_OverVolt_Fault",
    43: "AC_VW_UnderVolt_Fault",
    44: "AC_UV_OverVolt_Fault",
    45: "Parallel_Aux_Fault",
    46: "AC_OverFreq_Fault",
    47: "AC_UnderFreq_Fault",
    48: "AC_U_GridCurr_DcHigh_Fault",
    49: "AC_V_GridCurr_DcHigh_Fault",
    50: "AC_W_GridCurr_DcHigh_Fault",
    51: "AC_A_InductCurr_DcHigh_Fault",
    52: "AC_B_InductCurr_DcHigh_Fault",
    53: "AC_C_InductCurr_DcHigh_Fault",
    54: "DC_VoltHigh_Fault",
    55: "DC_VoltLow_Fault",
    56: "AC_BackFeed_Fault",
    57: "AC_U_GridCurr_High_Fault",
    58: "AC_V_GridCurr_High_Fault",
    59: "AC_W_GridCurr_High_Fault",
    60: "AC_A_InductCurr_High_Fault",
    61: "AC_B_InductCurr_High_Fault",
    62: "Arc_Fault",
    63: "Heatsink_HighTemp_Fault"
}

SERIAL_SETTINGS = {
    'serial.baudrate': 9600,
    'serial.bytesize': 8,
    'serial.parity': "'N'",
    'serial.stopbit': 1,
    'serial.timeout': 0.4
}

# Modbus Reigisters [register, bytes, number_of_decimals, functioncode, signed]
READ_REGISTERS = {
    "mppt1_V":[109, 1, 3, False],
    "mppt1_A":[110, 1, 3, False],
    "mppt2_V":[111, 1, 3, False],
    "mppt2_A":[112, 1, 3, False],
    "mppt1_W":[186, 0, 3, False],
    "mppt2_W":[187, 0, 3, False],
    "grid_V_L1":[150, 1, 3, False],
    "grid_V_L2":[151, 1, 3, False],
    "grid_V_L1_L2":[152, 1, 3, False],
    "inv_V_L1":[154, 1, 3, False],
    "inv_V_L2":[155, 1, 3, False],
    "inv_V_L1_L2":[156, 1, 3, False],
    "grid_A_L1":[160, 2, 3, True],
    "grid_A_L2":[161, 2, 3, True],
    "inv_A_L1":[164, 2, 3, True],
    "inv_A_L2":[165, 2, 3, True],
    "grid_W_L1":[167,0, 3, True],
    "grid_W_L2":[168,0, 3, True],
    "grid_W_total":[169, 0, 3, True], # >0 buy, <0 sell
    "inv_W_L1":[173, 0, 3, True],  #inverted power
    "inv_W_L2":[174, 0, 3, True],  #inverted power
    "inv_W_total":[175,0, 3, True], #inverted power
    "output_W_L1":[176,0, 3, True],  #total output power
    "output_W_L2":[177,0, 3, True],  #total output power
    "output_W_total":[178,0, 3, True],  #total
    "output_A_L1":[179,2, 3, True],
    "output_A_L2":[180,2, 3, True],
    "temp":[182, 1, 3, False],
    "batt_V":[183, 2, 3, False],
    "batt_SOC":[184, 0, 3, False],
    "batt_A":[191, 2, 3, True],
    "batt_W":[190, 0, 3, True],
    "gen_relay_status":[195, 0, 3, False],
    "DC_temp":[90, 1, 3, False],
    "heat_sink_temp":[91, 1, 3, False],
    "fault1":[103, 0, 3, False],
    "fault2":[104, 0, 3, False],
    "fault3":[105, 0, 3, False],
    "fault4":[106, 0, 3, False],
    "equalization_V":[201, 2, 3, False],
    "absorb_V":[202, 2, 3, False],
    "float_V":[203, 2, 3, False],
    "shutDown_V":[220, 2, 3, False],
    "smartload_on":[238, 2, 3, False],
    "smartload_off":[236, 2, 3, False],
    "PV_today":[108, 1, 3, False],
    "load_today":[84, 1, 3, False],
    "grid_buy_today":[76, 1, 3, False],
    "grid_sell_today":[77, 1, 3, False],
    "batt_in_today":[70, 1, 3, False],
    "batt_out_today":[71, 1, 3, False],
    "load_total":[85, 2, 3, False],
    "PV_total":[96, 2, 3, False],
    "grid_buy_total":[78, 3, 3, False],
    "grid_sell_total":[81, 2, 3, False],
    "batt_in_total":[72, 2, 3, False],
    "batt_out_total":[74, 2, 3, False],
}

OUTPUT = {
    "mppt1_V":[2, 12],
    "mppt1_A":[2, 30],
    "mppt2_V":[3, 12],
    "mppt2_A":[3, 30],
    "mppt1_W":[2, 47],
    "mppt2_W":[3, 47],
    "grid_V_L1":[21, 17],
    "grid_V_L2":[21, 32],
    "grid_V_L1_L2":[21, 53],
    "inv_V_L1":[15, 17],
    "inv_V_L2":[15, 32],
    "inv_V_L1_L2":[15, 53],
    "grid_A_L1":[22, 17],
    "grid_A_L2":[22, 32],
    "inv_A_L1":[16, 17],
    "inv_A_L2":[16, 32],
    "grid_W_L1":[23, 17],
    "grid_W_L2":[23, 32],
    "grid_W_total":[23, 53],
    "inv_W_L1":[17, 17],
    "inv_W_L2":[17, 32],
    "inv_W_total":[17, 53],
    "output_W_L1":[11, 17],
    "output_W_L2":[11, 32],
    "output_W_total":[11, 53],
    "output_A_L1":[10, 17],
    "output_A_L2":[10, 32],
    "temp":[18, 47],
    "batt_V":[6, 12],
    "batt_SOC":[6, 66],
    "batt_A":[6, 30],
    "batt_W":[6, 47],
    "DC_temp":[18, 17],
    "heat_sink_temp":[18, 32],
    "PV_today":[2, 66],
    "load_today":[10, 53],
    "grid_buy_today":[24, 17],
    "grid_sell_today":[24, 32],
    "batt_in_today":[7, 32],
    "batt_out_today":[7, 53],
    "PV_total":[3, 66],
    "absorb_V": [18, 66],
    "smartload_on":[12, 17],
    "smartload_off":[12, 32],
    "gen_relay_status":[12, 53],
}

WRITE_REGISTERS = {
    "equalization_V": 201,
    "absorb_V": 202,
    "float_V": 203,
    "max_current": 210,
    "shutdown_V": 220,
    "restart_V": 221,
    "low_batt_V": 222,
    "smartload_off": 236,
    "smartload_on": 238,
}


# inverter class
class Inverter():
    def __init__(self, db, log, spn, conf):
        """Initialize new SolArk inverter"""
        self.db = db
        db.create("CREATE TABLE inv_status (id INTEGER PRIMARY KEY, timestamp"\
            + " CONVERT_TIMESTAMP, mppt1_V REAL, mppt1_A REAL, mppt2_V REAL,"\
            + " mppt2_A REAL, mppt1_W INTEGER, mppt2_W INTEGER, grid_V_L1 REAL,"\
            + " grid_V_L2 REAL, grid_V_L1_L2 REAL, inv_V_L1 REAL, inv_V_L2"\
            + " REAL, inv_V_L1_L2 REAL, grid_A_L1 REAL, grid_A_L2 REAL,"\
            + " inv_A_L1 REAL, inv_A_L2 REAL, grid_W_L1 INTEGER, grid_W_L2"\
            + " INTEGER, grid_W_total INTEGER, inv_W_L1 INTEGER, inv_W_L2"\
            + " INTEGER, inv_W_total INTEGER, output_W_L1 INTEGER, output_W_L2"\
            + " INTEGER, output_W_total INTEGER, output_A_L1 REAL, output_A_L2"\
            + " REAL, temp REAL, data_stuck INTEGER, batt_V REAL, batt_A REAL,"\
            + " batt_W INTEGER,"\
            + " gen_relay_status INTEGER, DC_temp REAL, heat_sink_temp REAL,"\
            + " absorb_V REAL, batt_SOC INTEGER, faults INTEGER)")
        db.create("CREATE TABLE inv_totals (id INTEGER PRIMARY KEY, timestamp"\
            + " CONVERT_TIMESTAMP, PV_today REAL, load_today REAL, grid_buy_today"\
            + " REAL, grid_sell_today REAL, batt_in_today REAL, batt_out_today"\
            + " REAL, load_total REAL, PV_total REAL, grid_buy_total REAL,"\
            + " grid_sell_total REAL, batt_in_total REAL, batt_out_total REAL)")
        self.log = log
        self.READ_REGISTERS = READ_REGISTERS # needed by heater.py
        self.spn = spn
        self.dcfc_iface = conf['dcfc_iface']
        self.dcfc_id = conf['dcfc_id']
        self.arc = conf['arc']
        self.trkNormal = None
        self.trkSafe = None
        self.trkClrEncoder = None
        self.actor = None
        self.lock = threading.Lock()
        self.stop = False
        self.last_write = 0
        self.write_interval = 30
        self.write_count = 0
        self.faults = None
        self.outputlen = 28
        self.outputwidth = 74
        self.rowoffset = 1
        self.columnoffset = 1
        self.data_stuck = 0
        self.stuck_start = 0
        self.temp_stuck = 0
        self.port = conf['inverter_iface']
        now = time.time()
        self.sent = {
            "equalization_V": (now, None),
            "absorb_V": (now, None),
            "float_V": (now, None),
            "max_current": (now, None),
            "shutdown_V": (now, None),
            "restart_V": (now, None),
            "low_batt_V": (now, None),
            "smartload_on": (now, None),
            "smartload_off": (now, None),
        }
        self.m = minimalmodbus.Instrument(self.port, 
                (self.dcfc_id if self.dcfc_id is not None else 1))
        for k,v in SERIAL_SETTINGS.items():
            exec("self.m.%s = %s" % (k, v))
        for k in READ_REGISTERS.keys():
            exec("self.%s = None"%(k))
        self.MAX_CHARGE_VOLTAGE = (None if 'maxChargeVoltage' not in conf.keys()
                                       else conf['maxChargeVoltage'])
        self.RECOVERY_CHARGE_VOLTAGE = None
        self.HEADER = """
   Solar
1 Voltage:          Current:           Power:           E today:
2 Voltage:          Current:           Power:           E total:

    Batteries
  Voltage:          Current:           Power:               SOC:
  TODAY  -        Energy In:            Energy Out:

    Output
  Current - L1:            L2:                LOAD:
  Power   - L1:            L2:               TOTAL:
  Smartload On:           Off:        Relay Status:

    Inverter
  Voltage - L1:            L2:               L1_L2:
  Current - L1:            L2:
  Power   - L1:            L2:               TOTAL:
  Tempera - DC:            HS:           AMB:          charge V:

    Grid
  Voltage - L1:            L2:               L1_L2:
  Current - L1:            L2:
  Power   - L1:            L2:               TOTAL:
  Energy - BUY:          SELL:"""


    def invParams(self):
        raise NotImplementedError

    def read_register(self, *register):
        """read modbus register with retries"""
        repeat_count = 0
        ret_value = None
        incomplete = True
        self.lock.acquire()
        while incomplete and repeat_count < 10:
            try:
                ret_value = self.m.read_register(*register)
                incomplete = False
            except Exception:
                repeat_count += 1
        self.lock.release()
        if ret_value is not None:
            self.data_stuck = 0
            self.stuck_start = time.time()
        elif self.data_stuck == 0 and (time.time() - self.stuck_start) > 30:
            self.data_stuck = 1
        return ret_value

    def write_register(self, register, value):
        """write modbus register with retries"""
        repeat_count = 0
        incomplete = True
        reg = WRITE_REGISTERS[register]
        if self.sent[register][0] > time.time() and \
           self.sent[register][1] == value:
            # already been set
            #self.log("debug", "inverter", "Write register prevented, value was previously set")
            return
        self.lock.acquire()
        while incomplete and repeat_count < 10:
            repeat_count += 1
            try:
                if type(value) is type([]):
                    self.m.write_registers(reg, value)
                else:
                    self.m.write_register(reg, value)
                incomplete = False
                self.sent[register] = (time.time() + 30, value)
            except minimalmodbus.NoResponseError:
                time.sleep(20)
            except Exception:
                # Check if values were set despite this exception
                e = reg if type(value) is not type([]) else reg + len(value)
                for i in range(reg, e):
                    if self.m.read_register(i) != (value[i-reg] if e != reg else value):
                        break
                else:
                    continue
                self.m = minimalmodbus.Instrument(self.port, 1)
                for k,v in SERIAL_SETTINGS.items():
                    exec("self.m.%s = %s" % (k, v))
                time.sleep(1)
        if repeat_count >= 10:
            self.log("error", "inverter", "Failed to write Modbus...timeout")
        self.lock.release()

    def getData(self):
        """collect data from inverter and saves it in class variables"""
        self.spn += 1
        for k,v in READ_REGISTERS.items():
            exec("self.%s = self.read_register(%s)" % (k,str(v)[1:-1]))
            if k == "output_A_L1":
                # these data are wrong need to be calculated from output_V
                if self.inv_V_L1 is None:
                    self.output_A_L1 = None
                elif self.inv_V_L1 == 0:
                    self.output_A_L1 = 0
                elif self.output_A_L1 is None:
                    pass
                else:
                    self.output_A_L1 = round(self.output_A_L1 * 100/self.inv_V_L1, 2)
            elif k == "output_A_L2":
                # these data are wrong need to be calculated from output_V
                if self.inv_V_L2 is None:
                    self.output_A_L2 = None
                elif self.inv_V_L2 == 0:
                    self.output_A_L2 = 0
                elif self.output_A_L2 is None:
                    pass
                else:
                    self.output_A_L2 = round(self.output_A_L2 * 100/self.inv_V_L2, 2)
            elif k[-4:] == 'temp':
                try:
                    exec("self.%s = round(self.%s - 100, 2)" % (k,k))
                except Exception:
                    exec("self.%s = None"%(k))

            time.sleep(0.05)

        if None not in [self.fault1, self.fault2, self.fault3, self.fault4]:
            self.faults = (self.fault4<<48) + (self.fault3<<32) + (self.fault2<<16) + self.fault1
        else:
            self.faults = None
        if self.faults is not None and self.faults != 0:
            self.log('error', "inverter", "Inverter Fault: %x %x %x %x"%(self.fault4, self.fault3, self.fault2, self.fault1))
        if self.dcfc_id is not None:
            # open CAN interface
            db = cantools.database.load_file(
                os.path.dirname(os.path.abspath(__file__)) + "/../dbc/DCFC_ARC_001.dbc")
            msg = db.encode_message('DCFC_Status_Msg', {"Source": self.dcfc_id, "Device": 1,
                "Inverter_Fault": (0 if self.faults is None or self.faults == 0 else 1),
                "Inverter_RelayState": self.gen_relay_status & 0x1,
                "Inverter_ChargeVoltage": self.absorb_V,
                "Inverter_SolarPower": min(self.mppt1_W + self.mppt2_W, 65535),
                "Inverter_BatteryCurrent": self.batt_A})
            self.log('warning', 'inverter', "Sending CAN message: "+str([int(i) for i in msg]))
            try:
                bus = can.interface.Bus(self.dcfc_iface, bustype='socketcan')
                bus.send(can.Message(arbitration_id=304, data=msg, is_extended_id=False))
            except Exception:
                os.system("sudo ip link set %s down"%(self.dcfc_iface))
                os.system("sudo ip link set %s up type can bitrate 80000"%(self.dcfc_iface))
                self.log('warning', "Inverter", "Restarted CAN interface")

    def saveData(self):
        """Write collected data to the database"""
        t = time.time()
        data = (t, self.mppt1_V, self.mppt1_A,
                self.mppt2_V, self.mppt2_A, self.mppt1_W,
                self.mppt2_W, self.grid_V_L1, self.grid_V_L2, self.grid_V_L1_L2,
                self.inv_V_L1, self.inv_V_L2, self.inv_V_L1_L2, self.grid_A_L1,
                self.grid_A_L2, self.inv_A_L1, self.inv_A_L2, self.grid_W_L1,
                self.grid_W_L2, self.grid_W_total, self.inv_W_L1, self.inv_W_L2,
                self.inv_W_total, self.output_W_L1, self.output_W_L2,
                self.output_W_total, self.output_A_L1, self.output_A_L2,
                self.temp, self.data_stuck, self.batt_V, self.batt_A,
                self.batt_W, self.gen_relay_status, self.DC_temp,
                self.heat_sink_temp, self.absorb_V, self.batt_SOC, self.faults)
        l_data = (t, self.PV_today, self.load_today,
                self.grid_buy_today, self.grid_sell_today, self.batt_in_today,
                self.batt_out_today, self.load_total, self.PV_total,
                self.grid_buy_total, self.grid_sell_total, self.batt_in_total,
                self.batt_out_total)
        if self.last_write == 0:
            self.last_write = t
        elif self.last_write + self.write_interval < t and None not in data:
            self.db.put(("INSERT INTO inv_status (timestamp, mppt1_V, mppt1_A,"\
                + " mppt2_V, mppt2_A, mppt1_W, mppt2_W, grid_V_L1, grid_V_L2,"\
                + " grid_V_L1_L2, inv_V_L1, inv_V_L2, inv_V_L1_L2, grid_A_L1,"\
                + " grid_A_L2, inv_A_L1, inv_A_L2, grid_W_L1, grid_W_L2,"\
                + " grid_W_total, inv_W_L1, inv_W_L2, inv_W_total,"\
                + " output_W_L1, output_W_L2, output_W_total, output_A_L1,"\
                + " output_A_L2, temp, data_stuck, batt_V, batt_A, batt_W,"\
                + " gen_relay_status, DC_temp, heat_sink_temp, absorb_V,"\
                + " batt_SOC, faults) VALUES (%f, %f, %f, %f, %f, %d, %d, %f,"\
                + " %f, %f, %f, %f, %f, %f, %f, %f, %f, %d, %d, %d, %d,"\
                + " %d, %d, %d, %d, %d, %f, %f, %f, %d, %f, %f, %d, %d, %f,"\
                + " %f, %f, %d, %d);") % data)
            self.last_write = t
            if self.write_count >= 20 and None not in l_data:
                self.interval_count = 0
                self.db.put(("INSERT INTO inv_totals (timestamp, PV_today,"\
                    + " load_today, grid_buy_today, grid_sell_today,"\
                    + " batt_in_today, batt_out_today, load_total, PV_total,"\
                    + " grid_buy_total, grid_sell_total, batt_in_total,"\
                    + " batt_out_total) VALUES (%f,%f,%f,%f,%f,%f,%f,%f,%f,"\
                    + " %f,%f,%f,%f)") % l_data)
            else:
                self.write_count += 1

    def showData(self):
        """Writes collected data to outputfile"""
        ret_value = ""
        for k in OUTPUT.keys():
            if eval("self."+k) is not None: 
                ret_value += "\x1b[%d;%df%s" % (OUTPUT[k][0]+self.rowoffset, 
                                                OUTPUT[k][1]+self.columnoffset, 
                                                eval("self."+k))
                if (k == "gen_relay_status"):
                    ret_value += " - " + ("closed" if (self.gen_relay_status % 2
                                                      ) > 0 else "open  ")
        ret_value += "\x1b[%d;%df%s" % (self.rowoffset+self.outputlen - 4,
                self.columnoffset+self.outputwidth - 2, self.spn)
        return ret_value

    def setParamsCallback(self, func):
        """create a callback function to get inverter settings per battery type"""
        self.invParams = func
        conf = func()
        if self.MAX_CHARGE_VOLTAGE is None:
            self.MAX_CHARGE_VOLTAGE = conf['charge_v']
        if self.RECOVERY_CHARGE_VOLTAGE is None:
            self.RECOVERY_CHARGE_VOLTAGE = conf['recov_v']

    def getFaults(self):
        """decodes faults returns a list of fault strings"""
        result = []
        if self.faults is not None and self.faults > 0:
            for bit,fault in FAULT_TABLE.items():
                if self.faults & (1<<bit):
                    result.append(fault)
        return result

    def reqConfigure(self):
        """Writes configurable inverter parameters"""
        if self.dcfc_iface is None:
            self.configure()
            return
        conf = self.invParams()
        # MAX_CHARGE_VOLATAGR may have been reduced for overcharge
        if self.MAX_CHARGE_VOLTAGE is None or conf['charge_v'] < self.MAX_CHARGE_VOLTAGE:
            self.MAX_CHARGE_VOLTAGE = conf['charge_v']
        self.RECOVERY_CHARGE_VOLTAGE = conf['recov_v']
        self.reqChargeVoltage(self.MAX_CHARGE_VOLTAGE)
        self.reqOperatingRange(conf['shutd_v'], conf['restart_v'], conf['low_bat'])
        self.reqOutputRange(conf['sl_off'], conf['sl_on'])
        self.reqChargeCurrent()

    def configure(self):
        """Writes configurable inverter parameters"""
        conf = self.invParams()
        # MAX_CHARGE_VOLATAGR may have been reduced for overcharge
        if self.MAX_CHARGE_VOLTAGE is None or conf['charge_v'] < self.MAX_CHARGE_VOLTAGE:
            self.MAX_CHARGE_VOLTAGE = conf['charge_v']
        self.RECOVERY_CHARGE_VOLTAGE = conf['recov_v']
        self.setChargeVoltage(self.MAX_CHARGE_VOLTAGE)
        self.setOperatingRange(conf['shutd_v'], conf['restart_v'], conf['low_bat'])
        self.setOutputRange(conf['sl_off'], conf['sl_on'])
        self.setChargeCurrent()

    def start(self):
        """Launch a thread to collect, record, and report the inverter data"""
        self.stop = False
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        """Method that performs collect, record and report inverter data"""
        while not self.stop:
            try:
                self.getData()
                self.saveData()
                if self.data_stuck:
                    time.sleep(60)
                else:
                    time.sleep(3)
            except Exception:
                self.log('critical', 'inverter', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")

    def setFaultCallback(self, callback):
        """Set a callback function to execute when a fault occurs"""
        self.faultHandler = callback

    def forceOutputOff(self):
        """Shuts off the inverter output by raising the smartload on and off up to float voltage"""
        self.setOutputRange(self.MAX_CHARGE_VOLTAGE + 2, self.MAX_CHARGE_VOLTAGE + 3)

    def reqChargeCurrent(self, current=None):
        """Set Max Charge Current"""
        if self.dcfc_iface is None:
            self.setChargeCurrent(current)
            return
        self.log('debug', 'inverter', 'Requesting charge current to %s' % current)
        # Create CAN message
        data = { "Source": self.arc,
                 "Command": 4,
                 "Argument1": current,
                 "Argument2": 0,
                 "Argument3": 0,
        }
        msg = db.encode_message('DCFC_Inverter_Msg', data)
        self.log('warning', 'inverter', "Sending CAN message: "+str([int(i) for i in msg]))
        try:
            bus = can.interface.Bus(self.dcfc_iface, bustype="socketcan")
            bus.send(can.Message(arbitration_id=288, data=msg, is_extended_id=False))
        except can.CanError:
            os.system("sudo ip link set %s down"%(self.dcfc_iface))
            os.system("sudo ip link set %s up type can bitrate 80000"%(self.dcfc_iface))
            self.log('warning', "Inverter", "Restarted CAN interface")

    def setChargeCurrent(self, current=None):
        """Set Max Charge Current"""
        self.write_register('max_current', (current if current is not None else 165))

    def setChargeVoltage(self, voltage=None, recovery=False):
        """Set the bus voltage for charging the batteries"""
        # set to 48.3V while batteries recover
        if voltage is None:
            voltage = self.MAX_CHARGE_VOLTAGE
        if recovery:
            voltage = self.RECOVERY_CHARGE_VOLTAGE
        voltage = max(voltage, self.RECOVERY_CHARGE_VOLTAGE)
        self.log('debug', 'inverter', 'Setting charge voltages to %s' % voltage)
        for reg in ['equalization_V',
                    'absorb_V',
                    'float_V']:
            self.write_register(reg, voltage * 100)

    def reqChargeVoltage(self, voltage=None, recovery=False):
        """Set the bus voltage for charging the batteries"""
        if self.dcfc_iface is None:
            self.setChargeVoltage(voltage, recovery)
            return
        # set to 48.3V while batteries recover
        if voltage is None:
            voltage = self.MAX_CHARGE_VOLTAGE
        if recovery:
            voltage = self.RECOVERY_CHARGE_VOLTAGE
        voltage = max(voltage, self.RECOVERY_CHARGE_VOLTAGE)
        self.log('debug', 'inverter', 'Requesting charge voltages to %s' % voltage)
        db = cantools.database.load_file(
            os.path.dirname(os.path.abspath(__file__)) + "/../dbc/DCFC_ARC_001.dbc")
        # Create CAN messages
        data = { "Source": self.arc,
                 "Command": 3,
                 "Argument1": voltage,
                 "Argument2": 0,
                 "Argument3": 0,
        }
        msg = db.encode_message('DCFC_Inverter_Msg', data)
        self.log('warning', 'inverter', "Sending CAN message: "+str([int(i) for i in msg]))
        try:
            bus = can.interface.Bus(self.dcfc_iface, bustype="socketcan")
            bus.send(can.Message(arbitration_id=288, data=msg, is_extended_id=False))
        except can.CanError:
            os.system("sudo ip link set %s down"%(self.dcfc_iface))
            os.system("sudo ip link set %s up type can bitrate 80000"%(self.dcfc_iface))
            self.log('warning', "Inverter", "Restarted CAN interface")

    def shutOffInverting(self):
        """Shuts off solar; prevents accidental charging when batteries are off"""
        # cause Low DC Fault on inverter by upping the shutdown voltage
        self.setOperatingRange(self.MAX_CHARGE_VOLTAGE+0.5,
                               self.MAX_CHARGE_VOLTAGE+1.0,
                               self.MAX_CHARGE_VOLTAGE+1.5)

    def reqOperatingRange(self, shut_v=None, restart_v=None, low_batt=None):
        """set inverter operating range by battery voltage thresholds"""
        if self.dcfc_iface is None:
            self.setOperatingRange(shut_v, restart_v, low_batt)
            return
        if shut_v is None or restart_v is None or low_batt is None:
            conf = self.invParams()
            shut_v = conf['shutd_v']
            restart_v = conf['restart_v']
            low_batt = conf['low_bat']
        self.log('debug', 'inverter', 'Requesting operating voltage range %s, %s, %s' % (
            shut_v, low_batt, restart_v))
        db = cantools.database.load_file(
            os.path.dirname(os.path.abspath(__file__)) + "/../dbc/DCFC_ARC_001.dbc")
        # Create CAN messages
        data = { "Source": self.arc,
                 "Command": 2,
                 "Argument1": shut_v,
                 "Argument2": restart_v,
                 "Argument3": low_batt,
        }
        msg = db.encode_message('DCFC_Inverter_Msg', data)
        self.log('warning', 'inverter', "Sending CAN message: "+str([int(i) for i in msg]))
        try:
            bus = can.interface.Bus(self.dcfc_iface, bustype="socketcan")
            bus.send(can.Message(arbitration_id=288, data=msg, is_extended_id=False))
        except can.CanError:
            os.system("sudo ip link set %s down"%(self.dcfc_iface))
            os.system("sudo ip link set %s up type can bitrate 80000"%(self.dcfc_iface))
            self.log('warning', "Inverter", "Restarted CAN interface")

    def setOperatingRange(self, shut_v=None, restart_v=None, low_batt=None):
        """set inverter operating range by battery voltage thresholds"""
        if shut_v is None or restart_v is None or low_batt is None:
            conf = self.invParams()
            shut_v = conf['shutd_v']
            restart_v = conf['restart_v']
            low_batt = conf['low_bat']
        self.log('debug', 'inverter', 'Setting operating voltage range %s, %s, %s' % (
            shut_v, low_batt, restart_v))
        myShutV = self.read_register(WRITE_REGISTERS['shutdown_V'])
        myResV = self.read_register(WRITE_REGISTERS['restart_V'])
        while None in [myShutV, myResV]:
            time.sleep(1)
            if myShutV is None:
                myShutV = self.read_register(WRITE_REGISTERS['shutdown_V'])
            if myResV is None:
                myResV = self.read_register(WRITE_REGISTERS['restart_V'])
        if myShutV > shut_v*100:
            self.write_register('shutdown_V', shut_v*100)
        if myResV < restart_v*100:
            self.write_register('restart_V', restart_v*100)
        self.write_register('low_batt_V', low_batt*100)
        self.write_register('restart_V', restart_v*100)
        self.write_register('shutdown_V', shut_v*100)

    def setOutputRange(self, sl_off=None, sl_on=None):
        """Sets smartload voltages"""
        if sl_off is None or sl_on is None:
            conf = self.invParams()
            sl_off = conf['sl_off']
            sl_on = conf['sl_on']
        self.log('debug', 'inverter', 'Setting output voltage range %s, %s' % (
            sl_off, sl_on))
        self.write_register('smartload_off', [int(sl_off*100), 20, int(sl_on*100)])

    def reqOutputRange(self, sl_off=None, sl_on=None):
        """Sets smartload voltages"""
        if self.dcfc_iface is None:
            self.setOutputRange(sl_off, sl_on)
            return
        if sl_off is None or sl_on is None:
            conf = self.invParams()
            sl_off = conf['sl_off']
            sl_on = conf['sl_on']
        self.log('debug', 'inverter', 'Requesting output voltage range %s, %s' % (
            sl_off, sl_on))
        db = cantools.database.load_file(
            os.path.dirname(os.path.abspath(__file__)) + "/../dbc/DCFC_ARC_001.dbc")
        # Create CAN messages
        data = { "Source": self.arc,
                 "Command": 1,
                 "Argument1": sl_off,
                 "Argument2": sl_on,
                 "Argument3": 0,
        }
        msg = db.encode_message('DCFC_Inverter_Msg', data)
        self.log('warning', 'inverter', "Sending CAN message: "+str([int(i) for i in msg]))
        try:
            bus = can.interface.Bus(self.dcfc_iface, bustype="socketcan")
            bus.send(can.Message(arbitration_id=288, data=msg, is_extended_id=False))
        except can.CanError:
            os.system("sudo ip link set %s down"%(self.dcfc_iface))
            os.system("sudo ip link set %s up type can bitrate 80000"%(self.dcfc_iface))
            self.log('warning', "Inverter", "Restarted CAN interface")

    def isOutputOn(self):
        """Returns true if Generator Relay Contactor is closed - Output is on"""
        if self.gen_relay_status is None:
            return None
        return self.gen_relay_status % 2 == 1

    def forceOutputOn(self):
        """Force smartload on and reset force smartload after timeout (minutes) and run callback"""
        conf = self.invParams()
        self.setOutputRange(45, 46)
        self.setOperatingRange(conf['shutd_v'], conf['shutd_v']+0.2, conf['shutd_v']+0.1)
        self.log('info', 'inverter', "Force output initiated!")


if __name__ == "__main__":
    class db:
        def create(self, s):
            pass
        def put(self, s):
            pass
    def log(level, device, message):
        if level == "debug":
                level = "\x1b[37m"
        elif level == "info":
                level = "\x1b[97m"
        elif level == "warning":
                level = "\x1b[93m"
        elif level == "error":
                level = "\x1b[91m"
        elif level == "critical":
                level = "\x1b[31m"
        print(level+"|"+device+"|"+message+"\033[0m")
    class spinner:
        def __init__(self, color):
            self.default = color
            self.i = -1
            self.j = -1
            self.v = ['o', 'O', '\x00\xb0']
            self.c = ["\x1b[38;5;160m", "\x1b[38;5;166m", "\x1b[38;5;220m",
                      "\x1b[38;5;47m", "\x1b[38;5;33m", "\x1b[38;5;93m"]
        def __add__(self, other):
            self.i = (self.i + 1) % len(self.v)
            self.j = (self.j + 1) % len(self.c)
            return self
    
        def __str__(self):
            return self.c[self.j]+self.v[self.i]+self.default
    #inv = Inverter(db(), log, spinner("\x1b[38;5;166m"), {"arc": 0, "inverter_iface": "/dev/ttyUSB0", "dcfc_iface": "can0", "dcfc_id": 1})
    inv = Inverter(db(), log, spinner("\x1b[38;5;166m"), {"arc": 0, "inverter_iface": "/dev/ttyUSB0", "dcfc_iface": None, "dcfc_id": None})
    inv.rowoffset = 4
    ## BEAM ##
    #inv.setParamsCallback(lambda: { "capacity": 860, "shutd_v": 49.5, "restart_v": 51.5, "low_bat": 48.4, "recov_v": 48.3, "charge_v": 57,
    #                                "shutd_c": 35, "restart_c": 65, "low_bat_c": 40, "sl_off": 51, "sl_on": 54.5 })
    ## Flux ##
    #inv.setParamsCallback(lambda: { "capacity": 840, "shutd_v": 50.5, "restart_v": 53.3, "low_bat": 51.0, "recov_v": 48.0, "charge_v": 54.8,
    #                                "shutd_c": 35, "restart_c": 65, "low_bat_c": 40, "sl_off": 51.5, "sl_on": 53.5 })
    ## EVE ##
    inv.setParamsCallback(lambda: {"capacity": 800, "shutd_v": 50.5, "restart_v": 53.3,
                            "low_bat": 51, "recov_v": 50, "charge_v": 54.5, "sl_off": 51.5, "sl_on": 53.5})
    inv.reqConfigure()
    inv.getData()
    print("\x1bc\x1b[3J"+inv.HEADER+"\n", flush=True)
    inv.start()
    count = 10
    while True:
        count += 1
        print(inv.showData(), flush=True)
        time.sleep(2)

