import os
import time
import threading
import traceback

FLAG = '/home/service/service'

class ServiceMode:
    def __init__(self, inv, log):
        # self.batt = batt     # battery object
        self.inv = inv       # inverter object
        # self.trk = trk       # solar tracker object
        # self.wtr = wtr       # weather object
        self.log = log       # error logging
        self.runner = None   # thread of the runner
        self.running = False # escape boolean
        self.status = []     # single line of status for output
        self.action_mask = 0xFF # mask indicates changes needed for corrective actions

        # action_mask is defined as follows:
        # ----------+---------+------------------------------------
        # |bit      |device   |areas of change
        # ----------+---------+------------------------------------
        # 0      1   tracker   conditiong (service mode)
        # 1      2   batt      revive | shutdown (contactor open)
        # 2      4   batt      heating
        # 3      8   batt      reserved
        # 4      16  inverter  output control (smartload)
        # 5      32  inverter  charge voltage
        # 6-7        inverter  reserved
        # ----------+---------+------------------------------------

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if not self.running:
            if os.path.exists(FLAG):
                self.status = ["System Service Mode"]
            else:
                self.status = []

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if (self.runner is None):
                self.runner = threading.Thread(target=self.run, daemon=True)
                self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        self.log('error', 'action-sm', 'Service Mode Activated')
        try:
            workingOnIt = True
            while self.running and workingOnIt:
                time.sleep(1)
                if os.path.exists(FLAG):
                    state = open(FLAG).read().strip()
                    if state.lower() == "done":
                        self.status = []
                        os.remove(FLAG)
                        workingOnIt = False
                else:
                    workingOnIt = False
            # Restore standard configuration
            self.inv.reqConfigure()
            self.status = []
            self.log('error', 'action-sm', 'Service Mode Deactivated')
            self.running = False
            self.runner = None
        except Exception:
            self.log('critical', 'action-sm', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch, mock_open

    # Setup mocks
    fake_time = [1000000]
    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    def advance_time(t):
        nonlocal fake_time
        fake_time[0] = fake_time[0] + t
        return fake_time[0]
    
    class inv:
        def __init__(self):
            self._output = False
        def reqConfigure(self):
            self._output = True

    def log(level, device, mesg):
        #print(mesg)
        pass

    with patch("os.path.isfile", side_effect=lambda path: path in fake_files), \
         patch("builtins.open", side_effect=open_side_effect), \
         patch("os.remove", side_effect=lambda path: fake_files.pop(path)), \
         patch("os.path.exists", side_effect=lambda path: path in fake_files), \
         patch("time.time", side_effect=lambda: fake_time[0]), \
         patch("time.sleep", side_effect=advance_time):

        # create objects
        i = inv()
        act = ServiceMode(i, log) 

        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert act.running == False


        f = open_side_effect(FLAG, 'w')
        f.write("On")

        act.check()
        assert len(act.status) > 0
        assert act.status == ["System Service Mode"], "Expected status == [\"System Service Mode\"], got "+str(act.status)

        act.do()
        assert(act.running)

        fake_files[FLAG].seek(0)
        fake_files[FLAG].write("Done")

        while act.running:
            pass
        act.check()
        #assert(i._output)
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running 
        print("✅ Pass: Service Mode sequence completed")

if __name__=="__main__":
    main()
 
