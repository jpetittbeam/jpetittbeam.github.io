#!/bin/sh

if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This script must be run as root." >&2
    exit 1
fi

# 1. Initialize a loop control variable
echo "ON_TIME=0\nOFF_TIME=0\nDUAL_HEAT=0" > /var/lib/EVARC/heating
keep_running=true

# 2. Define the signal handler function
cleanup() {
    keep_running=false
    /sbin/mx-dio-ctl -o 1 -s 1;
    /sbin/mx-dio-ctl -o 2 -s 1;
    /sbin/mx-dio-ctl -o 3 -s 1;
}

# 3. Register the trap for SIGINT (Ctrl+C) and SIGTERM (kill)
trap cleanup INT TERM

# 4. Use the variable as the loop condition
while $keep_running; do
    [ -f /var/lib/EVARC/heating ] && . /var/lib/EVARC/heating

    if [ $DUAL_HEAT -eq 7 ]; then
        echo "Turn ON heaters"
        /sbin/mx-dio-ctl -o 2 -s 0
        /sbin/mx-dio-ctl -o 1 -s 0
        /sbin/mx-dio-ctl -o 3 -s 0
        sleep $ON_TIME
        echo "Turn OFF heaters"
        /sbin/mx-dio-ctl -o 2 -s 1
        /sbin/mx-dio-ctl -o 1 -s 1
        /sbin/mx-dio-ctl -o 3 -s 1
        sleep $OFF_TIME
    else
        if [ "$((DUAL_HEAT & 2))" -ne 0 ]; then
            echo "Turn ON h1"
            /sbin/mx-dio-ctl -o 2 -s 0
            /sbin/mx-dio-ctl -o 1 -s 0
            sleep $ON_TIME
            echo "Turn OFF h1"
            /sbin/mx-dio-ctl -o 2 -s 1
            /sbin/mx-dio-ctl -o 1 -s 1
            sleep $OFF_TIME
        elif [ "$((DUAL_HEAT & 4))" -ne 0 ]; then
            echo "Turn ON h2"
            /sbin/mx-dio-ctl -o 3 -s 0
            /sbin/mx-dio-ctl -o 1 -s 0
	    sleep $ON_TIME
            echo "Turn OFF h2"
            /sbin/mx-dio-ctl -o 3 -s 1
            /sbin/mx-dio-ctl -o 1 -s 1
	    sleep $OFF_TIME
        elif [ "$DUAL_HEAT" -lt 2 ]; then
            sleep 3
        fi
    fi
done
