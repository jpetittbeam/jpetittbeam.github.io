#!/usr/bin/python3
import minimalmodbus
import os
import time
import sys

sys.path.insert(0, "/var/lib/EVARC/")
import arcConfig
sys.path.pop(0)

def main():
    restart_service = os.system("sudo systemctl is-active --quiet EVARC") == 0
    if restart_service:
        os.system("sudo systemctl stop EVARC")

    offset = [7.5, 9.5]
    if arcConfig.config['num_batteries'] == 4:
        offset = [0, 0.5]
    elif arcConfig.config['num_batteries'] == 6:
        offset = [3.75, 5.75]

    print("Initializing...")
    if os.system("sudo mx-dio-ctl -o 1 -s 1 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 2 -s 1 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 3 -s 1 2>&1 > /dev/null") != 0:
        raise Exception("Failed to turn off heating")
    time.sleep(1)
    baseline = 0
    for module in range(8):
        m = minimalmodbus.Instrument("/dev/ttyUSB0", module + 1)
        m.serial.baudrate = 9600
        incomplete = False
        repeat_count = 0
        while incomplete and repeat_count < 4:
            try:
                val = m.read_register(0,2, 3, True)
                if val is not None:
                    baseline += val
                    incomplete = False
                else:
                    repeat_count += 1
            except Exception:
                repeat_count += 1

    print("Baseline Current: " + str(baseline))

    print("Testinig Heater Bank 1 ...", end="")
    if os.system("sudo mx-dio-ctl -o 1 -s 0 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 2 -s 0 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 3 -s 1 2>&1 > /dev/null") != 0:
        raise Exception("Failed to turn on")
    time.sleep(1)

    current = 0
    for module in range(8):
        m = minimalmodbus.Instrument("/dev/ttyUSB0", module + 1)
        m.serial.baudrate = 9600
        incomplete = True
        repeat_count = 0
        while incomplete and repeat_count < 4:
            try:
                val = m.read_register(0,2, 3, True)
                if val is not None:
                    current -= val
                    #print("Current" + str(module) + ": " + str(val))
                    incomplete = False
                else:
                    repeat_count += 1
            except Exception:
                repeat_count += 1

    if baseline + 7.5 < current < baseline + 9.5:
        print("\x1b[38;5;10mPass\x1b[39m\x1b[49m")
    elif current < baseline + 7.5:
        print("\x1b[38;5;9mFail - too few heaters\x1b[39m\x1b[49m")
    elif current > baseline + 9.5:
        print("\x1b[38;5;9mFail - heater short\x1b[39m\x1b[49m")
    print("Current: " + str(current))

    if os.system("sudo mx-dio-ctl -o 1 -s 1 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 2 -s 1 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 3 -s 1 2>&1 > /dev/null") != 0:
        raise Exception("Failed to turn off heating")
    time.sleep(1)

    print("Testinig Heater Bank 2 ...", end="")
    if os.system("sudo mx-dio-ctl -o 1 -s 0 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 2 -s 1 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 3 -s 0 2>&1 > /dev/null") != 0:
        raise Exception("Failed to turn on")
    time.sleep(1)

    current = 0
    for module in range(8):
        m = minimalmodbus.Instrument("/dev/ttyUSB0", module + 1)
        m.serial.baudrate = 9600
        incomplete = True
        repeat_count = 0
        while incomplete and repeat_count < 4:
            try:
                val = m.read_register(0,2, 3, True)
                if val is not None:
                    #print("Current" + str(module) + ": " + str(val))
                    current -= val
                    incomplete = False
                else:
                    repeat_count += 1
            except Exception:
                repeat_count += 1

    if baseline + offset[0] < current < baseline + offset[1]:
        print("\x1b[38;5;10mPass\x1b[39m\x1b[49m")
    elif current < baseline + offset[0]:
        print("\x1b[38;5;9mFail - too few heaters\x1b[39m\x1b[49m")
    elif current > baseline + offset[1]:
        print("\x1b[38;5;9mFail - heater short\x1b[39m\x1b[49m")
    print("Current: " + str(current))

    if os.system("sudo mx-dio-ctl -o 1 -s 1 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 2 -s 1 2>&1 > /dev/null") != 0\
       or os.system("sudo mx-dio-ctl -o 3 -s 1 2>&1 > /dev/null") != 0:
        raise Exception("Failed to turn off heating")

    if restart_service:
        os.system("sudo systemctl start EVARC")

if __name__ == "__main__":
    main()


