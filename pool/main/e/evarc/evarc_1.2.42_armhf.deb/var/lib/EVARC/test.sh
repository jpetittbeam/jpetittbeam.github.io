#!/bin/bash
exec 3>&1 4>&2

# Batteries
#echo -n BEAM...
#ap
#pid=python3 battery/beamBattery.py 2>/tmp/err 1>/tmp/stdout &
#sleep 1; cansend vcan0 18FF4082#027D770401000000; cansend vcan0 08FF1020#A7BD4C373A0000C3; cansend vcan0 08FF1120#21344E34E57C00C3; cansend vcan0 0CFF2620#4947464646464646; cansend vcan0 0CFF2720#4748494946464646; cansend vcan0 08FF5020#C3534C373A000000; cansend vcan0 08FF5120#21344E34E57C0021; cansend vcan0 0CFF2680#4948464746464646; cansend vcan0 0CFF2780#4647484846464646; cansend vcan0 08FF5080#C4554C373A000000; cansend vcan0 08FF5180#1D345434FD7C0021; cansend vcan0 0CFF2682#4A49484848484747; cansend vcan0 0CFF2782#49494B4B48484849; cansend vcan0 0CFF2681#4B4A484948484849; cansend vcan0 0CFF2781#49494A4B48484849; cansend vcan0 359#0000000000504E00; cansend vcan0 351#3A020C16CA1A0000; cansend vcan0 355#55005E0000000000; cansend vcan0 356#5316EEFFAA000000; cansend vcan0 35C#0000000000000000; cansend vcan0 35E#0000000000000000; cansend vcan0 305#0000000000000000; cansend vcan0 18FF2582#00033C3800000181; cansend vcan0 18FF2581#00033C3900000052; cansend vcan0 08FF1080#ABBD4C373A0000C4; cansend vcan0 08FF1180#1D345434FD7C00C4; cansend vcan0 08FF1081#AABC4E393C0000C5; cansend vcan0 08FF1181#11345834F67C00C5; cansend vcan0 307#0000000000000000; cansend vcan0 0CFF2620#4947464646464646; cansend vcan0 0CFF2720#4748494946464646; cansend vcan0 18FF4020#E37C760401000000; cansend vcan0 0CFF2680#4948464746464646; cansend vcan0 0CFF2780#4647484846464646; cansend vcan0 0CFF2682#4A49484948484747; cansend vcan0 0CFF2782#49494B4B48484849; cansend vcan0 08FF5082#C6564D383C000000; cansend vcan0 08FF5182#3B344534037D0041; cansend vcan0 18FF2520#00033A3700000152; cansend vcan0 0CFF2681#4B4A494948484849; cansend vcan0 0CFF2781#49494A4B48484849; cansend vcan0 08FF5081#C5554E393C000000; cansend vcan0 08FF5181#11345834F77C0021; cansend vcan0 18FF2580#00033A3700000052; cansend vcan0 08FF1020#A7BD4C373A0000C3; cansend vcan0 08FF1120#22344E34E37C00C3; cansend vcan0 18FF4080#FE7C760401000000; cansend vcan0 0CFF2620#4947464746464646; cansend vcan0 0CFF2720#4748494946464646; cansend vcan0 08FF5020#C3534C373A000000; cansend vcan0 08FF5120#22344E34E37C0021; cansend vcan0 0CFF2680#4948464746464646; cansend vcan0 0CFF2780#4647484846464646; cansend vcan0 08FF5080#C4554C373A000000; cansend vcan0 08FF5180#1D345434FE7C0021; cansend vcan0 0CFF2682#4A49484948484747; cansend vcan0 0CFF2782#49494B4B48484849; cansend vcan0 0CFF2681#4B4A494948484849; cansend vcan0 0CFF2781#49494A4B48484849; cansend vcan0 18FF2582#00033C3800000181; cansend vcan0 18FF2581#00033C3900000052; cansend vcan0 08FF1080#ABBD4C373A0000C4; cansend vcan0 08FF1180#1D345434FD7C00C4; cansend vcan0 08FF1081#AABC4E393C0000C5; cansend vcan0 08FF1181#10345834F77C00C5; cansend vcan0 0CFF2620#4947464746464646; cansend vcan0 0CFF2720#4748494946464646; cansend vcan0 18FF4081#F77C760401000000; cansend vcan0 0CFF2680#4948464746464646; cansend vcan0 0CFF2780#4647484846464646; cansend vcan0 0CFF2682#4A49484948484747; cansend vcan0 0CFF2782#49494B4B48484849; cansend vcan0 08FF5082#C6564D383C000000; cansend vcan0 08FF5182#3B344534037D0041; cansend vcan0 18FF2520#00033A3700000152; cansend vcan0 0CFF2082#0400006868000004; cansend vcan0 0CFF2182#DB7C7704395802C6; cansend vcan0 18FF8082#DB7C112C8935; cansend vcan0 18FF8182#7704C71F81F31F81; cansend vcan0 18FF8282#4EFC37803C82FC; cansend vcan0 18FF8382#AB2E1BBC; cansend vcan0 18FF8482#F5113677062D3677; cansend vcan0 18FFD282#00373A0200010020; cansend vcan0 0CFF2681#4B49494948484849; cansend vcan0 0CFF2781#49494A4B48484849; cansend vcan0 08FF5081#C5554E393C000000; cansend vcan0 08FF5181#10345834F77C0021; cansend vcan0 18FF2580#00023A3700000052; cansend vcan0 18FF4082#037D770401000000; cansend vcan0 08FF1020#A7BD4C373A0000C3; cansend vcan0 08FF1120#22344E34E37C00C3; cansend vcan0 0CFF2620#4947464646464646; cansend vcan0 0CFF2720#4748494946464646; cansend vcan0 08FF5020#C3534C373A000000; cansend vcan0 08FF5120#22344E34E37C0021; cansend vcan0 0CFF2680#4948464746464646; cansend vcan0 0CFF2780#4647484846464646; cansend vcan0 08FF5080#C4554C373A000000; cansend vcan0 08FF5180#1D345434FF7C0021; cansend vcan0 0CFF2682#4A49484948484747; cansend vcan0 0CFF2782#49494B4B48484849; cansend vcan0 0CFF2681#4B49494948484849; cansend vcan0 0CFF2781#49494A4B48484849; cansend vcan0 359#0000000000504E00; cansend vcan0 351#3A020916C71A0000; cansend vcan0 355#55005E0000000000; cansend vcan0 356#5316EDFFAA000000; cansend vcan0 35C#0000000000000000; cansend vcan0 35E#0000000000000000; cansend vcan0 18FF2582#00033C3800000181; cansend vcan0 18FF2581#00033C3900000052; cansend vcan0 305#0000000000000000; cansend vcan0 08FF1080#ABBD4C373A0000C4; cansend vcan0 08FF1180#1D345334FC7C00C4; cansend vcan0 08FF1081#AABC4E393C0000C5; cansend vcan0 08FF1181#10345834F77C00C5; cansend vcan0 307#0000000000000000; cansend vcan0 0CFF2620#4947464646464646; cansend vcan0 0CFF2720#4748494946464646; cansend vcan0 0CFF2680#4948464746464646; cansend vcan0 0CFF2780#4647484846464646; cansend vcan0 18FF4020#E47C760401000000; cansend vcan0 0CFF2682#4A49484948484747; cansend vcan0 0CFF2782#49494B4B48484849; cansend vcan0 08FF5082#C6564D383C000000; cansend vcan0 08FF5182#3C344534057D0041; cansend vcan0 18FF2520#00033A3700000152; cansend vcan0 0CFF2681#4B4A484948484849; cansend vcan0 0CFF2781#49494A4B48484849; cansend vcan0 08FF5081#C5554E393C000000; cansend vcan0 08FF5181#10345834F77C0021; cansend vcan0 18FF2580#00023A3700000052; cansend vcan0 08FF1020#A7BD4C373A0000C3; cansend vcan0 08FF1120#22344E34E77C00C3; cansend vcan0 18FF4080#FD7C760401000000; cansend vcan0 0CFF2620#4947464746464646; cansend vcan0 0CFF2720#4748494946464646; sleep 1; kill -SIGINT $pid
#if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
#echo -n EVE...
#result=$( { python3 battery/eveBattery.py 2>&4 1>/dev/null; } 4>&1 )
#if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
#echo -n Flux...
#result=$( { python3 battery/fluxBattery.py 2>&4 1>/dev/null; } 4>&1 )
#if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
#echo
## Inverter
#echo -n Inverter...
#result=$( { python3 inverter/solarkInverter.py 2>&4 1>/dev/null; } 4>&1 )
#if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
#
## Tracker
#echo -n Tracker...
#result=$( { python3 tracker/lauritzenTracker.py 2>&4 1>/dev/null; } 4>&1 )
#if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
#
## Weather
#echo -n Weather...
#result=$( { python3 weather.py 2>&4 1>/dev/null; } 4>&1 )
#if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
#
## Light
#echo -n Light...
#result=$( { python3 light.py 2>&4 1>/dev/null; } 4>&1 )
#if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi

# Actions
echo
echo Actions...

## 
echo -n battery_balancing...
result=$( { python3 actions/battery_balancing.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n battery_fault...
result=$( { python3 actions/battery_fault.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n inverter_fault...
result=$( { python3 actions/inverter_fault.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n output_force_off...
result=$( { python3 actions/output_force_off.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n output_force_on...
result=$( { python3 actions/output_force_on.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n overcharge_voltage_reduction...
result=$( { python3 actions/overcharge_voltage_reduction.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n overcurrent...
result=$( { python3 actions/overcurrent.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n periodic_database_reduction...
result=$( { python3 actions/periodic_database_reduction.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n periodic_inverter_config...
result=$( { python3 actions/periodic_inverter_config.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n runaway_heater...
result=$( { python3 actions/runaway_heater.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n service_mode...
result=$( { python3 actions/service_mode.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n system_revive...
result=$( { python3 actions/system_revive.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n tracker_conditioning...
result=$( { python3 actions/tracker_conditioning.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi
echo -n tracker_revive...
result=$( { python3 actions/tracker_revive.py 2>&4 1>/dev/null; } 4>&1 )
if [ "$result" == "" ]; then echo PASS; else echo FAIL; echo $result; fi

exec 3>&- 4>&-
