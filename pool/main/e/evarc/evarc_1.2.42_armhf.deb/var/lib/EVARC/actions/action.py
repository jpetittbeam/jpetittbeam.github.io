import time
import threading
import traceback

PERIOD = 0

class action:
    def __init__(self, batt, inv, trk, wtr, db, log):
        self.batt = batt     # battery object
        self.inv = inv       # inverter object
        self.trk = trk       # solar tracker object
        self.wtr = wtr       # weather object
        self.db = db         # database logging
        self.log = log       # error logging
        self.runner = None   # thread of the runner
        self.running = False # escape boolean
        self.lastCheck = 0   # timestamp for intermittent checking
        self.status = []     # single line of status for output
        self.action_mask = 0 # mask indicates changes needed for corrective actions

        # action_mask is defined as follows:
        # ----------+---------+------------------------------------
        # |bit      |device   |areas of change
        # ----------+---------+------------------------------------
        # 0      1   tracker   conditiong (service mode)
        # 1      2   batt      revive | shutdown (contactor open)
        # 2      4   batt      heating
        # 3      8   batt      reserved
        # 4      16  inverter  output control (smartload)
        # 5      32  inverter  charge voltage
        # 6-7        inverter  reserved
        # ----------+---------+------------------------------------

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if time.time() > self.lastCheck + PERIOD:
            self.lastCheck = time.time()
            #perform check
        raise NotImplementedError

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if self.runner is None:
            try:
                self.runner = threading.Thread(target=self.run, daemon=True)
                self.runner.start()
            except Exception:
                self.log('critical', 'action', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        try:
            self.running = True
            # Perform confirgurtaion changes
            while self.running:
                # Perform updates as needed
                raise NotImplementedError
            # Restore standard configuration
        except Exception:
            self.log('critical', 'action-xx', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

    


