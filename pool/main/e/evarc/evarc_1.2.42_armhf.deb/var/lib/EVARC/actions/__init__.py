import time
import traceback
import threading
import arcConfig
import actions.battery_balancing as battery_balancing
import actions.cold_conditioning as cold_conditioning
import actions.output_force_off as output_force_off
import actions.output_force_on as output_force_on
import actions.overcurrent as overcurrent
import actions.runaway_heater as runaway_heater
import actions.battery_fault as battery_fault
import actions.inverter_fault as inverter_fault
import actions.overcharge_voltage_reduction as overcharge_voltage_reduction
import actions.periodic_inverter_config as periodic_inverter_config
import actions.periodic_database_reduction as periodic_database_reduction
import actions.tracker_conditioning as tracker_conditioning
import actions.tracker_revive as tracker_revive
import actions.service_mode as service_mode
import actions.system_revive as system_revive

class Actor:
    def __init__(self, batt, inv, trk, wtr, db, log):
        """Constructor"""
        config = arcConfig.action
        self.log = log
        self.db = db
        db.create("CREATE TABLE actions (id INTEGER PRIMARY KEY, timestamp"\
            + " CONVERT_TIMESTAMP, actions TEXT)")
        self.sql = "INSERT INTO actions (timestamp, actions) VALUES (%f, '%s')"
        self.HEADER = """Actions:"""
        self.ouputlen = 4
        self.columnoffset = 0
        self.rowoffset = 0
        self.status = ""
        self.stop = False
        self.runner = None
        # Precipitators of change; ordered highest priority to lowest
        if arcConfig.config['dcfc_iface'] is None:
            self.acts = [ 
                runaway_heater.RunawayHeater(batt, inv, log, config),
                output_force_off.OutputForceOff(inv, log),
                output_force_on.OutputForceOn(inv, log),
                service_mode.ServiceMode(inv, log),
                overcurrent.Overcurrent(inv, log, config),
                tracker_conditioning.TrackerConditioning(batt, trk, log, config),
                cold_conditioning.ColdConditioning(batt, inv, trk, wtr, log, config),
                system_revive.SystemRevive(batt, inv, trk, wtr, log, config),
                overcharge_voltage_reduction.OverchargeVoltageReduction(batt, inv, log, config),
                inverter_fault.InverterFault(inv),
                battery_fault.BatteryFault(batt),
                battery_balancing.Balancing(batt, inv, log, config),
                tracker_revive.TrackerRevive(trk, log, config),
                periodic_inverter_config.PeriodicInverterConfig(inv, log, config),
                periodic_database_reduction.PeriodicDatabaseReduction(db, log, config),
            ]
        else:
            self.acts = [ 
                output_force_off.OutputForceOff(inv, log),
                output_force_on.OutputForceOn(inv, log),
                service_mode.ServiceMode(inv, log),
                inverter_fault.InverterFault(inv),
                battery_fault.BatteryFault(batt),
                battery_balancing.Balancing(batt, inv, log, config),
                tracker_revive.TrackerRevive(trk, log, config),
                periodic_inverter_config.PeriodicInverterConfig(batt, inv, log, config),
                periodic_database_reduction.PeriodicDatabaseReduction(db, log, config),
            ]

    def getData(self):
        """Collect actions that need attention"""
        action_mask = 0
        k = 0
        next_status = ""
        for i in self.acts:
            #self.log("debug", "actions", "Checking: "+str(i))
            i.check()
            if i.status != []:
                for j in i.status:
                    next_status += "\x1b[%d;%df%s" % (self.rowoffset + k % 5,
                         (2 if k < 5 else (46 if k < 10 else 90) + self.columnoffset),
                         str(k+1) + ("->" if i.running else ". ") + j[:40])
                    k += 1
                if (action_mask & i.action_mask) == 0:
                    if not i.running:
                        self.log("info", "actions", "Starting: "+str(i))
                        i.do()
                    action_mask += i.action_mask
                elif i.running:
                    self.log("info", "actions", "Stopping: "+str(i))
                    i.running = False
        self.status = next_status

    def saveData(self):
        """Record data to the database"""
        db_entry = ""
        for i in self.acts:
            if len(i.status):
                for j in i.status:
                    db_entry += j + ", "
        if len(db_entry) > 3:
            self.db.put(self.sql % (time.time(), db_entry))

    def showData(self):
        """Output for user interface"""
        clear = "\x1b[%d;%df" % (self.rowoffset, 1)
        clear += "\x1b[2K\n\x1b[2K\n\x1b[2K\n\x1b[2K\n\x1b[2K"
        return clear + self.status
 
    def start(self):
        """Launch a thread to collect, record and report the action data"""
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        """Method that performs actions and report the actions data"""
        while not self.stop:
            try:
                self.getData()
                self.saveData()
            except Exception:
                self.log('critical', 'actions', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")
            time.sleep(1)

def main():
    global m
    class batt:
        def __init__(self):
            self.faults = [0, 0, 0, 0, 0]
        def getFaults(self):
            return ["Batt 1: no good"]
    class inv:
        def __init__(self):
            self.faults = 0
        def getFaults(self):
            return ["Inverter is no good"]
    class trk:
        def __init__(self):
            self.sun_el = 30
            self.service = "Off"
        def normal(self):
            self.service = "Off"
        def safe(self):
            self.service = "On"
    class wtr:
        def __init__(self):
            wtr.sunny = False
    def log(level, device, mesg):
        global m
        m = mesg
    class db:
        def put(self, sql):
            pass
        def create(self, sql):
            pass

    b = batt()
    i = inv()
    t = trk()
    w = wtr()
    act = Actor(b, i, t, w, db, log)

    count = 0
    while True:
        if count == 0:
            print(act.HEADER)
        act.getData()
        print(act.showData(), end="")
        count += 1
        if count > 60:
            count = 0

if __name__=="__main__":
    main()
