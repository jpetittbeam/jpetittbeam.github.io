#!/usr/bin/python3
import can
import cantools
import time
import os
import traceback
import threading

BATTERY_PACK_ADDRESSES = range(4)
FAULT_TABLE = {
        0: "ESS_Mod_Flag_EWS",
        1: "ESS_Mod_Flag_Warning",
        2: "ESS_Mod_Flag_Full_Load",
        3: "ESS_Mod_Flag_Error",
        4: "DTC_State_Critically_Low_Battery",
        5: "DTC_State_Wrong_Charger",
        6: "DTC_State_Hardware_Failure",
        7: "DTC_State_High_Low_Temp",
        8: "DTC_State_Current_Exceeded",
        9: "DTC_State_Voltage_Imbalance",
        12: "Contactor_Flag_Sleep_Contactor",
        13: "Contactor_Flag_Voltage_Low",
        14: "Contactor_Flag_Integrity_Signal",
        15: "Contactor_Flag_EWS_Latched",
        16: "Contactor_Flag_Contactor_Line_Err",
        20: "Contactor_Flag_Communications",
        21: "Contactor_Flag_SoC",
        22: "Contactor_Flag_Temperature",
        23: "Contactor_Flag_Voltage_High",
        24: "Contactor_Flag_Current",
        25: "Contactor_Flag_Charging",
        26: "Contactor_Flag_Hardware_Fault",
        27: "Contactor_Flag_AC_Detected",
        28: "Safety_Violation_Overdischarged",
        36: "Safety_Violation_Divide_by_zero",
        37: "Safety_Violation_Welded_Contactor",
        38: "Safety_Violation_Flash_CRC_Fail",
        39: "Safety_Violation_Volatile_Memory",
        40: "Safety_Violation_Stack_Overflow",
        41: "Safety_Violation_Crystal_Error",
        42: "Safety_Violation_Flash_CRC_Addr_Invalid",
        43: "Safety_Violation_Dropped_Node"
}

def first_not_none_value(d: list):
    for i in d:
        if i is not None:
            return i
    return None

# battery class
class Battery:
    def __init__(self, db, log, spn, conf):
        """Initialize new Flux battery"""
        self.iface = conf['battery_iface']
        self.num_batteries = conf['num_batteries']
        self.db = db
        self.log = log
        self.spn = spn
        db.create("CREATE TABLE battery (id INTEGER PRIMARY KEY, timestamp"\
            + " CONVERT_TIMESTAMP, battery INTEGER, current REAL, soc REAL,"\
            + " bms_temp REAL, faults INTEGER, voltage REAL, min_voltage REAL,"\
            + " max_voltage REAL, max_temp REAL, min_temp REAL, contactor"\
            + " INTEGER, heater INTEGER, state INTEGER);")
            
        self.lock = threading.Lock()
        self.type = "Flux"
        self.stop = False
        self.can_db = cantools.database.load_file(
            os.path.dirname(os.path.abspath(__file__)) + "/../dbc/Flux_BMS_External_CAN.dbc"
        )
        if "can" in self.iface:
            self.bus = can.interface.Bus(self.iface, bustype="socketcan")
        elif "tty" in self.iface:
            self.bus = can.interface.Bus(bustype='seeedstudio', channel=self.iface, bitrate=125000)
        else:
            raise Exception("CAN Interface is not defined!")
        self.reconnect = True
        self.battery_count = 0
        self.outputlen = 21
        self.rowoffset = 0
        self.NON_RECOVERABLE_FAULTS = 0x7FFF0000000
        self.MIN_CELL_BAL_CHECK = 3.6
        self.HEADER = "BAT"+\
"""T1:                          BATT2:                          BATT3:                          BATT4:                      """ + \
        str(conf['num_batteries']) + """ Flux
  VOLTAGE:                        VOLTAGE:                        VOLTAGE:                        VOLTAGE:                  ------
     MIN :                           MIN :                           MIN :                           MIN :
     MAX :                           MAX :                           MAX :                           MAX :

  CURRENT:                        CURRENT:                        CURRENT:                        CURRENT:
  CONTACT:                        CONTACT:                        CONTACT:                        CONTACT:
   HEATER:                         HEATER:                         HEATER:                         HEATER:
      SOC:                            SOC:                            SOC:                            SOC:

 TEMPERAT:                       TEMPERAT:                       TEMPERAT:                       TEMPERAT:
     MIN :                           MIN :                           MIN :                           MIN :
     MAX :                           MAX :                           MAX :                           MAX :
     BMS :                           BMS :                           BMS :                           BMS :

    STATE:                          STATE:                          STATE:                          STATE:
   FAULTS:                         FAULTS:                         FAULTS:                         FAULTS:
"""
        self.batt_id = [i for i in range(1,5)]
        self.heat_group = [0, 0]
        self.soc = [None] * 4
        self.bms_temp = [None] * 4
        self.min_temp = [None] * 4
        self.max_temp = [None] * 4
        self.state = [None] * 4
        self.faults = [None] * 4
        self.voltage = [None] * 4 
        self.min_voltage = [None] * 4
        self.max_voltage = [None] * 4
        self.current = [None] * 4
        self.heater = [None] * 4
        self.contactor = [None] * 4
        self.messages_collected = {}
        for i in BATTERY_PACK_ADDRESSES:
            self.messages_collected[0x181 + i] = False
            self.messages_collected[0x281 + i] = False
            self.messages_collected[0x701 + i] = False
        self.last_sent = None
        self.runner = None

    def getData(self):
        """collect data from batteries and save it in class"""
        max_messages = 100
        msg_count = 0
        try:
            msg = self.bus.recv(10)  # 10 second timeout
            if msg is None:
                raise can.CanError
        except can.CanError:
            if 'can0' in self.iface:
                os.system("sudo ip link set %s down"%(self.iface))
                os.system("sudo ip link set %s up type can bitrate 125000"%(self.iface))
                self.bus = can.interface.Bus(self.iface, bustype="socketcan")
                self.log('warning', "Battery", "Restarted CAN interface")
            else:
                self.log('warning', "Battery", "CAN interface not working, cannot reset.")

        self.spn += 1
        for msg in self.bus:
            if msg_count > max_messages:
                msg_count = 0
                break
            else:
                msg_count += 1
            if 0x180 < msg.arbitration_id < 0x185:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id - 0x181 
                self.min_voltage[i] = res["Lowest_Cell_Volt"]
                self.max_voltage[i] = res["Highest_Cell_Volt"]
                self.bms_temp[i] = res["Board_Temperature"]
                self.soc[i] = res["State_of_Charge"]
                self.voltage[i] = res["Pack_Voltage"]
                self.current[i] = res["Current"]
                self.messages_collected[msg.arbitration_id] = True
            elif 0x280 < msg.arbitration_id < 0x285:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id - 0x281 
                self.contactor[i] = res["Contactor_Position"]
                self.heater[i] = res["Heater_State"]
                self.min_temp[i] = res["Lowest_Cell_Temp"]
                self.max_temp[i] = res["Highest_Cell_Temp"]
                self.faults[i] = (int.from_bytes(msg.data,'little') >> 4) & 0xFFFFFFFFFFF 
                self.messages_collected[msg.arbitration_id] = True
                if self.faults[i] > 0 and not self.fault_mask:
                    t = threading.Thread( target=self.faultHandler, args=(self.faults,), daemon=True)
                    t.start()
            elif 0x700 < msg.arbitration_id < 0x705:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id - 0x701
                self.state[i] = res["FluxTelemetry_State"]
                self.messages_collected[msg.arbitration_id] = True

    def saveData(self):
        """write collected data to the database"""
        if not all(self.messages_collected.values()):
            battery_count = 0
            missing_batteries = 0
            for i in BATTERY_PACK_ADDRESSES:
                if all([
                   self.messages_collected[0x181 + i],
                   self.messages_collected[0x281 + i],
                   self.messages_collected[0x701 + i]]):
                    battery_count += 1
                elif not any([
                   self.messages_collected[0x181 + i],
                   self.messages_collected[0x281 + i],
                   self.messages_collected[0x701 + i]]):
                    missing_batteries += 1
                    self.current[i] = None
                    self.soc[i] = None
                    self.bms_temp[i] = None
                    self.faults[i] = None
                    self.voltage[i] = None
                    self.min_voltage[i] = None
                    self.max_voltage[i] = None
                    self.max_temp[i] = None
                    self.min_temp[i] = None
                    self.contactor[i] = None
                    self.heater[i] = None
                    self.state[i] = None
                else:
                    return
            self.battery_count = battery_count
        else:
            self.battery_count = 4
        self.lock.acquire()
        if self.current is None:
            raise Exception("Data cleared before reported")
        t = time.time()
        for i in range(4):
            if self.battery_count == 4 or self.current[i] is not None:
                sql = (
                   ("INSERT INTO battery (timestamp, battery, current, soc,"\
                   + " bms_temp, faults, voltage, min_voltage,"\
                   + " max_voltage, max_temp, min_temp, contactor,"\
                   + " heater, state) VALUES (%f, %d, %f, %d, %f, %d, %f, %f,"\
                   + " %f, %f, %f, %d, %d, %d);") % (
                        t,
                        self.batt_id[i],
                        self.current[i],
                        self.soc[i],
                        self.bms_temp[i],
                        self.faults[i],
                        self.voltage[i],
                        self.min_voltage[i],
                        self.max_voltage[i],
                        self.max_temp[i],
                        self.min_temp[i],
                        self.contactor[i],
                        self.heater[i],
                        self.state[i],
                    )
                )
                self.db.put(sql)

        for i in BATTERY_PACK_ADDRESSES:
            self.messages_collected[0x181 + i] = False
            self.messages_collected[0x281 + i] = False
            self.messages_collected[0x701 + i] = False

        self.lock.release()

    def showData(self):
        """Writes collected data to outputfile"""
        ret_value = ""
        col = [12, 44, 76, 108]
        for i in range(4):
            if self.voltage[i] is not None:
                ret_value += "\x1b[%d;%df%4.2f" % (self.rowoffset + 2,
                                                  col[i], self.voltage[i])
            if self.min_voltage[i] is not None:
                ret_value += "\x1b[%d;%df%4.3f" % (self.rowoffset + 3,
                                                  col[i], self.min_voltage[i])
            if self.max_voltage[i] is not None:
                ret_value += "\x1b[%d;%df%4.3f" % (self.rowoffset + 4,
                                                  col[i], self.max_voltage[i])
            if self.current[i] is not None:
                ret_value += "\x1b[%d;%df%3.2f" % (self.rowoffset + 6,
                                                  col[i], self.current[i])
            if self.contactor[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 7,
                                                  col[i], self.contactor[i])
            if self.heater[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 8,
                                                  col[i], self.heater[i])
            if self.soc[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 9,
                                                  col[i], self.soc[i])
            if self.min_temp[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 12,
                                                  col[i], self.min_temp[i])
            if self.max_temp[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 13,
                                                  col[i], self.max_temp[i])
            if self.bms_temp[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 14,
                                                  col[i], self.bms_temp[i])
            if self.state[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 16,
                                                  col[i], self.state[i])
            if self.faults[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 17,
                                                  col[i], self.faults[i])
        ret_value += "\x1b[%d;%df%s" % (self.outputlen - 3, 129, self.spn)
        return ret_value

    def getFaults(self):
        """decodes faults returns a list of fault strings"""
        result = []
        for i in range(4):
            for bit,fault in FAULT_TABLE.items():
                if self.faults[i] is not None and self.faults[i] & (1<<bit):
                    result.append("Battery %s: %s"%(self.batt_id[i], fault))
        return result

    def getInvParams(self, summer):
        """returns inverter configuratins for this battery configuration"""
        if summer:
            if self.battery_count > 3:
                return { "capacity": 840, "shutd_v": 50.5, "restart_v": 53.3,
                        "low_bat": 51, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 51.5, "sl_on": 53.5}
            elif self.battery_count > 2:
                return { "capacity": 630, "shutd_v": 50.5, "restart_v": 53.3,
                        "low_bat": 51, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 51.5, "sl_on": 53.8}
            elif self.battery_count > 1:
                return { "capacity": 420, "shutd_v": 50.5, "restart_v": 53.3,
                        "low_bat": 51, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 51.5, "sl_on": 54.1}
            else:
                return { "capacity": 0, "shutd_v": 47, "restart_v": 53.3,
                        "low_bat": 47.5, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 59, "sl_on": 59.5}
        else:
            if self.battery_count > 3:

                return { "capacity": 840, "shutd_v": 51.0, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 52, "sl_on": 54.3}
            elif self.battery_count > 2:
                return { "capacity": 630, "shutd_v": 51.0, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 52, "sl_on": 54.5}
            elif self.battery_count > 1:
                return { "capacity": 420, "shutd_v": 51.0, "restart_v": 53.6,
                        "low_bat": 51.5, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 52, "sl_on": 54.7}
            else:
                return { "capacity": 0, "shutd_v": 55, "restart_v": 53.6,
                        "low_bat": 47.5, "recov_v": 48, "charge_v": 54.8,
                        "sl_off": 59, "sl_on": 59.5}


    def getStatus(self, ignores=[]):
        """Returns true if the batteries are in recovery state"""
        ret_value = []
        for i in range(4):
            if i not in ignores and (
               (self.state[i] is not None and self.state[i] != 5) or
               (self.faults[i] is not None and (
                   self.faults[i] & self.NON_RECOVERABLE_FAULTS))
               ):
                ret_value.append("Disconnected %d" %  (i))
        # check for Low Voltage
        b = [i for i in range(4) if \
                self.batt_id[i] not in ignores and \
                self.faults[i] is not None and \
                self.faults[i] >> 4 & 1]
        if b != []:
            ret_value += ["Low Voltage - "+str(b)]
        # check for Low Temperature
        b = [i for i in range(4) if \
                self.batt_id[i] not in ignores and \
                self.faults[i] is not None and \
                self.faults[i] >> 7 & 1]
        if b != []:
            ret_value += ["Temperature - "+str(b)]
        return ret_value

    def setBusVCallback(self, busV):
        """callback is provided to get inverter bus voltage setting"""
        pass

    def sendShutdown(self):
        pass

    def recover(self, batt, recovery=False):
        """Request batteries to transition to recovery mode (recovery=False to exit recovery)"""
        if self.last_sent[batt][0] == self.heat_group[batt%2] and time.time() - self.last_sent[batt][1] < 300:
            # already set value so do nothing
            return
        if recovery:
            self.bus.send(can.Message(arbitration_id=700+batt, data=[
                                      0xEC, 1, 1, self.heat_group[batt%2], 0, 0, 0, 0xFB]))
            self.last_sent[batt] = (self.heat_group[batt%2], time.time())
        self.bus.send(can.Message(arbitration_id=0x00,
                                  data=[
                                      (0x02 if recovery else 0x01), 
                                      batt],
                                  is_extended_id=False))

    def setFaultCallback(self, func):
        """Set a callback function to handle battery faults"""
        self.faultHandler = func

    def start(self):
        """Launch a thread to collect, record and report the battery data"""
        self.stop = False
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        """Method that performs collect, record and report the battery data"""
        while not self.stop:
            try:
                self.getData()
                self.saveData()
                time.sleep(3)
            except Exception:
                self.log('critical', 'battery', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")


if __name__ == "__main__":
    def log(device, level, msg):
        print("|%s| (%s) - %s" % (device, level, msg))

    class db:
        def create(self, s):
            pass
        def put(self, s):
            pass
    class s:
        def __add__(self, i):
            return self
        def __str__(self):
            return '-'

    b = Battery(db(), log, s(), {'battery_iface': 'can0', 'num_batteries': 4})
    b.fault_mask = True
    b.start()
    count = 20
    while True:
        if count >= 20:
            print("\033c\033[3J\x1b7\x1b[%d;1f"%(1)+b.HEADER+"\n\x1b8")
            count = 0
        count += 1
        print(b.showData(), flush=True)
        time.sleep(0.5)
