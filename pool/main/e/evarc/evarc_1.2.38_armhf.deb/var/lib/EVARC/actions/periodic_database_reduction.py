import os
import time
import threading
import traceback

PERIOD = 0
FLAG = "dbReduced"

class PeriodicDatabaseReduction:
    def __init__(self, db, log, config):
        global PERIOD
        PERIOD = config['databaseThiningPeriod']
        # self.batt = batt          # battery object
        # self.inv = inv            # inverter object
        # self.trk = trk            # solar tracker object
        # self.wtr = wtr            # weather object
        self.db = db              # database logging
        self.log = log            # error logging
        self.runner = None        # thread of def runner
        self.running = False      # escape boolean
        self.lastCheck = 0        # timestamp for intermittent checking
        self.status = []          # lines of status output
        self.action_mask = 0      # mask indicates changes needed for corection
        if os.path.isfile(FLAG):
            with open(FLAG, 'r') as f:
                content = f.read()
                if content is None or content == "":
                    self.lastCheck = 0
                else:
                    self.lastCheck = float(content)
        else:
            self.lastCheck = 0

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if time.time() > self.lastCheck + PERIOD:
            self.log("debug", "action-db", "Period: "+str(PERIOD)+" LastCheck: "+str(self.lastCheck))
            self.status = ['Database Reduction']

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        try:
            self.running = True
            now = time.time()
            #keeping last 24 hours of debug messages
            self.db.put("DELETE FROM error WHERE level = 'debug' AND timestamp < " + str(now - 86400))
            #keeping last 20 days
            self.db.put("DELETE FROM error WHERE timestamp < " + str(now - 2419200.0))
            #keeping last 20 days
            self.db.put("DELETE FROM inv_status WHERE timestamp < " + str(now - 2419200.0))
            #keeping last 7 days
            self.db.put("DELETE FROM inv_totals WHERE timestamp < " + str(now - 604800.0))
            #keeping last 20 days
            self.db.put("DELETE FROM battery WHERE timestamp < " + str(now - 2419200.0))
            #keeping last 7 days
            self.db.put("DELETE FROM tracking WHERE timestamp < " + str(now - 604800.0))
            #keeping last 7 days
            self.db.put("DELETE FROM light WHERE timestamp < " + str(now - 604800.0))
            # reduce database size
            self.db.put("VACUUM")
            self.lastCheck = now
            with open(FLAG, 'w') as f:
                f.write(str(now))
            self.status = []
            self.running = False
        except Exception:
            self.log('critical', 'action-db', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch, MagicMock
    
    # Setup mocs
    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            fake_files[file].close = lambda: True
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    # Mock database class
    class db:
        def __init__(self):
            self._configured = False
            self.put_calls = []
        def put(self, msg):
            self.put_calls.append(msg)
            self._configured = True

    # Mock logger
    log = MagicMock()

    conf = {
        'databaseThiningPeriod': 30
    }

    with patch('builtins.open', side_effect=open_side_effect), \
         patch('time.time', return_value=10000000):
        # Create objects
        d = db()
        act = PeriodicDatabaseReduction(d, log, conf)
        act.lastCheck = 9999999

        # Test initial state
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        act.lastCheck = 9999000

        act.check()
        assert act.status == ["Database Reduction"], "Expected active status, got "+str(act.status)

        act.do()
        act.runner.join()

        assert(not act.running)
        assert(act.status == [])

        expected_calls = [
                "DELETE FROM error WHERE timestamp < 7580800.0",
                "DELETE FROM inv_status WHERE timestamp < 7580800.0",
                "DELETE FROM inv_totals WHERE timestamp < 9395200.0",
                "DELETE FROM battery WHERE timestamp < 7580800.0",
                "DELETE FROM tracking WHERE timestamp < 9395200.0",
                "DELETE FROM light WHERE timestamp < 9395200.0"
                ]
        assert d.put_calls == expected_calls, "Expected "+str(expected_calls)+"\nReceived "+str(d.put_calls)

        assert FLAG in fake_files
        fake_files[FLAG].seek(0)
        assert fake_files[FLAG].read() == "10000000"
        print("✅ Pass: Periodic Database Thinning sequence completed")

if __name__=="__main__":
    main()

