import os
import time
import threading
import traceback

FLAG = "/home/service/sysConditioning"
trkFLAG = "/home/service/trkConditioning"
nuisFLAG = "/home/service/nuisanceBatteries"

class ColdConditioning:
    def __init__(self, batt, inv, trk, wtr, log, config):
        self.LOW_TEMPERATURE = config['lowTemperatureWarning']
        self.FAULT_FLAG_MASK = config['lowTemperatureMask'][batt.type]
        self.batt = batt         # battery object
        self.inv = inv           # inverter object
        self.trk = trk           # solar tracker object
        self.wtr = wtr           # weather object
        self.log = log           # error logging
        self.runner = None       # thread of def runner
        self.running = False     # thread 
        self.status = []         # lines of status output
        self.action_mask = 0x32  # mask indicates changes needed for corrective actions

        # action_mask is defined as follows:
        # ----------+---------+------------------------------------
        # |bit      |device   |areas of change
        # ----------+---------+------------------------------------
        # 0      1   tracker   conditiong (service mode)
        # 1      2   batt      revive | shutdown (contactor open)
        # 2      4   batt      heating
        # 3      8   batt      reserved
        # 4      16  inverter  output control (smartload)
        # 5      32  inverter  charge voltage
        # 6-7        inverter  reserved
        # ----------+---------+------------------------------------


    # Method: check
    # Purpose: Evaluates if task is necessary
    # Input Arguments: None
    # Return Value: True if task is required for correction;
    #               False if system operation is good
    def check(self):
        nuisanceBatt = []
        if not self.running:
            self.log('debug', 'action-cld', "Checking for cold")
            if os.path.isfile(nuisFLAG):
                with open(nuisFLAG, 'r') as f:
                    nuisanceBatt = eval(f.read())
            for i in range(len(self.batt.batt_id)):
                if self.batt.batt_id[i] not in nuisanceBatt and \
                        self.batt.faults[i] is not None and \
                        self.batt.faults[i] & self.FAULT_FLAG_MASK:
                    self.status = ["Cold Conditioning"]
                    self.log('debug', 'action-cld', "Its cold")

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
                self.runner = threading.Thread(target=self.run, daemon=True)
                self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        nuisanceBatt = []
        try:
            self.status = ["Cold Conditioning - Preparing"]
            # read nuisance battery list
            if os.path.isfile(nuisFLAG):
                with open(nuisFLAG, 'r') as f:
                    nuisanceBatt = eval(f.read())

            # If necessary set tracker to point South
            # if min_temp < low temperature
            if self.trk.service is not None and \
               self.trk.service.lower() == "off" and \
               (any([self.batt.min_temp[i] < self.LOW_TEMPERATURE for i in \
                   range(len(self.batt.batt_id)) if \
                   self.batt.min_temp[i] is not None and \
                   self.batt.batt_id[i] not in nuisanceBatt])):
                self.trk.safe()
                with open(trkFLAG, 'w') as f:
                    f.write("Tracker Conditioning - Low Temperature")
                    self.log('warning', 'action-cld', "Start Low Temp")

            # Turn off output
            if self.batt.type != 'EVE':
                conf = self.batt.getInvParams(self.wtr.summer())
                self.inv.reqOutputRange(conf['charge_v']+3, conf['charge_v']+1)

            # Record start of Cold Conditioniing
            with open(FLAG, 'w') as f:
                f.write(self.status[0][:18])

            self.status = ["Cold Conditioning - Waiting to recover"]
            while self.running:
                # Check status contactor state of each battery
                #          if not NON-RECOVERABLE or Nuisance
                batts = []
                for i in range(len(self.batt.contactor)):
                    if (self.batt.contactor[i] is not None and
                            self.batt.voltage[i] is not None and 
                            self.batt.batt_id[i] is not None and
                            self.batt.faults[i] is not None and not
                            ((self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS) or
                              self.batt.batt_id[i] in nuisanceBatt)):
                        batts.append((i, self.batt.contactor[i], self.batt.voltage[i])) 
                if batts != [] and all([i[1] for i in batts]):
                    self.log('warning', 'action-cld', "Cleared batteries connected.")
                    self.status = []
                    self.running = False
                # Check status if system has batteries to check
                elif batts != []:
                    if self.batt.type == 'EVE':
                        # Reduce charge current when fewer batteries are on the bus
                        max_charge_current = [25, 25, 50, 75, 165, 165, 165, 165, 165][sum(self.batt.contactor)]
                        self.inv.reqChargeCurrent(max_charge_current)
                    else:
                        # Order them by open contactors, by voltage, and leaving nuisance batts in the middle
                        #     Lowest voltage battery with open contactor is in front
                        #     Bus Voltage holder is in the back (closed contactor with highest Voltage)
                        #           assuming contactor is closed
                        orderByVoltage = sorted(batts, key=lambda x: x[2] + 100 * x[1])
                        self.log('debug', 'action-cld', "Evaluating batteries: " + str(orderByVoltage))
                        self.inv.reqChargeVoltage(max(
                            orderByVoltage[0][2]+0.3, 
                            self.inv.RECOVERY_CHARGE_VOLTAGE))
                for i in range(len(self.batt.batt_id)):
                    if self.batt.batt_id[i] not in nuisanceBatt and \
                            self.batt.faults[i] is not None and \
                            self.batt.faults[i] & self.FAULT_FLAG_MASK:
                        break
                else:
                    self.log('warning', 'action-cld', "Cleared")
                    self.running = False
                    self.status = []

            # Recovery complete
        except Exception:
            self.log('critical', 'action-cld', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
                #print(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch

    class batt:
        def __init__(self):
            self.type = "Beam"
            self.sstop = False
            self.voltage = [52.0, 52.0, 52.0, 48.0, 52.0]
            self.min_temp = [0, -2, 3, 3, 1, 2]
            self.faults = [0, 0, 0, 3, 0]
            self.contactor = [1, 1, 1, 0, 1]
            self.batt_id = [0, 1, 2, 3, 4]
            self.NON_RECOVERABLE_FAULTS = 1
            self._result = False
        def getInvParams(self, summer=False):
            return { "charge_v": 80 }
        def encourage(self):
            self.contactor = [0, 0, 0, 0, 0]
    
    class inv:
        def __init__(self):
            self.MAX_CHARGE_VOLTAGE = 55.0
            self.RECOVERY_CHARGE_VOLTAGE = 50.0
            self.t_output = True
            self.t_charge = 55.0
        def reqChargeVoltage(self, v:float=57.0):
            #print("in reqChargeVoltage: "+str(v))
            self.t_charge = v
        def reqOutputRange(self, sl_off:float=51, sl_on:float=53):
            self.t_output = False

    class trk:
        def __init__(self):
            self.service = "off"
        def safe(self):
            self.service = "on"
    class wtr:
        def __init__(self):
            pass
        def summer(self):
            return True

    logs = []

    def log(level, device, mesg):
        nonlocal logs
        logs.append(mesg)

    config = {
        'lowTemperatureWarning': 0,
        'lowTemperatureMask': {
            "EVE": 3, "Flux": 2, "Beam": 2
        }
    }

    # Setup mocks
    fake_time = [1000000]

    def advance_time(seconds):
        fake_time[0] += seconds
        return fake_time[0]

    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            fake_files[file].close = lambda: True
            return fake_files[file]
        if 'a' in mode:
            fake_files[file] = io.StringIO()
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    with patch("os.path.isfile", side_effect=lambda path: path in fake_files), \
         patch("builtins.open", side_effect=open_side_effect), \
         patch("os.remove", side_effect=lambda path: fake_files.pop(path)), \
         patch("os.path.exists", side_effect=lambda path: path in fake_files), \
         patch('time.time', side_effect=lambda: advance_time(1)), \
         patch('time.sleep', side_effect=lambda x: advance_time(x)):

        # Create objects
        b = batt()
        i = inv()
        t = trk()
        w = wtr()

        act = ColdConditioning(b, i, t, w, log, config)
        with open(nuisFLAG, 'w') as f:
            f.write('[3]')

        # Initial check: nothing abnormal
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        # Stimulate check: open contactor
        b.contactor[1] = 0
        b.faults[1] = 2
        act.check()
        assert act.status == ["Cold Conditioning"], "Expect activated, got "+str(act.status)

        act.do()
        #assert act.status == ["Cold Conditioning - Preparing"], "Expected 'Preparing', got "+str(act.status)
        assert not i.t_output, "Expected inverter off, got "+str(i.t_output)
        assert t.service, "Expected Tracker in service mode, got "+("Service" if t.service else "Normal")
        assert act.status == ["Cold Conditioning - Waiting to recover"], "Expected 'Waiting', got "+str(act.status)
        assert os.path.isfile(FLAG), "Expected FLAG presance"
        
        assert i.t_charge == 52.3, "Expected inverter 52.3, got "+str(i.t_charge)
        b.faults[1] = 0
        while act.running:
            pass

        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running 
        print("✅ Pass: Cold Conditioning sequence completed")


if __name__=="__main__":
    main()
