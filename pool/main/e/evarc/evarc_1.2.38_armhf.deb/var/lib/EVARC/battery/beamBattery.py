#!/usr/bin/python3
import can
import cantools
import time
import os
import traceback
import threading

BATTERY_PACK_ADDRESSES = [0x20, 0x80, 0x81, 0x82]
LOC = {0x20: 0, 0x80: 1, 0x81: 2, 0x82: 3}
FAULT_TABLE = {
    0: "ChargingOverCurrent",
    1: "DischargingOverCurrent",
    2: "OverVoltage",
    3: "UnderVoltage",
    4: "OverTemp",
    5: "UnderTemp",
    6: "VoltageImbalance",
    7: "CapImpedance",
    8: "VoltageComm",
    9: "BusVoltage",
    10: "PosIsolation",
    11: "NegIsolation",
    12: "PreCharge",
    13: "EEPROM",
    14: "Temperature",
    15: "TempOutOfRange",
    16: "VoltageOutOfRange",
    17: "CANMissing",
    18: "Charger",
    19: "TempDifference",
    20: "CAN",
    21: "FETOverTemp",
    22: "ExtremeOverTemp",
    23: "RecoveryMode"
}
STUCK_FLAG = "/home/service/beam_stuck_battery"

# 0: OFF, 1: HEAT W/ CONTACTOR CLOSED, 2: HEAT WITH CONTACTOR OPEN
HEAT_MODE = ["off    ", "on     "]

# 0: NO FAULT,  1: TEMP ON HIGH CELL TOO HIGH,
# 2: TEMP BETWEEN HIGH CELL AND LOW CELL TOO GREAT
HEAT_FAULT = [ None, "OT     ", "diff   ", "OT&diff", "UV     ", "OT&UV   ", "diff&UV", "OT&d&UV", "OV     ", "OT&OV  ", "diff&OV", "OT&d&OV"]

def first_not_none_value(d: list):
    for i in d:
        if i is not None:
            return i
    return None

# battery class
class Battery:
    def __init__(self, db, log, spn, conf):
        """Initialize new Beam / AllCell battery"""
        self.iface = conf['battery_iface']
        self.num_batteries = conf['num_batteries']
        self.db = db
        self.log = log
        self.spn = spn
        db.create("CREATE TABLE battery (id INTEGER PRIMARY KEY,"\
            + " timestamp CONVERT_TIMESTAMP, batt_id INTEGER, soc REAL,"\
            + " bms_temp REAL, min_temp REAL, max_temp REAL, faults"\
            + " INTEGER, voltage REAL, min_voltage REAL, max_voltage"\
            + " REAL, current REAL, recovery INTEGER, lf_role TEXT,"\
            + " contactor INTEGER, therm1 REAL, therm2 REAL, therm3 REAL,"\
            + " therm4 REAL, therm5 REAL, therm6 REAL, therm7 REAL, therm8"\
            + " REAL, therm9 REAL, therm10 REAL, therm11 REAL, therm12 REAL,"\
            + " therm13 REAL, therm14 REAL, therm15 REAL, therm16 REAL,"\
            + " heatMode INTEGER, heatFault INTEGER, canHeat INTEGER,"\
            + " cutOffHeat INTEGER);")
        db.create("CREATE TABLE debug (event_id INTEGER,"\
            + " timestamp CONVERT_TIMESTAMP, debug_mesg_id INTEGER,"\
            + " debug_mesg TEXT);")
        self.lock = threading.Lock()
        self.type = "Beam"
        self.stop = False
        self.sstop = False
        self.can_db = cantools.database.load_file(
            os.path.dirname(os.path.abspath(__file__)) + "/../dbc/Beam_Core_R06.dbc"
        )
        if "can" in self.iface:
            self.bus = can.interface.Bus(self.iface, bustype="socketcan")
        elif "tty" in self.iface:
            self.bus = can.interface.Bus(bustype='seeedstudio', channel=self.iface, bitrate=500000)
        else:
            raise Exception("CAN Interface is not defined!")
        self.battery_count = 0
        self.invBusVCallback = None
        self.outputlen = 22
        self.rowoffset = 0
        self.HEADER = "BATT     :                      BATT     :                      BATT     :                      BATT     :                  "+\
                str(conf['num_batteries'])+""" Beam
  VOLTAGE:                        VOLTAGE:                        VOLTAGE:                        VOLTAGE:                  ------
     MIN :                           MIN :                           MIN :                           MIN :
     MAX :                           MAX :                           MAX :                           MAX :

  CURRENT:                        CURRENT:                        CURRENT:                        CURRENT:
  CONTACT:                        CONTACT:                        CONTACT:                        CONTACT:
      SOC:                            SOC:                            SOC:                            SOC:

 TEMPERAT:                       TEMPERAT:                       TEMPERAT:                       TEMPERAT:
     MIN :                           MIN :                           MIN :                           MIN :
     MAX :                           MAX :                           MAX :                           MAX :
     BMS :                           BMS :                           BMS :                           BMS :

  HEATING:                        HEATING:                        HEATING:                        HEATING:            

 LEAD/FOL:                       LEAD/FOL:                       LEAD/FOL:                       LEAD/FOL:
 RECOVERY:                       RECOVERY:                       RECOVERY:                       RECOVERY:
 FAULTS  :                       FAULTS  :                       FAULTS  :                       FAULTS  :"""
        self.NON_RECOVERABLE_FAULTS = 0x18003
        self.MIN_CELL_BAL_CHECK = 3.96
        self.batt_id = [None] * 4
        self.soc = [None] * 4
        self.bms_temp = [None] * 4
        self.min_temp = [None] * 4
        self.max_temp = [None] * 4
        self.faults = [None] * 4
        self.voltage = [None] * 4 
        self.leader = None
        self.min_voltage = [None] * 4
        self.max_voltage = [None] * 4
        self.current = [None] * 4
        self.recovery = [None] * 4
        self.lf_role = [None] * 4
        self.contactor = [None] * 4
        self.messages_collected = [None] * 4
        self.therm = [[None]*16 for i in range(4)]
        self.heater = [None] * 4
        self.heatMode = [None] * 4
        self.heatFault = [None] * 4
        self.canHeat = [None] * 4
        self.cutOffHeat = [None] * 4
        self.messages_collected = {}
        self.messages_collected[0xFF81] = False
        for i in BATTERY_PACK_ADDRESSES:
            self.messages_collected[0xFF5000 + i] = False
            self.messages_collected[0xFF5100 + i] = False
            self.messages_collected[0xFF2500 + i] = False
            self.messages_collected[0xFF2600 + i] = False
            self.messages_collected[0xFF2700 + i] = False

        self.fault = False
        self.fault_mask = False
        self.fault_event_id = 0
        self.faultHandler = None

        self.runner = None
        self.sender = None
        self.send_index = 0

    def getData(self):
        """collect data from batteries and save it in class"""
        self.spn += 1
        max_messages = 100
        msg_count = 0
        try:
            msg = self.bus.recv(10)  # 10 second timeout
            if msg is None:
                raise can.CanError
        except can.CanError:
            if 'can' in self.iface:
                os.system("sudo ip link set %s down"%(self.iface))
                os.system("sudo ip link set %s up type can bitrate 500000"%(self.iface))
                self.bus = can.interface.Bus(self.iface, bustype="socketcan")
                self.log('warning', "Battery", "Restarted CAN interface")
            else:
                self.log('warning', "Battery", "CAN interface not working, cannot reset.")


        for msg in self.bus:
            if msg_count > max_messages:
                msg_count = 0
                break
            else:
                msg_count += 1
            if msg.arbitration_id & 0xFFFF00 == 0xFF5000:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id & 0xFF
                self.batt_id[LOC[i]] = res["Batt_ID"]
                self.soc[LOC[i]] = res["SOC"]
                self.bms_temp[LOC[i]] = res["BMS_Temp"]
                self.min_temp[LOC[i]] = res["Min_Temp"]
                self.max_temp[LOC[i]] = res["Max_Temp"]
                self.faults[LOC[i]] = (
                    int(msg.data[5]) + 256 * int(msg.data[6]) + 65536 * int(msg.data[7])
                )
                self.messages_collected[msg.arbitration_id & 0xFFFFFF] = True
            elif (msg.arbitration_id & 0xFFFF00) == 0xFF5100:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id & 0xFF
                self.min_voltage[LOC[i]] = res["Min_Cell_V"]
                self.max_voltage[LOC[i]] = res["Max_Cell_V"]
                self.current[LOC[i]] = -1 * res["Current"]
                self.recovery[LOC[i]] = res["RecoveryMode"]
                self.lf_role[LOC[i]] = res["LeadFollowState"]
                self.contactor[LOC[i]] = res["ContactorState"]
                self.messages_collected[msg.arbitration_id & 0xFFFFFF] = True
            elif (msg.arbitration_id & 0xFFFF00) == 0xFF8100:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id & 0xFF
                self.voltage[LOC[i]] = res["Voltage"]
                self.leader = msg.arbitration_id & 0xFF
                self.messages_collected[0xFF81] = True
            elif (msg.arbitration_id & 0xFFFE00) == 0xFF2600:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id & 0xFF
                for j in range(8):
                    if (msg.arbitration_id & 0x100) == 0:
                        self.therm[LOC[i]][j] = res["Thermistor_%d"%(j+1)]
                    else:
                        self.therm[LOC[i]][j+8] = res["Thermistor_%d"%(j+9)]
                self.messages_collected[msg.arbitration_id & 0xFFFFFF] = True
            elif (msg.arbitration_id & 0xFFFF00) == 0xFF4000:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id & 0xFF
                self.voltage[LOC[i]] = res["PackVoltage"]
            elif (msg.arbitration_id & 0xFFFF00) == 0xFF2500:
                res = self.can_db.decode_message(msg.arbitration_id, msg.data)
                i = msg.arbitration_id & 0xFF
                self.heater[LOC[i]] = res["HeaterOn"]
                self.heatMode[LOC[i]] = res["HeatingMode"]
                self.heatFault[LOC[i]] = res["HeaterFault"]
                self.canHeat[LOC[i]] = res["CanHeat"]
                self.cutOffHeat[LOC[i]] = res["HeaterCutOff"]
                self.messages_collected[msg.arbitration_id & 0xFFFFFF] = True

    def saveData(self):
        """write collected data to the database"""
        if not all(self.messages_collected.values()):
            battery_count = 0
            missing_batteries = 0
            for i in BATTERY_PACK_ADDRESSES:
                if self.messages_collected[0xFF81] and all([
                   self.messages_collected[0xFF5000 + i],
                   self.messages_collected[0xFF5100 + i],
                   self.messages_collected[0xFF2700 + i],
                   self.messages_collected[0xFF2600 + i]]):
                    battery_count += 1
                elif not any([
                   self.messages_collected[0xFF5000 + i],
                   self.messages_collected[0xFF5100 + i],
                   self.messages_collected[0xFF2700 + i],
                   self.messages_collected[0xFF2600 + i]]):
                    missing_batteries += 1
                    self.batt_id[LOC[i]] = None
                    self.soc[LOC[i]] = None
                    self.bms_temp[LOC[i]] = None
                    self.min_temp[LOC[i]] = None
                    self.max_temp[LOC[i]] = None
                    self.faults[LOC[i]] = None
                    self.voltage[LOC[i]] = None
                    self.min_voltage[LOC[i]] = None
                    self.max_voltage[LOC[i]] = None
                    self.current[LOC[i]] = None
                    self.recovery[LOC[i]] = None
                    self.lf_role[LOC[i]] = None
                    self.contactor[LOC[i]] = None
                    self.therm[LOC[i]][0] = None
                    self.therm[LOC[i]][1] = None
                    self.therm[LOC[i]][2] = None
                    self.therm[LOC[i]][3] = None
                    self.therm[LOC[i]][4] = None
                    self.therm[LOC[i]][5] = None
                    self.therm[LOC[i]][6] = None
                    self.therm[LOC[i]][7] = None
                    self.therm[LOC[i]][8] = None
                    self.therm[LOC[i]][9] = None
                    self.therm[LOC[i]][10] = None
                    self.therm[LOC[i]][11] = None
                    self.therm[LOC[i]][12] = None
                    self.therm[LOC[i]][13] = None
                    self.therm[LOC[i]][14] = None
                    self.therm[LOC[i]][15] = None
                    self.heatMode[LOC[i]] = None
                    self.heatFault[LOC[i]] = None
                    self.canHeat[LOC[i]] = None
                    self.cutOffHeat[LOC[i]] = None
                else:
                    return
            self.battery_count = battery_count
        else:
            self.battery_count = 4
        self.lock.acquire()
        if self.current is None:
            raise Exception("Data cleared before reported")
        t = time.time()
        for i in range(4):
            if all([self.messages_collected[j+BATTERY_PACK_ADDRESSES[i]] for j in [0xFF5000, 0xFF5100, 0xFF2500, 0xFF2600, 0xFF2700]]):
                sql = (
                    ("INSERT INTO battery (timestamp, batt_id, soc, bms_temp,"\
                    + " min_temp, max_temp, faults, voltage, min_voltage,"\
                    + " max_voltage, current, recovery, lf_role, contactor,"\
                    + " therm1, therm2, therm3, therm4, therm5, therm6, therm7,"\
                    + " therm8, therm9, therm10, therm11, therm12, therm13,"\
                    + " therm14, therm15, therm16, heatMode, heatFault,"\
                    + " canHeat, cutOffHeat) VALUES (%f, %d, %f, %f, %f,"\
                    + " %f, %d, %f, %f, %f, %f, %d, '%s', %d, %f,"\
                    + " %f, %f, %f, %f, %f, %f, %f, %f, %f, %f,"\
                    + " %f, %f, %f, %f, %f, %d, %d, %d, %d);") % (
                        t,
                        self.batt_id[i],
                        self.soc[i],
                        self.bms_temp[i],
                        self.min_temp[i],
                        self.max_temp[i],
                        self.faults[i],
                        self.voltage[i],
                        self.min_voltage[i],
                        self.max_voltage[i],
                        self.current[i],
                        self.recovery[i],
                        self.lf_role[i],
                        self.contactor[i],
                        self.therm[i][0],
                        self.therm[i][1],
                        self.therm[i][2],
                        self.therm[i][3],
                        self.therm[i][4],
                        self.therm[i][5],
                        self.therm[i][6],
                        self.therm[i][7],
                        self.therm[i][8],
                        self.therm[i][9],
                        self.therm[i][10],
                        self.therm[i][11],
                        self.therm[i][12],
                        self.therm[i][13],
                        self.therm[i][14],
                        self.therm[i][15],
                        self.heatMode[i],
                        self.heatFault[i],
                        self.canHeat[i],
                        self.cutOffHeat[i]
                    )
                )
                self.db.put(sql)

        for i in BATTERY_PACK_ADDRESSES:
            self.messages_collected[0xFF5000 + i] = False
            self.messages_collected[0xFF5100 + i] = False
            self.messages_collected[0xFF2500 + i] = False
            self.messages_collected[0xFF2600 + i] = False
            self.messages_collected[0xFF2700 + i] = False
        self.messages_collected[0xFF81] = False

        self.lock.release()

    def showData(self):
        """Writes collected data to outputfile"""
        ret_value = ""
        col = [12, 44, 76, 108]
        for i in range(4):
            if self.batt_id[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 1, 
                                                  col[i] - 6, self.batt_id[i])
            if self.voltage[i] is not None:
                ret_value += "\x1b[%d;%df%4.2f" % (self.rowoffset + 2,
                                                  col[i], self.voltage[i])
            if self.min_voltage[i] is not None:
                ret_value += "\x1b[%d;%df%4.3f" % (self.rowoffset + 3,
                                                  col[i], self.min_voltage[i])
            if self.max_voltage[i] is not None:
                ret_value += "\x1b[%d;%df%4.3f" % (self.rowoffset + 4,
                                                  col[i], self.max_voltage[i])
            if self.current[i] is not None:
                ret_value += "\x1b[%d;%df%3.2f" % (self.rowoffset + 6,
                                                  col[i], self.current[i])
            if self.contactor[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 7,
                                                  col[i], self.contactor[i])
            if self.soc[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 8,
                                                  col[i], self.soc[i])
            if self.min_temp[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 11,
                                                  col[i], self.min_temp[i])
            if self.max_temp[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 12,
                                                  col[i], self.max_temp[i])
            if self.bms_temp[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 13,
                                                  col[i], self.bms_temp[i])
            if self.heater[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset +
                            15, col[i], HEAT_MODE[self.heater[i]])
            if self.lf_role[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (
                        self.rowoffset + 17,
                        col[i], str(self.lf_role[i]) + " "*(18-len(
                            str(self.lf_role[i]))))
            if self.recovery[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 18,
                                                  col[i], self.recovery[i])
            if self.faults[i] is not None:
                ret_value += "\x1b[%d;%df%s" % (self.rowoffset + 19,
                                                  col[i], self.faults[i])
        ret_value += "\x1b[%d;%df%s" % (self.rowoffset + self.outputlen - 3, 
                                          129, self.spn)
        return ret_value

    def getFaults(self):
        """decodes faults returns a list of fault strings"""
        result = []
        for i in range(4):
            if self.faults[i] is not None and self.faults[i] > 0:
                for bit,fault in FAULT_TABLE.items():
                    if self.faults[i] & (1<<bit):
                        result.append("Battery %s: %s"%(self.batt_id[i], fault))
        return result

    def getInvParams(self, summer):
        """returns inverter configuratins for this battery configuration"""
        if summer:
            if self.battery_count > 3:
                return { "capacity": 860, "shutd_v": 48.3, "restart_v": 51.5,
                        "low_bat": 48.4, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 48.5, "sl_on": 52}
            elif self.battery_count > 2:
                return { "capacity": 645, "shutd_v": 48.3, "restart_v": 51.5,
                        "low_bat": 48.4, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 48.5, "sl_on": 53.5}
            elif self.battery_count > 1:
                return { "capacity": 430, "shutd_v": 48.3, "restart_v": 51.5,
                        "low_bat": 48.4, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 48.5, "sl_on": 55}
            else:
                return { "capacity": 0, "shutd_v": 47, "restart_v": 51.5,
                        "low_bat": 47.5, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 59, "sl_on": 59.5}

        else:
            if self.battery_count > 3:

                return { "capacity": 860, "shutd_v": 49.5, "restart_v": 51.5,
                        "low_bat": 49.6, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 51, "sl_on": 54.5}
            elif self.battery_count > 2:
                return { "capacity": 645, "shutd_v": 49.5, "restart_v": 51.5,
                        "low_bat": 49.6, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 51, "sl_on": 55.5}
            elif self.battery_count > 1:
                return { "capacity": 430, "shutd_v": 49.5, "restart_v": 51.5,
                        "low_bat": 49.6, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 51, "sl_on": 56.5}
            else:
                return { "capacity": 0, "shutd_v": 47, "restart_v": 51.5,
                        "low_bat": 47.5, "recov_v": 48.3, "charge_v": 57,
                        "sl_off": 59, "sl_on": 59.5}


    def getStatus(self, ignores=[]):
        """Returns if any battery is in recovery mode"""
        if all([self.recovery[i] == 0 and self.contactor[i] == 1 
                for i in range(4) if self.recovery[i] is not None and
                self.batt_id[i] not in ignores]):
            return []
        if any([i < 48.1 for i in self.voltage if i is not None]):
            return ["Low Voltage"]
        if any([i < 0 for i in self.min_temp if i is not None]):
            return ["Low Temperature"]
        return ["Battery not connected"]

    def encourage(self, depth=0):
        """Renegotiate Leadership returns the new leader - Note: this causes all main contactors to open"""
        assert depth < 200
        self.bus.send(
            can.Message(
                arbitration_id=0x18DCFF00,
                data=[0x40, 0, 0, 0, 0, 0, 0, 0],
                is_extended_id=True,
            )
        )
        time.sleep(5)
        self.sendBusVoltage(min([i for i in self.voltage if i is not None]))
        timeout = time.time() + 60
        while (self.leader is None or 
               self.lf_role[LOC[self.leader]] == "Leader") and \
              time.time() < timeout:
            time.sleep(0.5)
        if time.time() > timeout:
            return self.encourage(depth+1)
        self.leader = None
        while self.leader is None:
            time.sleep(0.5)
        return LOC[self.leader]

    def setBusVCallback(self, busV):
        self.invBusVCallback = busV

    def sendHBBusVoltage(self):
        """start sending battery messages to the batteries to keep the bus alive"""
        if self.check_stuck_flag():
            return
        timeOfLastSend = 0
        try:
            self.log('debug', 'battery', 'Called Send BusV')
            while not self.stop and not self.sstop:
                busV = None
                if any(self.contactor):
                    for i in range(len(self.contactor)):
                        if self.contactor[i] and self.voltage[i] is not None:
                            busV = self.voltage[i]
                else:
                    try:
                        busV = min([self.voltage[i] for i in range(len(self.voltage)) if (
                                self.voltage[i] is not None and 
                                self.faults[i] is not None and (
                                self.faults[i] & self.NON_RECOVERABLE_FAULTS) == 0)])
                    except ValueError:
                        time.sleep(2)
                if busV is not None and timeOfLastSend + 1 < time.time():
                    self.sendBusVoltage(busV)
                    timeOfLastSend = time.time()
            self.sender = None
        except Exception:
            self.log('critical', 'battery', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")

    def sendBusVoltage(self, busV):
        """send single battery bus voltage message"""
        try:
            self.bus.send(can.Message(arbitration_id=773, data=b'\x00\x00\x00\x00\x00\x00\x00\x00', is_extended_id=False)) 
            if busV is not None:
                busV = [(int(busV * 20) & 0xF00) >> 8, int(busV * 20) & 0xFF]
                self.bus.send(
                    can.Message(
                        arbitration_id=0x0CFF3000,
                        data=[0x81, busV[1], busV[0], 0, 0, 0, 0, 0],
                        is_extended_id=True,
                    )
                )
        except can.CanError:
            if 'tty' in self.iface:
                os.system("echo 2-2:1.0 | sudo tee /sys/bus/usb/drivers/ch341/unbind")
                os.system("echo 2-2:1.0 | sudo tee /sys/bus/usb/drivers/ch341/bind")
                self.bus = can.interface.Bus(bustype='seeedstudio', channel=self.iface, bitrate=500000)

    def sendShutdown(self, batt_id):
        """Shutdown the specified battery by battery_address"""
        if batt_id == 0:
            self.bus.send(
                can.Message(
                    arbitration_id=0x18DCFF00,
                    data=[0x66, 0, 0, 0, 0, 0, 0, 0],
                    is_extended_id=True
                )
            )
            self.batt_id = [ None ] * 4
            self.soc = [ None ] * 4
            self.bms_temp = [ None ] * 4
            self.min_temp = [ None ] * 4
            self.max_temp = [ None ] * 4
            self.faults = [ None ] * 4
            self.voltage = [ None ] * 4
            self.min_voltage = [ None ] * 4
            self.max_voltage = [ None ] * 4
            self.current = [ None ] * 4
            self.recovery = [ None ] * 4
            self.lf_role = [ None ] * 4
            self.contactor = [ None ] * 4
            self.therm = [ [ None ] * 16 ] * 4
            self.stop = True
            self.sstop = True
            return self.bus.send(
            can.Message(
                arbitration_id=0x18DCFF00,
                data=[0x77, batt_id, 0, 0, 0, 0, 0, 0],
                is_extended_id=True
            )
        )
        time.sleep(0.2) # wait for last messages before clearing data
        self.batt_id[batt_id] = None
        self.soc[batt_id] = None
        self.bms_temp[batt_id] = None
        self.min_temp[batt_id] = None
        self.max_temp[batt_id] = None
        self.faults[batt_id] = None
        self.voltage[batt_id] = None
        self.min_voltage[batt_id] = None
        self.max_voltage[batt_id] = None
        self.current[batt_id] = None
        self.recovery[batt_id] = None
        self.lf_role[batt_id] = None
        self.contactor[batt_id] = None
        self.therm[batt_id][0] = None
        self.therm[batt_id][1] = None
        self.therm[batt_id][2] = None
        self.therm[batt_id][3] = None
        self.therm[batt_id][4] = None
        self.therm[batt_id][5] = None
        self.therm[batt_id][6] = None
        self.therm[batt_id][7] = None
        self.therm[batt_id][8] = None
        self.therm[batt_id][9] = None
        self.therm[batt_id][10] = None
        self.therm[batt_id][11] = None
        self.therm[batt_id][12] = None
        self.therm[batt_id][13] = None
        self.therm[batt_id][14] = None
        self.therm[batt_id][15] = None
        if self.batt_id == [ None ] * len(self.batt_id):
            self.stop = True
            self.sstop = True

    def check_stuck_flag(self):
        """Checks if a battery is stuck (flagged by action library)"""
        if os.path.isfile(STUCK_FLAG):
            return True
        return False

    def start(self):
        """Launch a thread to collect, record and report the battery data"""
        self.stop = False
        if self.runner is None:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()
        if self.sender is None:
            self.sender = threading.Thread(target=self.sendHBBusVoltage, daemon=True)
            self.sender.start()

    def run(self):
        """Method that performs collect, record and report the battery data"""
        while not self.stop:
            try:
                self.getData()
                self.saveData()
                time.sleep(3)
            except Exception:
                self.log('critical', 'battery', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")


if __name__ == "__main__":
    line = 21
    def log(device, level, msg):
        global line
        print("\x1b7\x1b[%d;%df%s\x1b8" % (line, 0, "|%s| (%s) - %s" % (device, level, msg)))
        line += 1

    class db:
        def create(self, s):
            pass
        def put(self, s):
            pass

    class s:
        def __add__(self, i):
            return self
        def __str__(self):
            return "-"

    b = Battery(db(), log, s(), {'battery_iface': 'can1', 'num_batteries': 4})
    b.fault_mask = True
    b.start()
    #b.sender = threading.Thread(target=b.sendHBBusVoltage, daemon=True)
    #b.sender.start()
    count = 20
    while True:
        if count >= 20:
            line = 21
            print("\033c\033[3J\x1b7\x1b[%d;1f"%(1)+b.HEADER+"\n\x1b8")
            count = 0
        count += 1
        print(b.showData(), flush=True)
        time.sleep(0.5)
