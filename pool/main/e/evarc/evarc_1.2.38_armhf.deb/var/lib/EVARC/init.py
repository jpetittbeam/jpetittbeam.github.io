import os
import serial
import minimalmodbus
import time
import can
import subprocess
from jinja2 import Environment, FileSystemLoader


def check_tty(iface):
    """returns 1-Inverter 2-EVE_batt 3-CAN or 0-NoResponse"""
    print("Checking serial device: "+iface, end="")
    try:
        m = minimalmodbus.Instrument(iface, 1)
        m.serial.baudrate = 9600
        o = m.read_register(0)
        if o == 3:
            print(" - Inverter")
            return 1
        else:
            print(" - EVE batt")
            return 2
    except serial.serialutil.SerialException:
        print(" - " + iface + " is already in use")
    except minimalmodbus.InvalidResponseError:
        return check_tty(iface)
    except minimalmodbus.NoResponseError:
        print(" - Nothing")
        return 0

def check_CAN(iface, bitrate):
    """returns (batt_type, count), where type is 1-Flux 2-Beam or 0-NoResponse"""
    print("Checking CAN device: "+iface, end="")
    batt_type = None
    beam = { 0x20: 1, 0x80: 2, 0x81: 3, 0x82: 4 }
    count = [0, 0, 0, 0, 0]
    try:
        print("TRYING " + iface)
        if 'can' in iface:
            if subprocess.run(['timeout', '1s', 'candump', iface], stdout=subprocess.PIPE).stdout == "":
                return (0, 0)
            b = can.interface.Bus(iface, bustype='socketcan')
        else:
            b = can.interface.Bus(bustype='seeedstudio', channel=iface, bitrate=bitrate)
        msg = b.recv(2)
        if msg is None:
            raise can.CanError
        for msg in b:
            if msg.is_extended_id:
                batt_type = 2
                count[beam[0xFF & msg.arbitration_id]] += 1
            elif (msg.arbitration_id & 0xFF0) == 0x180:
                batt_type = 1
                count[0xF & msg.arbitration_id] += 1
            elif (msg.arbitration_id & 0xFF0) == 0x280:
                batt_type = 1
                count[0xF & msg.arbitration_id] += 1
            if any([i > 10 for i in count]):
                break
        if batt_type is not None:
            b.shutdown()
            print(" - %s of type %d" % (str(count), batt_type))
            return (batt_type, sum([i != 0 for i in count]))
        b.shutdown()
    except can.CanError:
        return (0, 0)
    return (0, 0)

def set_can(iface, bitrate):
    print("Configuring CAN device: %s at rate %d" % (iface, bitrate))
    os.system("ip link set %s down" % (iface))
    os.system("ip link set %s up type can bitrate %d" % (iface, bitrate))


def main():
    includes_heater = False
    answers = {"arc": None, "battery_vend": None, "number_of_batteries": None,
            "battery_iface": None, "inverter_iface": None, "tracker_iface": None,
            "ip_addr": None, "motors": None, "grid": None, "shore_power": None,
            "chargers": None, "e_power": None}
    
    if os.path.isfile("/var/lib/EVARC/old_arcConfig.py"):
        namespace = {}
        exec(open("/var/lib/EVARC/old_arcConfig.py").read(), namespace)
        answers["arc"] = namespace['config']['arc']\
                         if 'arc' in namespace['config'].keys()\
                         else None
        answers["battery_vend"] = namespace['config']['battery_vend']\
                         if 'battery_vend' in namespace['config'].keys()\
                         else None
        answers["number_of_batteries"] = namespace['config']['num_batteries']\
                         if 'num_batteries' in namespace['config'].keys()\
                         else None
        answers["battery_iface"] = namespace['config']['battery_iface']\
                         if 'battery_iface' in namespace['config'].keys()\
                         else None
        answers["inverter_iface"] = namespace['config']['inverter_iface']\
                         if 'inverter_iface' in namespace['config'].keys()\
                         else None
        answers["tracker_iface"] = namespace['config']['tracker_iface']\
                         if 'tracker_iface' in namespace['config'].keys()\
                         else None
        if 'system' in namespace.keys():
            answers["ip_addr"] = namespace['system']['ip_addr']
            answers["motors"] = namespace['system']['motors']
            answers["grid"] = namespace['system']['grid']
            answers["shore_power"] = namespace['system']['shore_power']
            answers["chargers"] = namespace['system']['chargers']
            answers["e_power"] = namespace['system']['e_power']\
                    if 'e_power' in namespace['system'].keys()\
                    else None
        if 'heating' in namespace.keys():
            includes_heater = True

    p = subprocess.run(['ls', '/home'], stdout=subprocess.PIPE)
    if "moxa" in str(p.stdout):
        u = "moxa"
        m = check_tty("/dev/ttyM0") 
        if m == 1:
            answers["inverter_iface"] = "/dev/ttyM0"
        elif m == 2:
            answers["battery_vend"] = "EVE"
            answers["battery_iface"] = "/dev/ttyM0"
        m = check_tty("/dev/ttyM1")
        if m == 1:
            answers["inverter_iface"] = "/dev/ttyM1"
        elif m == 2:
            answers["battery_vend"] = "EVE"
            answers["battery_iface"] = "/dev/ttyM1"
        if answers["battery_iface"] is None:
            set_can('can0', 500000)
            m = check_CAN('can0', 500000)
            if m[0] == 0:
                set_can('can0', 125000)
                m = check_CAN('can0', 125000)
                if m[0] == 1:
                    answers['battery_iface'] = "can0"
                    answers['battery_vend'] = "Flux"
                    answers['number_of_batteries'] = m[1]
            elif m[0] == 2:
                answers['battery_iface'] = "can0"
                answers['battery_vend'] = "Beam"
                answers['number_of_batteries'] = m[1]
        answers["tracker_iface"] = "192.168.3.2"
    elif "debian" in str(p.stdout):
        u = "debian"
        m = check_tty("/dev/ttyUSB0")
        if m == 1:
            answers["inverter_iface"] = "/dev/ttyUSB0"
        elif m == 3:
            answers["battery_iface"] = "/dev/ttyUSB0"
            set_can('/dev/ttyUSB0', 500000)
            m = check_CAN('/dev/ttyUSB0', 500000)
            if m[0] == 0:
                set_can('/dev/ttyUSB0', 125000)
                m = check_CAN('/dev/ttyUSB0', 125000)
                if m[2] == 1:
                    answers['battery_iface'] = "/dev/ttyUSB0"
                    answers['battery_vend'] = "Flux"
                    answers['number_of_batteries'] = m[1]
            elif m[0] == 2:
                answers['battery_iface'] = "/dev/ttyUSB0"
                answers['battery_vend'] = "Beam"
                answers['number_of_batteries'] = m[1]
        m = check_tty("/dev/ttyUSB1")
        if m == 1:
            answers["inverter_iface"] = "/dev/ttyUSB1"
        elif m == 3:
            answers["battery_iface"] = "/dev/ttyUSB1"
            set_can('/dev/ttyUSB1', 500000)
            m = check_CAN('/dev/ttyUSB1', 500000)
            if m[0] == 0:
                set_can('/dev/ttyUSB1', 125000)
                m = check_CAN('/dev/ttyUSB1', 125000)
                if m[0] == 1:
                    answers['battery_iface'] = "/dev/ttyUSB1"
                    answers['battery_vend'] = "Flux"
                    answers['number_of_batteries'] = m[1]
            elif m[0] == 2:
                answers['battery_iface'] = "/dev/ttyUSB1"
                answers['battery_vend'] = "Beam"
                answers['number_of_batteries'] = m[1]
        if answers['battery_iface'] is None:
            p1 = subprocess.Popen(['ip', 'link', 'show'], stdout=subprocess.PIPE)
            p2 = subprocess.Popen(['grep', '-e', '^[0-9]'], stdin=p1.stdout, stdout=subprocess.PIPE)
            p3 = subprocess.Popen(['cut', '-d:', '-f2'], stdin=p2.stdout, stdout=subprocess.PIPE)
            ifaces = p3.stdout.read().split("\n ")
            for i in ifaces:
                i = str(i)
                if 'can' in i:
                    set_can(i, 500000)
                    m = check_CAN(i, 500000)
                    if m[0] == 0:
                        set_can(i, 125000)
                        m = check_CAN(i, 125000)
                        if m[0] == 1:
                            answers['battery_iface'] = i
                            answers['battery_vend'] = "Flux"
                            answers['number_of_batteries'] = m[1]
                    elif m[0] == 2:
                        answers['battery_iface'] = i
                        answers['battery_vend'] = "Beam"
                        answers['number_of_batteries'] = m[1]
        answers["tracker_iface"] = "192.168.127.2"
    elif "pi" in str(p.stdout):
        u = "pi"
        p = subprocess.run(['ip', '-j', 'link', 'show'], stdout=subprocess.PIPE)
        intf = eval(p.stdout)
        for i in intf:
            if 'can' in i['ifname']:
                j = i['ifname']
                set_can(j, 500000)
                m = check_CAN(j, 500000)
                if m[0] == 0:
                    set_can(j, 125000)
                    m = check_CAN(j, 125000)
                    if m[0] == 1:
                        answers['battery_iface'] = j
                        answers['battery_vend'] = "Flux"
                        answers['number_of_batteries'] = m[1]
                elif m[0] == 2:
                    answers['battery_iface'] = j
                    answers['battery_vend'] = "Beam"
                    answers['number_of_batteries'] = m[1]
        if answers["inverter_iface"] is None:
            m = check_tty("/dev/ttyUSB0")
            if m == 1:
                answers["inverter_iface"] = "/dev/ttyUSB0"
            elif m == 0:
                m = check_tty("/dev/ttyUSB1")
                if m == 1:
                    answers["inverter_iface"] = "/dev/ttyUSB1"
                elif m == 3 and answers['battery_iface'] is None:
                    set_can('/dev/ttyUSB1', 500000)
                    m = check_CAN('/dev/ttyUSB1', 500000)
                    if m[0] == 0:
                        set_can('/dev/ttyUSB1', 125000)
                        m = check_CAN('/dev/ttyUSB1', 125000)
                        if m[2] == 1:
                            answers['battery_iface'] = "/dev/ttyUSB1"
                            answers['battery_vend'] = "Flux"
                            answers['number_of_batteries'] = m[1]
                    elif m[0] == 2:
                        answers['battery_iface'] = "/dev/ttyUSB1"
                        answers['battery_vend'] = "Beam"
                        answers['number_of_batteries'] = m[1]
            elif m == 3 and answers['battery_iface'] is None:
                set_can('/dev/ttyUSB0', 500000)
                m = check_CAN('/dev/ttyUSB0', 500000)
                if m[0] == 0:
                    set_can('/dev/ttyUSB0', 125000)
                    m = check_CAN('/dev/ttyUSB0', 125000)
                    if m[2] == 1:
                        answers['battery_iface'] = "/dev/ttyUSB0"
                        answers['battery_vend'] = "Flux"
                        answers['number_of_batteries'] = m[1]
                elif m[0] == 2:
                    answers['battery_iface'] = "/dev/ttyUSB0"
                    answers['battery_vend'] = "Beam"
                    answers['number_of_batteries'] = m[1]
        answers["tracker_iface"] = "192.168.127.2"
    
    p = subprocess.run(['find', '/home/'+u, '-name', 'arcConfig.py'], stdout=subprocess.PIPE)
    for d in p.stdout.split():
        arcConfig = open(d).read()
        namespace = {}
        exec(arcConfig, namespace)
        c = namespace['Config']()
        if answers["arc"] is None and "arc" in dir(c):
            answers["arc"] = int(c.arc)
        if answers["motors"] is None and "motors" in dir(c):
            answers["motors"] = c.motors
        if answers['number_of_batteries'] is None and c.arc == answers["arc"] and "number_of_batteries" in dir(c):
            answers["number_of_batteries"] = c.number_of_batteries
    
    
    print(answers)

    if None not in [answers['arc'], answers['battery_vend'],
                    answers['number_of_batteries'], answers['motors'],
                    answers['inverter_iface'], answers['battery_iface'],
                    answers['tracker_iface']] or not includes_heater:
        env = Environment(loader=FileSystemLoader('.'))
        template = env.get_template('arcConfig.template')
        output = template.render(answers)
        with open("arcConfig.py", 'w') as f:
            f.write(output)
    m = minimalmodbus.Instrument(answers['inverter_iface'], 1)
    m.serial.baudrate = 9600
    ncomplete = True
    while ncomplete:
        try:
            m.write_register(200, 0)
            m.write_register(213, 0)
            ncomplete = False
        except Exception:
            time.sleep(1)
        
    os.system("rm -f /root/monitor")
    os.system("cp -f /var/lib/EVARC/monitor.py /root/monitor")
    os.system("ln -fs /var/lib/EVARC/EVARC.py /var/lib/EVARC/main.py")

if __name__ == "__main__":
    main()
