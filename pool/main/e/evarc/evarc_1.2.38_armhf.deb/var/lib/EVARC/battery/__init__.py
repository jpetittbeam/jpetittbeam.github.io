import arcConfig
import battery.beamBattery as beam
import battery.eveBattery as eve
import battery.fluxBattery as flux

config = arcConfig.config
if config['battery_vend'] == 'Beam':
    Battery = beam.Battery
elif config['battery_vend'] == 'EVE':
    Battery = eve.Battery
elif config['battery_vend'] == 'Flux':
    Battery = flux.Battery
else:
    raise NotImplementedError("Unknown battery type: %s, check arcConfig.py"%(
        config['battery_vend']))
