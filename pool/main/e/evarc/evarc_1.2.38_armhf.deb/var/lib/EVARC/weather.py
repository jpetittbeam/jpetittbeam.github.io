import requests
import sys
import datetime
import time
import traceback
import threading

FORECAST_INTERVAL = 3600

def summer():
    d = datetime.date.today()
    d = d.month * 100 + d.day  # create numeric representation
    return (d > 400) and (d <= 1000)

class Weather:
    def __init__(self, log):
        self.log = log
        self.rowoffset = 0
        self.columnoffset = 0
        self.outputlen = 5
        self.stop = False
        self.HEADER = "   Forecast:" + "\n" + 5 * (" " * 37 + "\n") + "Summer Mode: "
        self.output = ""
        self.get_time = 0
        self.getInit = None
        self.summer = summer
        self.sunny = None
        self.latt = None
        self.long = None
        self.missed_data = 0

    def setInit(self, callback):
        self.getInit = callback

    def getData(self):
        self.output = ""
        if self.missed_data > 3:
            time.sleep(60)
            self.missed_data = 0
        if self.latt is not None and self.long is not None:
            api_url = "https://api.weather.gov/points/%s,%s" % (
                      self.latt, self.long)
            try:
                response = requests.get(api_url)
                data = response.json()
                hourly = data['properties']['forecastHourly']
                response = requests.get(hourly)
                data = response.json()

                periods = data['properties']['periods']
                sunny = True
                vals = [""] * 4
                i = 0
                for j in range(len(periods)):
                    start_time = periods[j]['startTime'][11:16]
                    if int(start_time[0:start_time.find(":")]) < datetime.datetime.now().hour:
                        continue
                    vals[i] = start_time
                    vals[i] += " " + str(periods[i]['temperature'])
                    vals[i] += "\u00b0" + periods[i]['temperatureUnit']
                    if periods[i]['isDaytime']:
                        vals[i] += " " + "\u2600" + "\t"
                    else:
                        vals[i] += " " + "\u263E" + "\t"
                        sunny = False
                    if (periods[i]['shortForecast'] == "Sunny"
                            or periods[i]['shortForecast'] == "Clear"):
                        pass
                    elif (periods[i]['shortForecast'] == "Mostly Sunny"
                            or "Cloudy" in periods[i]['shortForecast']):
                        vals[i] += "\u26C5"
                        sunny = False
                    elif "Rain" in periods[i]['shortForecast']:
                        vals[i] += "\u2614"
                        sunny = False
                    elif "Snow" in periods[i]['shortForecast']:
                        vals[i] += "\u2744"
                        self.sunny = False
                    else:
                        vals[i] += periods[i]['shortForecast']
                        sunny = False
                    if i >= 3:
                        break
                    else:
                        i += 1
                self.sunny = sunny
                self.output = ""
                for i in range(4):
                    self.output += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+2+i,
                                                              self.columnoffset+5,
                                                              vals[i])
            except requests.exceptions.ConnectionError:
                self.log('error', 'weather', 'Offline')
                self.missed_data += 1
        self.output += "\x1b7\x1b[%d;%df%s\x1b8"%(self.rowoffset+7,
                                                  self.columnoffset+15,
                                                  self.summer())

    def showData(self):
        return self.output

    def start(self):
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        lastChecked = 0
        while not self.stop:
            try:
                if time.time() > lastChecked + FORECAST_INTERVAL and \
                        self.latt is not None and \
                        self.long is not None:
                    self.getData()
                    lastChecked = time.time() - datetime.datetime.now().minute*60
                elif (self.latt is None or self.long is None) and self.getInit is not None:
                    (self.latt, self.long) = self.getInit()
                else:
                    time.sleep(1)
            except Exception:
                self.log('critical', 'weather', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time()) + "\n")
                    f.write(traceback.format_exc() + "\n")


if __name__=="__main__":
    w = Weather(print)
    print("\x1bc\x1b7\x1b[%d;%df%s\x1b8" % (14,40,"    Forecast"))
    print("\x1b[%d;%df%s\x1b8" % (20,40,"Summer Mode:"))
    w.rowoffset = 13
    w.columnoffset = 40
    if len(sys.argv) > 2:
        w.getData(sys.argv[1], sys.argv[2])
        print(w.showData())
    else:
        w.latt = 32.883
        w.long = -117.197
        w.getData()
        print(w.showData())


