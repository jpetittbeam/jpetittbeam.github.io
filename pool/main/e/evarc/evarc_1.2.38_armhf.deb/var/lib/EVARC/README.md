# EVARC
EVARC software has the purpose of gathering data from batteries, inverter, and solar tracker to optimize and control the EVARC product by Beam Global.  Controls balance maximizing energy to customers for vehical charging, and maximizing product life.

## Architecture
This code base contains libraries for specific hardware components.  The directory structure reflects the different functional components and within each directory is a library for each of the supported component models.

```
EVARC
  +------actions----------------------------------------------+-----runaway_heater
  |                                                           |     force_output_on
  +------battery-------------------------+----beam            |     force_ouput_off
  |                                      |    eve             |     service_mode
  +------database-------------sqlite     +----flux            |     overcurrent
  |                                                           |     tracker_conditioning
  +------inverter-------------solark                          |     system_revive
  |                                                           |     overcharge_voltage_reduction
  +------light                                                |     inverter_faults
  |                                                           |     battery_faults
  +------tracker--------------lauritzen                       |     battery_balancing
  |                                                           |     tracker_revive
  +------weather                                              |     periodic_inverter_conifg
  |                                                           +-----periodic_database_reduction
  +- EVARC.py
```

The toplevel EVARC creates instances of each of the components and then manages them and provides toplevel controls.

### Actions
The actions module instates a priority queue of actionable features.  The individule actions have both a priority assigned by the order in which they are instantiated and a mask that describes the hardware it utilizes to perform its action.  The high priority action can then run simultaneously with lower priority actions as long as their masks don't overlap.

| Function | Description |
| -------- | ----------- |
| **getData():**             | Collects data from the batteries. |
| **saveData():**            | Saves collected data to the database. |
| **showData():**            | Returns a string to be used with HEADER, to display the current battery data. (also see rowoffset) |
| **start():**               | Launch a thread to periodically getData and saveData. This saves the running thread to a field called runner.|
| **HEADER**                 | A string used to present battery data. |
| **rowoffset**              | Field used to offset the data from showData.  For stacking outputs. |
| **outputlen**              | Indicator of the number of lines the HEADER and data use. For stacking outputs. |

### Battery
The battery supports charging when solar is inconsistant.

| Function | Description |
| -------- | ----------- |
| **getData():**             | Collects data from the batteries. |
| **saveData():**            | Saves collected data to the database. |
| **showData():**            | Returns a string to be used with HEADER, to display the current battery data. (also see rowoffset) |
| **start():**               | Launch a thread to periodically getData and saveData. This saves the running thread to a field called runner.|
| **getFaults():**           | Returns a list of faults in human readable string format. |
| **HEADER**                 | A string used to present battery data. |
| **rowoffset**              | Field used to offset the data from showData.  For stacking outputs. |
| **outputlen**              | Indicator of the number of lines the HEADER and data use. For stacking outputs. |
| **getInverterConfig**      | Returns a dictionary containing battery specific inverter configurations. |
| **NON_RECOVERABLE_FAULTS** | A mask that indicates which faults latch.  Batteries with an alarm that is non-recoverable should be effectively excluded from the system. |

### Database
The database module handles all interactions with data collection, and management.  Each library within this folder implements at a minimum the following:

| Function | Description |
| -------- | ----------- |
| **start():**                  | Launch a thread to begin managing incoming requests. |
| **create():**                 | Creates a new table within the database if it does not already exist, using the SQL string to define the table. |
| **put(sql):**                 | Adds an entry into a table using the provided SQL string. |
| **newEvent(event_message):**  | Add a special entry to flag the start of a new event. |
| **purgeBefore(date):**        | Removes all entries before a specified timestamp. |
| **thinBefore(date, period):** | Removes entries that happen close together leaving only events spaced by more than period of time. |

### Inverter
The inverter is the heart of the EVARC product collecting solar and producing output for EV charging utilizing a combination of battery, solar, and sometimes grid inputs.

| Function | Description |
| -------- | ----------- |
| **getData()**                | Collects data from the inverter. |
| **saveData()**               | Saves collected data to the database. |
| **showData()**               | Returns a string to be used with HEADER, to display the current inverter data.  (also see rowoffset) |
| **start()**                  | Launch a thread to periodically getData and saveData. This saves the running thread to a field called runner.|
| **getFaults()**              | Returns a list of faults in human readable string format. |
| **configure()**              | Sets default system configurations to the inverter. |
| **setChargeVoltage()**       | Sets the bus voltage for charging batteries to Normal/Hibernate/Off. |
| **setOutputRange()**         | Adjusts inverter Smart Load set points. |
| **HEADER**                   | A string used to present inverter data. |
| **rowoffset**                | Field used to offset the data from showData.  For stacking outputs. |
| **outputlen**                | Indicator of the number of lines the HEADER and data use. For stacking outputs. |

### Light
Control the signalling lights on product

| Function | Description |
| -------- | ----------- |
| **turnOn():**        | Turn on indicator light. | 
| **turnOff():**       | Turn off indicator light. | 
| **flash(n):**        | Blink the indicator light n times. | 

### Tracker
The solar tracker maximizes the solar input.

| Function | Description |
| -------- | ----------- |
| **getData():**   | Collects data from the tracker. |
| **saveData():**  | Saves collected data to the database. |
| **showData():**  | Returns a string to be used with HEADER, to display the current tracker data.  (also see rowoffset) |
| **start():**     | Launch a thread to periodically getData and saveData.  This saves the running thread to a field called runner.|
| **idDaytime():** | Returns a boolean indicating if the sun is up. |
| **getFaults():** | Returns a list of faults in human readable string format. |
| **normal():**    | Set tracker to normal opperation. |
| **safe():**      | Set tracker to service mode pointing South. |
| **HEADER**       | A string used to present tracker data. |
| **rowoffset**    | Field used to offset the data from showData.  For stacking outputs. |
| **outputlen**    | Indicator of the number of lines the HEADER and data use. For stacking outputs. |

### Weather
The solar tracker maximizes the solar input.

| Function | Description |
| -------- | ----------- |
| **getData():**   | Collects data from the weather. |
| **showData():**  | Returns a string to be used with HEADER, to display the current weather data.  (also see rowoffset) |
| **start():**     | Launch a thread to periodically getData and saveData.  This saves the running thread to a field called runner.|
| **forecast():**  | Gathers Nathional Weather Service information for the specified location. |
| **HEADER**       | A string used to present tracker data. |
| **rowoffset**    | Field used to offset the data from showData.  For stacking outputs. |
| **outputlen**    | Indicator of the number of lines the HEADER and data use. For stacking outputs. |



