import os
import time
import threading
import traceback

PERIOD = 30
FLAG = "/home/service/HeaterFault"
MAX_TEMP = 0
TIMEOUT = 0

class RunawayHeater:
    def __init__(self, batt, inv, log, config):
        global MAX_TEMP, TIMEOUT
        MAX_TEMP = config['heaterFaultTemp']
        TIMEOUT = config['heaterConfirmTime']
        self.batt = batt         # battery object
        self.inv = inv           # inverter object
        # self.trk = trk           # solar tracker object
        # self.wtr = wtr           # weather object
        # self.db = db             # database logging
        self.log = log           # error logging
        self.lastCheck = 0       # timestamp for intermittent checking
        self.start = 0           # timestamp for start of heater fault
        self.running = False     # escape boolean
        self.status = []         # single line of status for output
        self.action_mask = 50    # mask indicates changes needed for corrective actions

        # action_mask is defined as follows:
        # ----------+---------+------------------------------------
        # |bit      |device   |areas of change
        # ----------+---------+------------------------------------
        # 0      1   tracker   conditiong (service mode)
        # 1      2   batt      revive | shutdown (contactor open)
        # 2      4   batt      heating
        # 3      8   batt      reserved
        # 4      16  inverter  output control (smartload)
        # 5      32  inverter  charge voltage
        # 6-7        inverter  reserved
        # ----------+---------+------------------------------------

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if not self.running:
            if os.path.exists(FLAG):
                self.running = True
                self.status = ["Runaway Heater - Fault: Batteries Shutdown!"]
            elif self.batt.type == "Beam" and time.time() > self.lastCheck + PERIOD:
                self.lastCheck = time.time()
                # RUNAWAY HEATER
                if any([i is not None for i in self.batt.max_temp]):
                    max_temp = max([i for i in self.batt.max_temp if i is not None])
                    if max_temp >= MAX_TEMP:
                        self.log("error", 'action-rh', "Over Temperature fault started")
                        self.status = ["Runaway Heater - Concern"]
                        if self.start == 0:
                            self.start = time.time()
                    elif self.running:
                        self.running = False
                        self.start = 0
                        self.log("info", 'action-rh', "OT fault is fixed")
                        self.status = []

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        try:
            # if overtemp for 3 minutes
            while self.running and time.time() - self.start < TIMEOUT:
                # RUNAWAY HEATER
                if any([i is not None for i in self.batt.max_temp]):
                    max_temp = max([i for i in self.batt.max_temp if i is not None])
                    if max_temp < MAX_TEMP:
                        self.running = False
                        self.start = 0
                        self.log("info", 'action-rh', "OT fault is fixed")
                        self.status = []
                time.sleep(1)
            if self.running:
                self.log("critical", 'EVARC',
                      "Over Temperature fault - shutting off batteries")
                self.status = ["Runaway Heater - Fault: Batteries Shutdown!"]
                open(FLAG, 'w')
                #sendEmail.sendEmail("Stuck Heater", "Batteries were shutdown due to a stuck heater condition")
                self.inv.shutOffInverting()
                self.batt.sendShutdown(0)
        except Exception:
            self.log('critical', 'action-rh', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False


def main():
    import builtins
    import io
    import os
    from unittest.mock import patch

    # Simulated components
    class DummyBattery:
        def __init__(self):
            self.type = 'Beam'
            self.max_temp = [25, 25, 25, 25, 25]
            self._shutdown = False
        def sendShutdown(self, val):
            self._shutdown = True

    class DummyInverter:
        def __init__(self):
            self._off = False
        def shutOffInverting(self):
            self._off = True

    log_messages = []
    class DummyLogger:
        def __call__(self, level, device, mesg):
            nonlocal log_messages
            log_messages.append((level, device, mesg))

    conf = {
        'heaterFaultTemp': 75,
        'heaterConfirmTime': 180  # 3 minutes
    }

    fake_time = [1000000]

    def fake_time_func():
        return fake_time[0]

    def advance_time(seconds):
        fake_time[0] += seconds

    # Setup mocks
    mocked_open = mock_open()
    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    def remove_side_effect(path):
        fake_files.pop(path, None)

    with patch("time.time", side_effect=fake_time_func), \
         patch("time.sleep", side_effect=lambda x: advance_time(x)), \
         patch("builtins.open", side_effect=open_side_effect), \
         patch("os.path.exists", side_effect=lambda path: path in fake_files), \
         patch("os.remove", side_effect=remove_side_effect):

        # Create objects
        b = DummyBattery()
        i = DummyInverter()
        log = DummyLogger()
        act = RunawayHeater(b, i, log, conf)

        # Initial check: nothing abnormal
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running

        # Temperature is high, but just below threshold
        b.max_temp[0] = 74
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)
        advance_time(31)

        # Cross threshold - begins fault
        b.max_temp[0] = 75
        act.check()
        assert act.status, "Expected runaway heater to be detected"
        assert act.start == fake_time[0], "Expected the start time to be set"

        # Drop below threshold - auto-clear
        b.max_temp[0] = 74
        act.run()
        assert act.status == [], "Expected fault to clear"
        assert any("OT fault is fixed" in msg for _, _, msg in log_messages)
        advance_time(31)

        # Hit again with threshold
        b.max_temp[1] = 75
        act.check()
        assert act.status == ["Runaway Heater - Concern"], "Expected runaway heater to be detected"

        # Simulate enough time has passed for fault to trigger
        act.do()

        # Let thread complete
        advance_time(181)

        # Validate critical actions occurred
        assert act.status == ["Runaway Heater - Fault: Batteries Shutdown!"]
        assert i._off
        assert b._shutdown
        assert FLAG in fake_files
        print("✅ Pass: Runaway Heater sequence completed")

if __name__ == "__main__":
    main()

