import os
import time
from datetime import datetime
import threading
import traceback

FLAG = "/home/service/battBalance"

class Balancing:
    def __init__(self, batt, inv, log, config):
        self.START_V = batt.getInvParams(False)['charge_v'] - 0.2
        self.STOP_V = config['balanceStopVoltage'][batt.type]
        self.MAX_DIFF = config['balanceMaxSpread'][batt.type]
        self.batt = batt          # battery object
        self.inv = inv            # inverter object
        # self.trk = trk            # solar tracker object
        # self.wtr = wtr            # weather object
        # self.db = db              # database logging
        self.log = log            # error logging
        self.runner = None        # thread of the runner
        self.running = False      # escape boolean
        self.status = []          # single line of status for output
        self.action_mask = 0x0    # mask indicates changes needed for corrective actions

        # action_mask is defined as follows:
        # ----------+---------+------------------------------------
        # |bit      |device   |areas of change
        # ----------+---------+------------------------------------
        # 0      1   tracker   conditiong (service mode)
        # 1      2   batt      revive | shutdown (contactor open)
        # 2      4   batt      heating
        # 3      8   batt      reserved
        # 4      16  inverter  output control (smartload)
        # 5      32  inverter  charge voltage
        # 6-7        inverter  reserved
        # ----------+---------+------------------------------------

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if not self.running:
            voltages = []
            for i in range(len(self.batt.min_voltage)):
                if self.batt.voltage[i] is not None and \
                   self.batt.faults[i] is not None and \
                   not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS):
                    voltages.append(self.batt.voltage[i])
            if voltages != [] and max(voltages) > self.START_V:
                self.status = ["Cell Balancing - Check"]


    # Method: do
    # Purpose: Launch run task in a thread
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        self.status = ["Cell Balancing - In Progress"]
        try:
            if os.path.exists(FLAG):
                with open(FLAG, 'a') as f:
                    f.write("\n"+datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            else:
                with open(FLAG, 'w') as f:
                    f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            workingOnIt = True
            while self.running and workingOnIt:
                diffs = []
                minv = []
                for i in range(len(self.batt.faults)):
                    if self.batt.min_voltage[i] is not None\
                       and self.batt.max_voltage[i] is not None\
                       and self.batt.faults[i] is not None\
                       and not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS):
                        diffs.append(self.batt.max_voltage[i] - self.batt.min_voltage[i])
                        minv.append(self.batt.min_voltage[i])
                if max(diffs) < self.MAX_DIFF and self.status == ['Cell Balancing - In Progress']:
                    self.status = ['Cell Balancing - Complete']
                    with open(FLAG, 'a') as f:
                        f.write(" - "+datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                elif max(minv) < self.STOP_V and self.status == ['Cell Balancing - In Progress']:
                    self.status = ['Cell Balancing - Incomplete']
                if max(minv) < self.STOP_V:
                    workingOnIt = False
                time.sleep(1)
            # Restore standard configuration
            if self.status == ['Cell Balancing - Complete']:
                self.log('warning', 'action-bb', 'complete')
            self.status = []
            self.running = False
        except Exception:
            self.log('critical', 'action-bb', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch
    class batt:
        def __init__(self):
            self.faults = [0, 0, 0, 0, 0]
            self.type = 'Beam'
            self.NON_RECOVERABLE_FAULTS = 1
            self.min_voltage = [3.95, 3.97, 3.97, 3.97, 3.97]
            self.max_voltage = [3.99, 3.99, 3.99, 3.99, 3.99]
    class inv:
        def __init__(self):
            self._ouput = True
        def shutOffOutput(self):
            self._output = False
        def reqOutputRange(self):
            self._output = True

    def log(level, device, mesg):
        print(mesg)

    action = {
        # Battery Balancing
        "balanceStartVoltage": {
            "Beam": 3.96,
            "EVE": 3.385,
            "Flux": 3.4,
            },
        "balanceMaxSpread": {
            "Beam": 0.05,        
            "EVE": 0.031,
            "Flux": 0.03,
            },
    }


    b = batt()
    i = inv()
    act = Balancing(b, i, log, action)


    # Setup mocks
    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        elif any([i in mode for i in ['w', 'a']]):
            fake_files[file] = io.StringIO()
            return fake_files[file]
        else:
            raise ValueError("Unsupported mode")

    with patch("os.path.isfile", side_effect=lambda path: path in fake_files), \
            patch("builtins.open", side_effect=open_side_effect):

        # Initial check: nothing abnormal
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert act.running is False

        # Stimulate check: Balancing start
        b.min_voltage[0] = 3.97
        act.check()
        assert(act.status == ["Cell Balancing - Required"])
        b.max_voltage[0] = 4.3

        act.do()
        assert(act.status == ["Cell Balancing - In Progress"])
        assert(act.running)
        b.max_voltage[0] = 3.98
        time.sleep(0.1)
        assert(act.status == [])
        act.check()
        assert(act.running)
        b.min_voltage = [3.5, 3.5, 3.5, 3.5, 3.5]
        b.max_voltage = [3.5, 3.5, 3.5, 3.5, 3.5]
        
        time.sleep(0.1)
        act.check()
        assert(act.status == [])
        assert(not act.running)

        b.min_voltage = [4.8] * 5
        b.max_voltage = [4.8, 4.8, 4.8, 4.8, 4.91]
        act.check()
        assert(act.status == ["Cell Balancing - Required"])

        act.do()
        assert(act.running)
        assert(act.status == ["Cell Balancing - In Progress"])
        b.min_voltage[4] = 4.811
        assert(act.running)
        assert(act.status == ["Cell Balancing - In Progress"])

        b.min_voltage = [3.5, 3.5, 3.5, 3.5, 3.5]
        b.max_voltage = [3.5, 3.5, 3.5, 3.5, 3.5]
        
        act.check()
        time.sleep(0.1)
        assert(act.status == [])
        assert(not act.running)
        print("✅ Pass: Battery Balancing sequence completed")


if __name__=="__main__":
    main()
