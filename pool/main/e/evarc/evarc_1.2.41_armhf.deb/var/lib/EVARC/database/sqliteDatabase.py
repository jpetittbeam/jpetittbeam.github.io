#!/usr/bin/python3
import sqlite3
import threading
import queue
import os
import traceback
import time

FILENAME = os.path.dirname(os.path.abspath(__file__)) + "/../EVARC.db"

class Database:
    """SQLite database wrapper"""
    def __init__(self, name=None):
        """Database object initializer (optional argument database PATH)"""
        if name is None:
            self.filename = FILENAME
        else:
            self.filename = name
        self.stop = False
        self.q = queue.Queue()
        self.lock = threading.Lock()
        self.log = print
        self.event = int(time.time())

    def put(self, sql):
        """Add sql command to queue to be proecessed"""
        self.q.put(sql)

    def addLogCallback(self, log):
        """Add a logging callback function"""
        self.log = log
        
    def start(self):
        """Process: looping threaded function that takes commands from db.q and submit them to the database"""
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        """Method: looping takes commands from db.q and submit them to the database"""
        self.lock.acquire()
        con = sqlite3.connect(self.filename)
        cursor = con.cursor()
        while not self.stop:
            try:
                while not self.q.empty():
                    cmd = self.q.get()
                    if cmd == "VACUUM":
                        con.commit()
                    # TODO add command checking
                    cursor.execute(cmd)
                con.commit()
                time.sleep(1)
            except Exception:
                self.log('critical', 'database', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")
        con.commit()
        con.close()
        self.lock.release()

    def create(self, creator):
        """Create a table using the provided string, unless that table is in the database"""
        acquired = self.lock.acquire(blocking=False)
        if not acquired:
            self.stop = True
            self.lock.acquire()
        con = sqlite3.connect(self.filename)
        cursor = con.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        tables = [i[0] for i in tables]
        table = creator[13:creator.find(" ",13)].strip()
        if table not in tables:
            cursor.execute(creator)
            ret_value = cursor.fetchall()
        else:
            ret_value = 1
        con.commit()
        con.close()
        self.lock.release()
        if not acquired:
            self.start()
        return ret_value

    def purgeBefore(self, timestamp):
        """remove all data from database before specified timestamp"""
        raise NotImplementedError

    def thinBetween(self, start, stop, table, period):
        """remove all data from database before specified timestamp"""
        raise NotImplementedError

def main():
    print("Database Library\nVersion: 0.0.1")
    print("\nExample:\nimport database\ndb=database.Database()")
    print("db.create(\"CREATE TABLE my_table(id INTEGER PRIMARY KEY, column1 TEXT, column2 REAL);\")")
    print("db.put(\"INSERT INTO my_table VALUES ('Item1', 43.2);\")")
    print("db.stop = True")
    print("db.lock.acquire()")

if __name__ == "__main__":
    main()

