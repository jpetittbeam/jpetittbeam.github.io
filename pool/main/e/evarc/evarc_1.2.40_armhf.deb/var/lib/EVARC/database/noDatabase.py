#!/usr/bin/python3
import sqlite3
import threading
import queue
import os
import traceback
import time

FILENAME = os.path.dirname(os.path.abspath(__file__)) + "/../EVARC.db"

class Database:
    """SQLite database wrapper"""
    def __init__(self, name=None):
        """Database object initializer (optional argument database PATH)"""
        if name is None:
            self.filename = FILENAME
        else:
            self.filename = name
        self.stop = False
        self.q = queue.Queue()
        self.lock = threading.Lock()
        self.log = print
        self.event = int(time.time())

    def put(self, sql):
        """Add sql command to queue to be proecessed"""
        pass

    def addLogCallback(self, log):
        """Add a logging callback function"""
        self.log = log
        
    def start(self):
        """Process: looping threaded function that takes commands from db.q and submit them to the database"""
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        """Method: looping takes commands from db.q and submit them to the database"""
        while not self.stop:
            pass

    def create(self, creator):
        """Create a table using the provided string, unless that table is in the database"""
        pass

    def purgeBefore(self, timestamp):
        """remove all data from database before specified timestamp"""
        raise NotImplementedError

    def thinBetween(self, start, stop, table, period):
        """remove all data from database before specified timestamp"""
        raise NotImplementedError

def main():
    print("Database Library\nVersion: 0.0.1")
    print("\nExample:\nimport database\ndb=database.Database()")
    print("db.create(\"CREATE TABLE my_table(id INTEGER PRIMARY KEY, column1 TEXT, column2 REAL);\")")
    print("db.put(\"INSERT INTO my_table VALUES ('Item1', 43.2);\")")
    print("db.stop = True")
    print("db.lock.acquire()")

if __name__ == "__main__":
    main()

