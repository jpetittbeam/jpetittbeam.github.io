import time
import os
import threading
import traceback

FLAG = "/home/service/trkConditioning"
TIMEOUT = 0
PERIOD = 60

class TrackerRevive:
    def __init__(self, trk, log, config):
        global TIMEOUT
        TIMEOUT = config['trackerReviveTimer']
        # self.batt = batt         # battery object
        # self.inv = inv           # inverter object
        self.trk = trk           # solar tracker object
        # self.wtr = wtr           # weather object
        self.log = log           # error logging
        self.runner = None       # thread of def runner
        self.running = False     # escape boolean
        self.status = []         # lines of status output
        self.action_mask = 1     # 1 to 10; 10 being highest priority
        self.lastCheck = 0

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if time.time() > self.lastCheck + PERIOD: 
            # check service mode for current state
            if self.trk.service is not None and self.trk.service.lower() == 'on':
                if os.path.isfile(FLAG):
                    self.status = []
                else:
                    self.status = ['Tracker is in service mode']
            else:
                self.status = []

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if (self.runner is None):
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        try:
            # if weather is available wait for a sunny day
            # if not then wait for morning 
            # this will provide the best chance to recover
            with open('/proc/uptime', 'r') as f:
                uptime = float(f.readline().split()[0])
            while (uptime < TIMEOUT):
                with open('/proc/uptime', 'r') as f:
                    uptime = float(f.readline().split()[0])
                time.sleep(1) 
            # The time is right
            self.log("error", "action-trk", "Tracker is in service mode")
            self.lastCheck = time.time()
            #self.trk.normal()   #Not including this for now in case of fault
            #self.status = []
            #self.running = False
        except Exception:
            self.log('critical', 'action-tr', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch
    
    # Dummy classes
    class trk:
        def __init__(self):
            self.service = "Off"
            self.sun_el = 6
        def safe(self):
            self.service = "On"
        def normal(self):
            self.service = "Off"
    class wtr:
        sunny = None
    class ti:
        def __init__(self):
            self.tm_hour = 3
        def localtime(self):
            print("hey")
            return self
    def sleep(t):
        global time
        time.sleep(t)
    def log(level, device, mesg):
        #print(mesg)
        pass
    conf = {
        'trackerReviveTimer': 20
    }

    # Setup mocks
    fake_time = [1000000]

    def advance_time(seconds):
        fake_time[0] += seconds
        return fake_time[0]

    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    with patch("os.path.isfile", side_effect=lambda path: path in fake_files), \
         patch("builtins.open", side_effect=open_side_effect), \
         patch("os.remove", side_effect=lambda path: fake_files.pop(path)), \
         patch("os.path.exists", side_effect=lambda path: path in fake_files), \
         patch('time.time', side_effect=lambda: advance_time(1)), \
         patch('time.sleep', side_effect=lambda x: advance_time(x)):

        # Create objects
        time = ti()
        
        t = trk()
        act = TrackerRevive(t, log, conf)
        
        act.check()
        assert(act.status == [])

        t.service = "On"
        act.check()
        assert(act.status == ["Tracker is in service mode"])
        
        f = open("/proc/uptime", 'w')
        f.write('25')
        open(FLAG, 'w')
        act.check()
        assert(act.status == [])

        os.remove(FLAG)
        act.check()
        act.do()
        assert(act.status == ["Tracker is in service mode"])
        print("✅ Pass: Tracker Revive sequence completed")

if __name__=="__main__":
    main()

