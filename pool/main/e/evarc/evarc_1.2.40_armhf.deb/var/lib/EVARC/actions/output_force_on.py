import os
import time
import threading
import traceback

FLAG = "/home/service/service"

class OutputForceOn:
    def __init__(self, inv, log):
        # self.batt = batt         # battery object
        self.inv = inv           # inverter object
        # self.trk = trk           # solar tracker object
        # self.wtr = wtr           # weather object
        # self.db = db             # database logging
        self.log = log           # error logging
        #self.runner = None       # thread of def runner
        self.running = False     # escape boolean
        self.status = []         # lines of status output
        self.action_mask = 0     # mask indicates changes needed for correction
        self.start = 0           # time of force on starting

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if not self.running:
            # CHECK FOR FORCE OUTPUT SIGNAL
            if os.path.exists(FLAG):
                with open(FLAG, 'r') as f:
                    state = f.read()
                    if state.strip().lower() == "on":
                        self.status = ["Forcing On Output"]

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        self.log('error', 'action-on', 'Forcing Output On')
        try:
            self.inv.forceOutputOn()
            while self.running and os.path.exists(FLAG):
                with open(FLAG, 'r') as f:
                    state = f.read()
                    if state.strip().lower() == "on":
                        self.status = ["Output Forced On"]
                        time.sleep(1)
                    else:
                        self.status = []
                        self.running = False
            self.status = []
            self.running = False
        except Exception:
            self.log('critical', 'action-on', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False


def main():
    import io
    from unittest.mock import patch, mock_open

    # Setup mocks
    mock_content = mock_open(read_data="On")
    fake_file = False
    fake_time = [1000000]

    def advance_time(t):
        nonlocal fake_time
        fake_time[0] = fake_time[0] + t
        return fake_time[0]

    class inv:
        def __init__(self):
            self._output = False
        def forceOutputOn(self):
            self._output = True

    def log(level, device, mesg):
        #print(mesg)
        pass

    with patch("os.path.isfile", side_effect=lambda path: fake_file), \
         patch("builtins.open", mock_content), \
         patch("os.path.exists", side_effect=lambda path: fake_file), \
         patch("time.time", side_effect=lambda: fake_time[0]), \
         patch("time.sleep", side_effect=advance_time):

        # create objects
        i = inv()
        act = OutputForceOn(i, log) 

        # Initial check: nothing abnormal
        act.check()
        assert act.status == []
        assert not act.running

        # Stimulate check: file
        fake_file = True
        act.check()
        assert len(act.status) > 0
        assert "Forcing On Output" == act.status[0]

        # Run the action
        act.do()
        assert act.status[0] == "Output Forced On"
        assert i._output
        assert act.running

        # Verify return to normal operation
        fake_file = False
        while act.running:
            print("\r", end="")
        act.check()
        assert not act.running
        assert act.status == []
        print("✅ Pass: Force Output On sequence completed")

if __name__=="__main__":
    main()

