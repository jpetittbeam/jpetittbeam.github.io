import os
import time
import threading
import traceback

FLAG = "/home/service/voltageReduction"
OVERAGE = 0
LOWER_V = 0

class OverchargeVoltageReduction:
    def __init__(self, batt, inv, log, config):
        global OVERAGE, LOWER_V
        OVERAGE = config['overchargeHighVoltageOverage']
        LOWER_V = config['lowerChargeVoltage']
        self.batt = batt         # battery object
        self.inv = inv           # inverter object
        # self.trk = trk           # solar tracker object
        # self.wtr = wtr           # weather object
        self.log = log           # error logging
        self.runner = None       # thread of the runner
        self.running = False     # escape boolean
        self.status = []         # lines of status output
        self.action_mask = 32    # mask indicates changes needed for corrective actions

        # action_mask is defined as follows:
        # ----------+---------+------------------------------------
        # |bit      |device   |areas of change
        # ----------+---------+------------------------------------
        # 0      1   tracker   conditiong (service mode)
        # 1      2   batt      revive | shutdown (contactor open)
        # 2      4   batt      heating
        # 3      8   batt      reserved
        # 4      16  inverter  output control (smartload)
        # 5      32  inverter  charge voltage
        # 6-7        inverter  reserved
        # ----------+---------+------------------------------------

    # Method: check
    # Purpose: Evaluates if task is necessary updates status array
    #      status == [] if no action is needed
    # Input Arguments: None
    # Return Value: None
    def check(self):
        if not self.running:
            if os.path.exists(FLAG):
                self.status = ["Batteries Overcharge"]
            for i in range(len(self.batt.voltage)):
                if (self.batt.voltage[i] is not None and 
                    self.batt.faults[i] is not None and 
                    not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS)):
                    if self.inv.MAX_CHARGE_VOLTAGE is not None and self.batt.voltage[i] > (self.inv.MAX_CHARGE_VOLTAGE + OVERAGE):
                        self.status = ["Batteries Overcharge"]

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if (self.runner is None):
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        self.status = ["Batteries Overcharge - Reducing Voltage"]
        try:
            # Perform confirgurtaion changes
            max_charge_voltage = 0
            if not os.path.exists(FLAG):
                self.inv.reqChargeVoltage(LOWER_V)
                open(FLAG, 'w')
            else:
                with open(FLAG, 'r') as f:
                    try:
                        max_charge_voltage = float(f.read())
                    except Exception:
                        pass

            workingOnIt = True
            self.log("error", "action-vr", "Overcharge event")
            while self.running and workingOnIt:
                voltages = []
                for i in range(len(self.batt.voltage)):
                    if (self.batt.voltage[i] is not None and
                        self.batt.faults[i] is not None and 
                        not (self.batt.faults[i] & self.batt.NON_RECOVERABLE_FAULTS)):
                        voltages.append(float(self.batt.voltage[i]))
                if voltages != [] and max(voltages) > max_charge_voltage:
                    max_charge_voltage = max(voltages)
                    with open(FLAG, 'w') as f:
                        f.write(str(max_charge_voltage))
                if voltages != [] and max(voltages) < self.inv.MAX_CHARGE_VOLTAGE:
                    self.status = []
                    workingOnIt = False
            if self.status == []:
                self.log("error", "action-vr", "Overcharge event cleared.  Maximum voltage=" + str(max_charge_voltage))
                self.inv.reqChargeVoltage(2*self.inv.MAX_CHARGE_VOLTAGE - max_charge_voltage)
                os.remove(FLAG)
                self.running = False
                self.runner = None
        except Exception:
            self.log('critical', 'action-vr', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False

def main():
    import io
    from unittest.mock import patch, MagicMock
    global PERIOD
    
    # Setup mocs
    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            fake_files[file].close = lambda: True
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    # Mock classes
    class inv:
        def __init__(self):
            self.MAX_CHARGE_VOLTAGE = 100
            self._chargeV = None
        def reqChargeVoltage(self, v=90):
            self._chargeV = v 
    class batt:
        def __init__(self):
            self.voltage = [100, 99, 99, 99, None]
            self.faults = [0, 0, 0, 0, 0]
            self.NON_RECOVERABLE_FAULTS = 1
    class db:
        def __init__(self):
            self._configured = False
            self.put_calls = []
        def put(self, msg):
            self.put_calls.append(msg)
            self._configured = True

    # Mock logger
    log = MagicMock()

    config = {
        # Overcharge Voltage Reduction
        "overchargeHighVoltageOverage": 0.5,
        "lowerChargeVoltage": 52,
    }
    with patch('builtins.open', side_effect=open_side_effect), \
         patch('os.path.exists', side_effect=lambda path: path in fake_files), \
         patch('os.path.isfile', side_effect=lambda path: path in fake_files), \
         patch('os.remove', side_effect=lambda path: fake_files.pop(path)), \
         patch('time.time', return_value=10000000):

        i = inv()
        b = batt()
        act = OverchargeVoltageReduction(b, i, log, config)

        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        fake_files[FLAG] = 'trigger'
        act.check()
        assert act.status == ["Batteries Overcharge"], "Exepcted activate status, got "+str(act.status)

        fake_files.pop(FLAG)

        b.voltage[0] = 101
        act.check()
        assert act.status == ["Batteries Overcharge"], "Exepcted activate status, got "+str(act.status)

        act.do()
        assert act.running
        assert i._chargeV == 52
        assert act.status == ["Batteries Overcharge - Reducing Voltage"]

        b.voltage[0] = 98
        while act.running:
            pass

        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running
        
        print("✅ Pass: Overcharge Voltage Reduction sequence completed")

if __name__=="__main__":
    main()
