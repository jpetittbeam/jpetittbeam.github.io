import traceback
import threading
import cantools
import time
import can
import os

class Listener:
    def __init__(self, inv, trk, lit, log, conf):
        """Create a new CANbus listener"""
        self.dcfc_iface = conf['dcfc_iface']
        self.dcfc_id = conf['dcfc_id']
        self.inv = inv
        self.trk = trk
        self.lit = lit
        self.log = log
        self.stop = False

    def start(self):
        """Launch a thread to collect, record, and report the inverter data"""
        self.stop = False
        self.runner = threading.Thread(target=self.listen, daemon=True)
        self.runner.start()

    def listen(self):
        """Method that listens for system controller messages"""
        if self.dcfc_id is None or self.dcfc_iface is None:
            return
        # open CAN interface
        bus = can.interface.Bus(self.dcfc_iface, bustype='socketcan')
        db = cantools.database.load_file(
            os.path.dirname(os.path.abspath(__file__)) + "/dbc/DCFC_ARC_001.dbc")
        loop_count = 0
        while not self.stop:
            try:
                # receive messages
                msg = bus.recv(1)
                if msg is not None and msg.arbitration_id == 288:
                    res = db.decode_message(288, msg.data)
                    self.log('info', 'canlisten', 'Command: %s, Arg1: %s, Arg2: %s'%(res['Command'], res['Argument1'], res['Argument2']))
                    self.log('info', 'canlisten', 'Listener received message: '+' '.join([hex(i)[2:] for i in msg.data]))
                    # check if message is from controller
                    if res['Source'] == 0:
                        args = [None if res['Argument1'] == 655.35 else res['Argument1'],
                                None if res['Argument2'] == 655.35 else res['Argument2'],
                                None if res['Argument3'] == 655.35 else res['Argument3']]
                        # run command locally
                        if res['Command'] == 0 and self.dcfc_id == 1:
                            self.inv.configure()
                        elif res['Command'] == 1 and self.dcfc_id == 1:
                            self.log('debug', 'canlisten', 'Listener setting output range: %s, %s'%(
                                args[0], args[1]))
                            self.inv.setOutputRange(args[0], args[1])
                        elif res['Command'] == 2 and self.dcfc_id == 1:
                            self.log('debug', 'canlisten', 'Listener setting operating range: %s, %s, %s'%(
                                args[0], args[1], args[2]))
                            self.inv.setOperatingRange(args[0], args[1], args[2])
                        elif res['Command'] == 3 and self.dcfc_id == 1:
                            self.log('debug', 'canlisten', 'Listener setting charge voltage: %s'%(args[0]))
                            self.inv.setChargeVoltage(args[0])
                        elif res['Command'] == 4 and self.dcfc_id == 1:
                            self.log('debug', 'canlisten', 'Listener setting charge current to '+str(args[0]))
                            self.inv.setChargeCurrent(args[0])
                        elif res['Command'] == 5:
                            if args[0] == 0.0:
                                self.log('debug', 'canlisten', 'Listener setting tracker to Normal')
                                self.trk.normal()
                            elif args[0] == 0.01:
                                self.log('debug', 'canlisten', 'Listener setting tracker to face South')
                                self.trk.safe()
                            elif args[0] == 0.02:
                                self.log('debug', 'canlisten', 'Listener setting tracker to clear encoder')
                                self.trk.clrEncoder()
                            elif args[0] == 0.03:
                                self.log('debug', 'canlisten', 'Listener setting tracker to service Mode')
                                self.trk.smode()
                            else:
                                self.log('warning', 'canlisten',
                                        'Listener received tracker directive %f and no callback is available'%(args[0]))
                        elif res['Command'] == 6:
                            self.log('debug', 'canlisten', 'Listener setting light to '+str(args[0]))
                            if args[0] == 0:
                                self.lit.turnOff()
                            elif args[0] == 0.01:
                                self.lit.turnOn()
                        else:
                            # Unknown Command: just ignore
                            pass
                loop_count = 0
                time.sleep(0.2)
            except can.CanError:
                loop_count += 1
                if loop_count > 10:
                    os.system("sudo ip link set %s down"%(self.dcfc_iface))
                    os.system("sudo ip link set %s up type can bitrate 80000"%(self.dcfc_iface))
                    self.log('warning', "canlisten", "Restarted CAN interface")
            except Exception:
                self.log('critical', 'canlisten', 'Thread listener crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time())+"\n")
                    f.write(traceback.format_exc()+"\n")

def main():
    class Inv:
        def __init__(self):
            self._outputOn = False
            self.chargeV = 10
            self.sd_v = 2
            self.re_v = 4
            self.lb_v = 3
            self.sl_off = 3
            self.sl_on = 4
        def setChargeVoltage(self, v1):
            self.chargeV = v1
        def setOutputRange(self, sl_off, sl_on):
            self.sl_off = sl_off
            self.sl_on = sl_on
        def setOperatingRange(self, sdV, rsV, lbV):
            self.sd_v = sdV
            self.re_v = rsV
            self.lb_v = lbV
        def isOutputOn(self):
            return self._outputOn
    class Trk:
        def __init__(self):
            self.tracking = False
        def safe(self):
            self.tracking = False
        def normal(self):
            self.tracking = True
    class Light:
        def __init__(self):
            self.state = None
        def turnOn(self):
            self.state = "ON"
        def turnOff(self):
            self.state = "OFF"
    class db:
        def create(self, s):
            pass
        def put(self, s):
            pass
    def log(level, device, message):
        if level == "debug":
                level = "\x1b[37m"
        elif level == "info":
                level = "\x1b[97m"
        elif level == "warning":
                level = "\x1b[93m"
        elif level == "error":
                level = "\x1b[91m"
        elif level == "critical":
                level = "\x1b[31m"
        print(level+"|"+device+"|"+message+"\033[0m")
    lis = Listener(Inv(), Trk(), Light(), log, {'dcfc_iface': "can0", 'dcfc_id': 2})
    lis.listen()


if __name__=="__main__":
    main()
