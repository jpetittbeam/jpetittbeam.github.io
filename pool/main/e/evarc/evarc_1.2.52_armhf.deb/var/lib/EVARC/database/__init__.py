try:
    with open("/sys/kernel/debug/mmc2/mmc2:0001/ext_csd") as fh:
        fh.seek(538)
        if int(fh.read(2), 16) > 10:
            from database.noDatabase import *
        else:
            from database.sqliteDatabase import *
except Exception:
    from database.sqliteDatabase import *
