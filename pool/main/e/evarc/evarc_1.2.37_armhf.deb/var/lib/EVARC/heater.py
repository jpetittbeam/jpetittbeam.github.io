#!/usr/bin/python3
import time
import traceback
import threading
import subprocess

FLAG = "/var/lib/EVARC/heating"

class Heater:
    def __init__(self, batt, inv, trk, db, log, conf, bg_proc):
        self.batt = batt
        self.inv = inv
        self.trk = trk
        self.db = db
        self.log = log
        self.bg_proc = bg_proc
        self.stop = False
        self.p_stop = True
        self.h_stop = True
        self.sys_revive = lambda: False
        self.pid = conf['heater_pid']
        self.heat_start = conf['temperatureMinStart']
        self.heat_stop = conf['temperatureMinStop']
        self.too_diff = conf['temperatureMaxDelta']
        self.v_cut = conf['lowVoltageCutOff']
        self.v_target = conf['voltageTarget']
        self.maxDutyCycle = conf['maximumDutyCycle']
        self.ctrl = (0, 0)   # (DutyCycle, Error)
        self.heat_params = (0, 0, 0)
        self.HEADER = "        Heating Batteries: "
        self.last_status = ""
        self.status = ""
        self.transitioned = False
        db.create("CREATE TABLE heating (id INTEGER PRIMARY KEY, timestamp COVERT_TIMESTAMP, status TEXT)")
        self.sql = "INSERT INTO heating (timestamp, status) VALUE (%f, %s)"

        #Initialize from FLAG
        self.bank1_en = False
        self.bank2_en = False
        self.failcount = 0
        self.delayed_start = time.time() + 60

    def showData(self):
        """Output current heater state"""
        return "\x1b[%d;%df%s" % (self.rowoffset + 1, self.columnoffset + 27, self.status)

    def getData(self):
        """Update state"""
        if self.batt.type == "Beam":
            self.status = "%12s" % str([self.batt.batt_id[i] for i in range(len(
                                        self.batt.heater)) if self.batt.heater[i]])[1:-1]
            return
        if time.time() < self.delayed_start:
            return

        if self.p_stop and not self.stop:
            #launch solar heating helper thread
            self.log('error', 'heater', "solar heating started")
            time.sleep(10)
            self.p_stop = False
            self.p_runner = threading.Thread(target=self.solarHeat, daemon=True)
            self.p_runner.start()
        else:
            #check for a crash
            if not self.p_runner.is_alive():
                self.log('error', 'heater', "solar heating crashed...restarting thread")
                self.p_runner.join()
                self.p_runner = threading.Thread(target=self.solarHeat, daemon=True)
                self.p_runner.start()

        if self.h_stop and not self.stop:
            self.h_stop = False
            self.bg_proc[0] = subprocess.Popen(["/var/lib/EVARC/heatManager.sh"])
        else:
            #check for a crash
            if self.bg_proc[0].poll() is not None:
                self.log('error', 'heater', "heat manager crashed...restarting thread")
                self.bg_proc[0] = subprocess.Popen(["heatManager.sh"])
             
    def saveData(self):
        """Write state to database"""
        if self.status != self.last_status:
            self.last_status = self.status
            self.db.put(self.sql % (time.time(), self.last_status))

    def start(self):
        """Launch a tread to collect, collect and report heater data"""
        self.stop = False
        self.runner = threading.Thread(target=self.run, daemon=True)
        self.runner.start()

    def run(self):
        """Perform heater status updates"""
        while not self.stop:
            try:
                self.getData()
                time.sleep(2)
            except Exception:
                self.log('critical', 'heater', 'Thread crashed see /var/log/EVARC.log')
                with open("/var/log/EVARC.log", 'a+') as f:
                    f.write(str(time.time()) + "\n")
                    f.write(traceback.format_exc() + "\n")

    def solarHeat(self):
        """Manage heating from sun using PID algorithm"""
        integral = 0
        prev_time = time.time()
        while not self.p_stop:
            if any([False] + self.batt.contactor):
                #self.log('error', 'heater', 'Bypass: battery connected'+str(self.batt.contactor))
                self.heat_params = [(1, 2, 1)]
                time.sleep(3)
            else:
                #self.log('error', 'heater', 'Voltage: '+str(self.inv.batt_V)+
                #         ' Error: '+str(self.ctrl[1])+' Duty_Cycle: '+str(self.ctrl[0])+
                #         ' Enable: '+str(self.heat_params[2] + 2*self.bank1_en + 4*self.bank2_en))
                try:
                    g1 = [self.batt.min_temp[i] for i in range(4) if self.batt.min_temp[i] is not None]
                    g2 = [self.batt.min_temp[i] for i in range(4,len(self.batt.min_temp)) \
                            if self.batt.min_temp[i] is not None]
                    ht = max([self.batt.max_temp[i] for i in range(len(self.batt.max_temp)) \
                            if self.batt.max_temp[i] is not None])
                    if ht - min(g1+g2) > 15:
                        if self.bank1_en or self.bank2_en:
                            self.log('error', 'heater', 'Temperature Variance Too High')
                        self.bank1_en = False
                        self.bank2_en = False
                    elif min([self.v_cut] + [self.batt.voltage[i] \
                            for i in range(len(self.batt.voltage)) \
                            if self.batt.voltage[i] is not None and \
                            self.batt.contactor[i]]) < self.v_cut:
                        if self.bank1_en or self.bank2_en:
                            self.log('error', 'heater', 'Battery Voltage Too Low')
                        self.bank1_en = False
                        self.bank2_en = False
                    else:
                        if self.bank1_en:
                            self.bank1_en = min(g1) < self.heat_stop
                        else:
                            self.bank1_en = min(g1) < self.heat_start
                        if self.bank2_en:
                            self.bank2_en = min(g2) < self.heat_stop
                        else:
                            self.bank2_en = min(g2) < self.heat_start

                    self.inv.batt_V = self.inv.read_register(*self.inv.READ_REGISTERS['batt_V'])
                    while self.inv.batt_V is None:
                        time.sleep(2)
                        self.inv.batt_V = self.inv.read_register(*self.inv.READ_REGISTERS['batt_V'])

                    (duty_cycle, error, integral) = pid_controller(
                            self.inv.MAX_CHARGE_VOLTAGE * self.v_target, #setpoint
                            self.inv.batt_V, # measured
                            self.pid[0],
                            self.pid[1],
                            self.pid[2],
                            self.ctrl[1],
                            integral,
                            time.time() - prev_time,
                            self.log)
                    prev_time = time.time()
                    #error = self.inv.batt_V - self.inv.MAX_CHARGE_VOLTAGE * self.v_target
                    ## duty_cycle = duty_cycle(old) + Proportional + Integral + Derivative
                    #self.log('error', 'heater', 'Proportional: '+str(error*self.pid[0]))
                    #self.log('error', 'heater', 'Integral: '+str((error+self.ctrl[1])*self.pid[1]))
                    #self.log('error', 'heater', 'Derivative: '+str((self.ctrl[1]+error)*self.pid[2]))
                    #duty_cycle = self.ctrl[0] + error * self.pid[0] + \
                    #             (error + self.ctrl[1]) * self.pid[1] + \
                    #             (self.ctrl[1] - error) * self.pid[2]
                    if duty_cycle < 0.0098:
                        # No Heating:
                        self.bank1_en = False
                        self.bank2_en = False
                        time.sleep(30)
                        self.ctrl = (0, error)
                    elif duty_cycle < 0.1:
                        self.heat_params = (duty_cycle * 10 / (1 - 2 * duty_cycle), # On Time
                                             5, # Off Time
                                             0) # Dual Banks
                        self.ctrl = (duty_cycle, error)
                    elif duty_cycle < self.maxDutyCycle:
                        self.heat_params = (duty_cycle * 2 / (1 - duty_cycle), # On Time
                                             2, # Off Time
                                             1) # Dual Banks
                        self.ctrl = (duty_cycle, error)
                    else:
                        self.heat_params = (self.maxDutyCycle * 2 / (1 - self.maxDutyCycle), 2, 1)
                        self.ctrl = (self.maxDutyCycle, error)
                    with open("/var/lib/EVARC/heating", 'w') as f:
                        f.write("ON_TIME="+str(self.heat_params[0]) + \
                                "\nOFF_TIME="+str(self.heat_params[1]) + \
                                "\nDUAL_HEAT="+str(self.heat_params[2] + 2*self.bank1_en + 4*self.bank2_en))
                    time.sleep(3) 
                except Exception:
                    self.log('critical', 'heater', 'Thread crashed see /var/log/EVARC.log')
                    with open("/var/log/EVARC.log", 'a+') as f:
                        f.write(str(time.time()) + "\n")
                        f.write(traceback.format_exc() + "\n")

def pid_controller(setpoint, pv, kp, ki, kd, previous_error, integral, dt, log):
    # Calculate error
    error = setpoint - pv
    
    # Proportional term
    proportional = kp * error
    
    # Integral term
    integral += error * dt
    integral_term = ki * integral
    
    # Derivative term
    derivative = (error - previous_error) / dt
    derivative_term = kd * derivative
    
    # Total output
    #log('error', 'heater', str(proportional)+', '+str(integral_term)+', '+str(derivative_term))
    output = proportional + integral_term + derivative_term
    
    return output, error, integral
