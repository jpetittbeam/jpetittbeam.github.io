import os
import time
import threading
import traceback

FLAG = "/home/service/sysConditioning"
trkFLAG = "/home/service/trkConditioning"
nuisFLAG = "/home/service/nuisanceBatteries"
stuckFLAG = "/home/service/beam_stuck_battery"


class SystemRevive:
    def __init__(self, batt, inv, trk, wtr, log, config):
        self.LOW_VOLTAGE = config["lowVoltageWarning"][batt.type]
        self.CLEAR_VOLTAGE = config["lowVoltageClear"][batt.type]
        self.batt = batt  # battery object
        self.inv = inv  # inverter object
        self.trk = trk  # solar tracker object
        self.wtr = wtr  # weather object
        self.log = log  # error logging
        self.runner = None  # thread of def runner
        self.running = False  # thread
        self.status = []  # lines of status output
        self.action_mask = 0x32  # mask indicates changes needed for corrective actions
        self.ifdown_end = None
        self.init_time = time.time() + 80

    # Method: check
    # Purpose: Evaluates if task is necessary
    # Input Arguments: None
    # Return Value: True if task is required for correction;
    #               False if system operation is good
    def check(self):
        if not self.running:
            if os.path.isfile(stuckFLAG):
                with open(stuckFLAG, "r") as f:
                    self.ifdown_end = float(f.read())
                    self.status = ["System Revive - Stuck Battery"]
            elif os.path.isfile(FLAG):
                with open(FLAG, "r") as f:
                    self.status = ["System Revive - " + f.read()]
            else:
                if os.path.isfile(nuisFLAG):
                    with open(nuisFLAG, "r") as f:
                        nuisanceBatt = eval(f.read())
                        self.status = [
                            "System Revive - " + i
                            for i in self.batt.getStatus(nuisanceBatt)
                        ]
                else:
                    self.status = [
                        "System Revive - " + i for i in self.batt.getStatus()
                    ]

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        nuisanceBatt = []
        try:
            # read nuisance battery list
            if os.path.isfile(nuisFLAG):
                with open(nuisFLAG, "r") as f:
                    nuisanceBatt = eval(f.read())

            # SOFTWARE RESTARTED DURING INTERFACE RESET
            if self.ifdown_end is not None:
                self.log(
                    "error",
                    "action-sr",
                    "Beam stuck battery, exp: " + str(self.ifdown_end)
                )
                fault_state = []
                while time.time() < self.ifdown_end:
                    self.status = ["System Revive - Interface Reset %d:%02d" % (
                        (time.time()-self.ifdown_end)/3600,
                        (self.ifdown_end-time.time())%3600/60)]
                    time.sleep(60)
                    if fault_state != self.batt.recovery + self.batt.lf_role + self.batt.faults:
                        lowest=0
                        for i in range(len(self.batt.voltage)):
                            if self.batt.voltage[i] < self.batt.voltage[lowest] \
                               and self.batt.batt_id[i] not in nuisanceBatt:
                                lowest = i
                        self.batt.sendBusVoltage(self.batt.voltage[lowest])
                        if renegotiate(self.batt.encourage, self.batt.voltage, lowest):
                            break
                        else:
                            fault_state = self.batt.recovery + self.batt.lf_role + self.batt.faults
                self.batt.sstop = False
                os.remove(stuckFLAG)
                time.sleep(2)
                self.ifdown_end = None
            self.negotiation_start = time.time()

            # If necessary set tracker to point South
            # if min_voltage < low voltage
            # or if too few batteries on bus
            if (
                self.trk.service is not None
                and self.trk.service.lower() == "off"
                and (
                    any(
                        [
                            self.batt.min_voltage[i] < self.LOW_VOLTAGE
                            for i in range(len(self.batt.voltage))
                            if self.batt.min_voltage[i] is not None
                            and self.batt.batt_id[i] not in nuisanceBatt
                        ]
                    )
                    or sum(
                        [
                            self.batt.contactor[i]
                            for i in range(len(self.batt.voltage))
                            if self.batt.contactor[i] is not None
                        ]
                    )
                    < (4 if self.batt.type == "EVE" else 2)
                )
            ):
                self.trk.safe()
                time.sleep(3)
                while (self.trk.servo is None or "idle" not in self.trk.servo.lower()):
                    time.sleep(4)
                    self.status = ['System Revive - Trk: Orienting South']
                if round(self.trk.trk_az) != 180:
                    self.trk.safe()
                with open(trkFLAG, "w") as f:
                    f.write("Tracker Conditioning - Low Capacity")

            # Turn off output
            if self.batt.type != "EVE":
                conf = self.inv.invParams()
                self.inv.reqOutputRange(conf["charge_v"] + 3, conf["charge_v"] + 1)

            # Record start of system revive
            with open(FLAG, "w") as f:
                f.write(self.status[0][16:])

            self.status = ["System Revive - Waiting to recover"]
            self.log("info", "actions-sr", "Entering system revive")
            self.negotiation_start = time.time()
            workingOnIt = True
            while self.running and workingOnIt:
                # Check status contactor state of each battery
                #          if not NON-RECOVERABLE or Nuisance
                if len(nuisanceBatt) == self.batt.num_batteries:
                    nuisanceBatt = []
                batts = []
                for i in range(len(self.batt.contactor)):
                    if (
                        self.batt.contactor[i] is not None
                        and self.batt.voltage[i] is not None
                        and self.batt.batt_id[i] is not None
                        and self.batt.faults[i] is not None
                    ):
                        batts.append(
                            (
                                i,
                                self.batt.contactor[i],
                                self.batt.voltage[i],
                                (
                                    (
                                        self.batt.faults[i]
                                        & self.batt.NON_RECOVERABLE_FAULTS
                                    )
                                    or self.batt.batt_id[i] in nuisanceBatt
                                ),
                            )
                        )
                if batts != [] and all([i[1] and not i[3] for i in batts]) and\
                   self.batt.getStatus() == []:
                    self.log(
                        "warning",
                        "action-sr",
                        "Batteries all reconnected"
                    )
                    self.status = ["System Revive - Done"]
                    workingOnIt = False
                    break
                # Check status if system has batteries to check
                if batts != []:
                    if self.batt.type == "EVE":
                        closed_contactor_count = sum([i for i in self.batt.contactor if i is not None])
                        # Reduce charge current when fewer batteries are on the bus
                        max_charge_current = [25, 25, 50, 75, 100, 125, 150, 165, 165][
                            closed_contactor_count
                        ]
                        self.inv.reqChargeCurrent(max_charge_current)
                        # Shut-off output (SL and shutdown_V) when battery count is below 4
                        if closed_contactor_count < 4 and self.init_time < time.time():
                            self.inv.reqOperatingRange(shut_v=55, restart_v=57, low_batt=56)
                            self.inv.reqOutputRange(sl_off=55, sl_on=56)
                    else:
                        # Order them by open contactors, by voltage, and leaving nuisance batts in the middle
                        #     Lowest voltage battery with open contactor is in front
                        #     Bus Voltage holder is in the back (closed contactor with highest Voltage)
                        #           assuming contactor is closed
                        orderByVoltage = sorted(
                            batts,
                            key=lambda x: x[2]
                            + ((80 if x[3] else 100) if x[1] else (79 if x[3] else 0)),
                        )
                        self.log(
                            "debug",
                            "action-sr",
                            "Evaluating batteries: " + str(orderByVoltage),
                        )
                        self.inv.reqChargeVoltage(
                            (
                                max(orderByVoltage[0][2], self.inv.RECOVERY_CHARGE_VOLTAGE) if \
                                    self.batt.type == "Flux" or not any([i == 128 for i in self.batt.recovery]) else \
                                (self.inv.RECOVERY_CHARGE_VOLTAGE - 0.5)
                            )
                        )
                        lowest = orderByVoltage[0][0]
                        # bus voltage is the highest voltage if contactor is closed,
                        # otherwise all contactors are open so bus could be the lowest pack
                        bus = (
                            orderByVoltage[-1][2]
                            if orderByVoltage[-1][1]
                            else orderByVoltage[0][2]
                        )
                        self.log("debug", "action-sr", "Bus voltage evaluation: "+ str(bus))
                        attempts = 0
                        # Only intervene if disconnected battery is not the leader and is below the bus
                        if (
                            self.batt.type == "Beam" and 
                            orderByVoltage[0][2] <= bus and 
                            self.batt.lf_role[lowest] != "Leader" and
                            self.negotiation_start + 300 < time.time()
                        ):
                            # RECORD CHANGING BATTERY HIERARCHY
                            self.status = ["System Revive - Renegotiating Leader"]
                            with open(FLAG, 'w') as fh:
                                fh.write("Beam renegotiation")
                            # stop sending busV messages
                            self.batt.sstop = True
                            # waiting for lowest battery to become leader (retry 4 times)
                            for i in range(4):
                                self.batt.sendBusVoltage(self.batt.voltage[lowest])
                                if renegotiate(self.batt.encourage, self.batt.voltage, lowest):
                                    break
                            else:
                                # RECORD BRINGING DOWN INTERFACE
                                self.status = ["System Revive - Resetting Interface"]
                                self.ifdown_end = time.time() + 0x40000 # 72 hour counter roll-over
                                self.log(
                                    "error",
                                    "action-sr",
                                    "Beam stuck battery, exp: " + str(self.ifdown_end)
                                )
                                with open(stuckFLAG, 'w') as fh:
                                    fh.write(str(self.ifdown_end))

                                fault_state = self.batt.recovery + self.batt.lf_role + self.batt.faults
                                while time.time() < self.ifdown_end:
                                    self.status = ["System Revive - Interface Reset %d:%02d" % (
                                        (time.time()-self.ifdown_end)/3600,
                                        (self.ifdown_end-time.time())%3600/60)]
                                    time.sleep(60)
                                    if fault_state != self.batt.recovery + self.batt.lf_role + self.batt.faults:
                                        self.batt.sendBusVoltage(self.batt.voltage[lowest])
                                        if renegotiate(self.batt.encourage, self.batt.voltage, lowest):
                                            break
                                        
                                os.remove(stuckFLAG)
                                time.sleep(2)
                                self.ifdown_end = None
                                for i in range(4):
                                    self.batt.sendBusVoltage(self.batt.voltage[lowest])
                                    if renegotiate(self.batt.encourage, self.batt.voltage, lowest):
                                        break
                                else:
                                    if self.batt.batt_id[lowest] not in nuisanceBatt:
                                        nuisanceBatt.append(self.batt.batt_id[lowest])
                                    with open(nuisFLAG, "w") as f:
                                        f.write(str(nuisanceBatt))
                                        self.log(
                                            "debug",
                                            "action-sr",
                                            "Assessing - nuisance batteries: " + str(nuisanceBatt)
                                        )
                                self.batt.sstop = False
                            self.negotiation_start = time.time()
                            self.log("debug", "action-sr", "Starting Batteries to send BusV")
                            self.batt.start()
                        elif (
                            self.batt.type == "Beam" and 
                            orderByVoltage[0][2] <= bus and 
                            self.batt.lf_role[lowest] == "Leader"
                        ):
                            if self.batt.sstop:
                                self.log("debug", "action-sr", "Starting Batteries to send BusV")
                                self.batt.start()

                        # Only intervene if disconnected battery is lower than the bus
                        elif self.batt.type == "Flux":
                            if bus - 0.5 < orderByVoltage[0][2] <= bus:
                                attempts = 0
                                while attempts < 3:
                                    self.batt.recover(self.batt.batt_id[lowest])
                                    time.sleep(3)
                                    if self.batt.contactor[lowest]:
                                        self.log("debug", "action-sr",
                                                 "Successfully closed contactor on battery "
                                                 + self.batt.batt_id[lowest])
                                        break
                                    else:
                                        self.batt.recover(self.batt.batt_id[lowest], True)
                                        time.sleep(2)
                                        attempts += 1
                                else:
                                    nuisanceBatt.append(self.batt.batt_id[lowest])
                                    with open(nuisFLAG, "w") as f:
                                        f.write(str(nuisanceBatt))
                                        self.log(
                                            "debug",
                                            "action-sr",
                                            "Adding -- nuisance battery: " + str(nuisanceBatt)
                                        )
                            else:
                                #self.batt.recover(0, True)
                                time.sleep(2)
            # Recovery complete
            if self.status == ["System Revive - Done"]:
                self.inv.reqConfigure()
                restart_recover = False
                # Assure after low voltage charge above tracker conditioning
                while any([v<(self.LOW_VOLTAGE + (self.CLEAR_VOLTAGE - self.LOW_VOLTAGE)/4)
                           for v in self.batt.min_voltage if v is not None]):
                    self.status = ["System Revive - Critical charging"]
                    # exit loop if any contactor opens
                    if any([c == 0 for c in self.batt.contactor if c is not None]):
                        restart_recover = True
                        break
                    time.sleep(3)
                if not restart_recover:
                    self.status = ["System Revive - Cleaning Up"]
                    if os.path.isfile(trkFLAG):
                        self.trk.normal()
                        time.sleep(3)
                        if (self.trk.service is not None and self.trk.service.lower() == "on"):
                            self.trk.normal()
                        while (self.trk.servo is None or "idle" not in self.trk.servo.lower()):
                            time.sleep(4)
                            self.status = ['System Revive - Trk: '+("" if self.trk.servo is None else self.trk.servo)]
                        if round(self.trk.trk_az) != round(self.trk.tgt_az):
                            self.trk.normal()
                        self.log('warning', 'action-sr', 'Tracker Conditioning - clear')
                        os.remove(trkFLAG)
                    if os.path.isfile(FLAG):
                        os.remove(FLAG)
                    self.status = []
                self.running = False
        except Exception:
            self.log("critical", "action-sr", "Thread crashed see /var/log/EVARC.log")
            #print(traceback.format_exc())
            with open("/var/log/EVARC.log", "a+") as f:
                f.write(str(time.time()) + "\n")
                f.write(traceback.format_exc() + "\n")
            self.running = False

def renegotiate(encourage, volts, lowest):
    lead = encourage()
    if lead == lowest or (
       volts[lead] < volts[lowest] + 0.5):
        return True
    return False

def main():
    import io
    from unittest.mock import patch

    class batt:
        def __init__(self):
            self.type = "EVE"
            self.iface = "can0"
            self.stop = False
            self.sstop = False
            self.voltage = [52.0, 52.0, 52.0, 48.0, 52.0, 52.0, 51.0, 51.8]
            self.min_voltage = [3.2, 3.2, 3.2, 3.0, 3.2, 3.2, 3.2, 3.2]
            self.faults = [0, 0, 0, 3, 0, 0, 0, 0]
            self.contactor = [1, 1, 1, 0, 1, 1, 1, 1]
            self.lf_role = [
                "follower",
                "leader",
                "AttemptFollow",
                "Follower",
            ]
            self.batt_id = [0, 1, 2, 3, 4, 5, 6, 7]
            self.current = [0.4, 0.8, -0.2, 0.3, 0]
            self.min_temp = [14, 15, 15, 14, 15, 15, 15, 15]
            self.NON_RECOVERABLE_FAULTS = 1
            self._status = []
            self._encourage_count = 0
            self._encourage_calls = []
            self._recover_calls = set()

        def getStatus(self, i=[]):
            return self._status

        def encourage(self):
            # [([voltage], [contactor], [lf_role], leader),]
            results = [
                ([53, 53, 53, 51], [0, 0, 0, 1], ["Follower", "Follower", "Follower", "Leader"], 3),
                ([52, 52, 52, 51], [0, 0, 0, 1], ["Follower", "Follower", "Follower", "Leader"], 3),
                ([55, 53, 57, 51], [0, 0, 1, 0], ["Follower", "Follower", "Follower", "Leader"], 2),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [0, 1, 0, 0], ["AttemptFollow", "Leader", "AttemptFollow", "AttemptFollow"], 2),
                ([55, 57, 57, 51], [0, 0, 1, 0], ["AttemptFollow", "AttemptFollow", "Leader", "AttemptFollow"], 1),
                ([55, 57, 57, 51], [1, 0, 0, 1], ["Leader", "AttemptFollow", "AttemptFollow", "AttemptFollow"], 3)
            ]
            self.voltage = results[self._encourage_count][0]
            self.contactor = results[self._encourage_count][1]
            self.lf_role = results[self._encourage_count][2]
            self._encourage_count += 1
            print(self._encourage_count)
            return results[self._encourage_count-1][3]

        def recover(self, bat=0, recovery=False):
            self._recover_calls.add((bat, recovery))
            if bat == 0: 
                self.contactor = [(0 if recovery else 1)] * len(b.voltage)
                self._result = False
            else:
                for i in range(len(self.batt_id)):
                    if self.batt_id[i] == bat:
                        self.contactor[i] = (0 if recovery else 1)
                        self._result = True

        def run(self):
            pass

        def start(self):
            pass

    class inv:
        def __init__(self):
            self.MAX_CHARGE_VOLTAGE = 55.0
            self.RECOVERY_CHARGE_VOLTAGE = 50.0
            self.t_output = True
            self.t_charge = 55.0
            self.t_current = 180
            self._current_calls = set()

        def invParams(self):
            return {"charge_v": 80}

        def reqChargeVoltage(self, v: float = 57.0):
            self.t_charge = v

        def reqOutputRange(self, sl_off: float = 51, sl_on: float = 53):
            self.t_output = sl_off == 51 and sl_on == 53

        def reqChargeCurrent(self, current):
            self._current_calls.add(current)
            self.t_current = current

        def reqConfigure(self):
            self.reqChargeVoltage()

    class trk:
        def __init__(self):
            self.service = "off"

        def safe(self):
            self.service = "on"

        def normal(self):
            self.service = "off"

    class wtr:
        def summer(self):
            return True

    def log(level, device, mesg):
        #print(mesg)
        pass

    config = {"lowVoltageWarning": {"EVE": 3.002, "Flux": 3.028, "Beam": 3.010}, 
              "lowVoltageClear": {"EVE": 3.302, "Flux": 3.328, "Beam": 3.310}}

    # Setup mocks
    fake_time = [1000000]

    def advance_time(seconds):
        fake_time[0] += seconds
        return fake_time[0]

    fake_files = {}

    def open_side_effect(file, mode="r", *args, **kwargs):
        nonlocal fake_files
        if "w" in mode:
            fake_files[file] = io.StringIO()
            fake_files[file].close = lambda: True
            return fake_files[file]
        if "a" in mode:
            if file not in fake_files:
                fake_files[file] = io.StringIO()
            return fake_files[file]
        elif "r" in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    sys_vals = []

    def sys_call(val):
        nonlocal sys_vals
        sys_vals.append(val)

    with patch("os.path.isfile", side_effect=lambda path: path in fake_files),\
         patch("builtins.open", side_effect=open_side_effect),\
         patch("os.remove", side_effect=lambda path: fake_files.pop(path)),\
         patch("os.path.exists", side_effect=lambda path: path in fake_files),\
         patch("time.time", side_effect=lambda: advance_time(1)),\
         patch("time.sleep", side_effect=lambda x: advance_time(x)),\
         patch("os.system", side_effect=sys_call):

        # Create objects
        b = batt()
        i = inv()
        t = trk()
        w = wtr()

        act = SystemRevive(b, i, t, w, log, config)

        ### A) TEST EVE
        # Initial check: nothing abnormal
        act.check()
        assert act.status == [], "Expected status == [], got " + str(act.status)

        # Stimulate check: file
        fh = open_side_effect(FLAG, "w")
        fh.write("999999")

        act.check()
        assert act.status == [
            "System Revive - 999999"
        ], 'Expected "999999", got ' + str(act.status)
        os.remove(FLAG)

        act.check()
        assert act.status == [], "Expected status == [], got " + str(act.status)

        # Stimulate check: open contactor
        b.contactor[1] = 0
        b._status = ["Low Battery Conditioning"]

        act.check()
        assert act.status == [
            "System Revive - Low Battery Conditioning"
        ], "Expected 'Low Battery', got " + str(act.status)

        act.do()
        assert act.status == [
            "System Revive - Low Battery Conditioning"
        ], "Expected 'Low Battery', got " + str(act.status)
        assert act.running
        assert t.service, "Expected Tracker in service mode, got " + (
            "Service" if t.service else "Normal"
        )
        t.trk_az = 180.321
        t.servo = "is_idle"
        assert os.path.isfile(FLAG), "Expected FLAG presance"
        assert act.status == [
            "System Revive - Waiting to recover"
        ], "Expected 'Waiting', got " + str(act.status)
        assert i.t_output, "Expected inverter to be on, got " + str(i.t_output)
        b.faults[3] = 0
        b.contactor[0] = 0
        b.contactor[2] = 0
        b.contactor[4] = 0
        assert i.t_charge == 55, "Expected inverter 55, got "+str(i.t_charge)
        assert act.running
        while i.t_current == 165:
            pass
        b.contactor[5] = 0
        while i.t_current == 75:
            pass
        b.contactor[7] = 0
        while i.t_current == 50:
            pass
        b.contactor = [0] * 8
        [print("\r", end="") for x in range(85)]  # stall
        b.contactor = [1] * 8
        while i.t_current == 25:
            pass

        assert act.status == ["System Revive - Low Voltage"], "Expected status == ['Low Voltage'], got " + str(act.status)
        b.min_voltage = [3.4]*8
        while act.running:
            pass

        assert act.status == [], "Expected status == [], got " + str(act.status)
        assert not act.running
        assert not os.path.isfile(FLAG)
        
        assert i._current_calls ==  { 75, 50, 25, 165}, \
                "Expecting {75, 50, 25, 165}, got "+str(i._current_calls[-6:])

        ### B) TEST FLUX
        ## B1) Cold Recovery
        b.type = "Flux"
        b.contactor = [1, 1, 1, 1]
        b.voltage = [52, 52, 52, 52]
        b.faults = [0, 0, 0, 0]
        b.min_temp = [-1, 1, 1, 1]
        b.batt_id = [1, 2, 3, 4]

        # Initial check: nothing abnormal
        b._status = []
        act.check()
        assert act.status == [], "Expected status == [], got " + str(act.status)

        # Stimulate check: open contactor
        b.contactor[1] = 0
        b._status = ["Low Battery Conditioning"]

        act.check()
        assert act.status == [
            "System Revive - Low Battery Conditioning"
        ], "Expected 'Low Battery', got " + str(act.status)

        act.do()
        [print("\r", end="") for x in range(35)]  # stall
        assert not act.running
        assert act.status == []

        assert b._result

        ## B2) Other Recovery
        b.type = "Flux"
        b.contactor = [1, 1, 1, 1]
        b.voltage = [48, 49, 52, 52]
        b.min_temp = [10, 10, 10, 10]
        b._result = False

        # Initial check: nothing abnormal
        b._status = []
        act.check()
        assert act.status == [], "Expected status == [], got " + str(act.status)

        # Stimulate check: open contactor
        b.contactor[0] = 0
        b.contactor[1] = 0
        b._status = ["Low Battery Conditioning"]

        act.check()
        [print("\r", end="") for x in range(35)]  # stall
        assert act.status == [
            "System Revive - Low Battery Conditioning"
        ], "Expected 'Low Battery', got " + str(act.status)

        act.do()
        assert act.status == [
            "System Revive - Waiting to recover"
        ], "Expected 'Waiting', got " + str(act.status)
        [print("\r", end="") for x in range(35)]  # stall
        assert not b._result
        while b.contactor[0] != 1:
            pass
        b.voltage[0] = 49
        while b.contactor[1] != 1:
            pass
        b.voltage[0] = 50
        b.voltage[1] = 50
        while b.contactor[2] != 0:
            pass
        b.voltage[0] = 52
        b.voltage[1] = 52
        while b.contactor[2] != 1:
            pass
        while b.contactor[3] != 1:
            pass
        [print("\r", end="") for x in range(35)]  # stall
        assert b._result
        assert t.service == "off"
        assert i.t_charge == 57
        assert not act.running

        assert b._recover_calls == {(0, True), (1, False), (2, False), (3, False), (4, False)}, \
                "Expecting {(0, True), (1, False), (2, False), ... (4, False)}, got "+str(b._recover_calls)

        ### C) TEST BEAM
        ## C1) No renegotiation
        b.type = "Beam"
        b._status = []
        b.contactor = [1, 1, 1, 1]
        b.voltage = [51, 52, 52, 53]
        b.lf_role = ["Leader", "Follower", "Follower", "Follower"]
        b.faults = [0, 0, 0, 0]

        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        b.contactor[0] = 0
        b._status = [" "]

        act.check()
        assert "System Revive" in act.status[0], "Expected active status, got "+str(act.status)

        act.do()

        assert "Waiting" in act.status[0], "Expected waiting, got "+str(act.status)
        assert b._encourage_count == 0, "Didn't expect encouragement, got "+str(b._encourage_count)
        b.contactor[3] = 0

        assert "Waiting" in act.status[0], "Expected waiting, got "+str(act.status)
        assert b._encourage_count == 0, "Didn't expect encouragement, got "+str(b._encourage_count)

        b.voltage = [ 53, 53, 53, 51]

        time.sleep(270)
        while b._encourage_count == 0:
            pass
        [print("\r", end="") for x in range(35)]  # stall
        assert b._encourage_count > 0, "Expect encouragement, got "+str(b._encourage_count)
        assert b.contactor == [0,0,0,1], "One battery"
        [print("\r", end="") for x in range(35)]  # stall
        assert i.t_charge == 53.3, "Expected reduced charge voltage = 53, got "+str(i.t_charge)
        b.contactor = [1,0,0,1]
        b.contactor = [1,1,0,1]
        b.contactor = [1,1,1,1]

        [print("\r", end="") for x in range(35)]  # stall
        assert b._encourage_count == 1, "Expected exactly 2 encourages, got "+str(b._encourage_count)
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running

        ## C2) Leadership renegotiation (staggard start)
        b._status = []
        b.contactor = [1, 1, 1, 1]
        b.voltage = [52, 52, 52, 51]
        b.lf_role = ["Leader", "Follower", "Follower", "Follower"]
        b.faults = [0, 0, 0, 0]

        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        b._status = [" "]
        b.contactor = [0, 1, 1, 0]

        act.check()
        assert "System Revive" in act.status[0], "Expected active status, got "+str(act.status)

        act.do()

        #assert "Waiting" in act.status[0], "Expected waiting, got "+str(act.status)
        assert "Renegotiating" in act.status[0], "Expected renegotiating, got "+str(act.status)
        [print("\r", end="") for x in range(35)]  # stall
        time.sleep(270)
        while b._encourage_count == 1:
            pass

        assert b._encourage_count == 2, "Expect encouragement, got "+str(b._encourage_count)

        while i.t_charge == 51.3:
            pass
        assert i.t_charge == 52.3, "Expected reduced charge voltage = 52, got "+str(i.t_charge)
        b.contactor = [1,1,1,1]
        while act.running:
            pass

        assert i.t_charge == 57, "Expected reduced charge voltage = 57, got "+str(i.t_charge)
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running
        
        ## C3) Leadership renegotiation (stuck AttemptFollow)
        b.contactor = [1, 1, 1, 1]
        b.voltage = [52, 52, 52, 51]
        b.lf_role = ["Leader", "Follower", "Follower", "Follower"]
        b.faults = [0, 0, 0, 0]
        b._status = []

        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        b._status = [" "]
        b.contactor = [0, 1, 1, 0]

        act.check()
        assert "System Revive" in act.status[0], "Expected active status, got "+str(act.status)

        act.do()

        assert "Interface Reset" in act.status[0], "Expected Interface, got "+str(act.status)
        [print("\r", end="") for x in range(35)]  # stall
        #time.sleep(280)
        time.sleep(0x40000)
        while b._encourage_count < 11:
            pass
        assert len(sys_vals) > 0
        b.contactor = [1, 1, 1, 1]
        while act.running:
            pass
        assert nuisFLAG in fake_files, "Expected excluded battery"

        print(act.status)
        assert i.t_charge == 57, "Expected reduced charge voltage = 57, got "+str(i.t_charge)
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running

        print("✅ Pass: System Revive sequence completed")

if __name__ == "__main__":
    main()
