import os
import time
import datetime
import threading
import traceback

FLAG = '/home/service/ocFault'
MAX_LINE_CURRENT = 0
TIMEOUT = 0

class Overcurrent:
    def __init__(self, inv, log, config):
        global MAX_LINE_CURRENT, TIMEOUT
        MAX_LINE_CURRENT = config['overcurrentMaxAmp']
        TIMEOUT = config['overcurrentDownSec']
        # self.batt = batt        # battery object
        self.inv = inv          # inverter object
        # self.trk = trk          # solar tracker object
        # self.wtr = wtr          # weather object
        # self.db = db            # database logging
        self.log = log          # error logging
        self.runner = None      # thread of def runner
        self.running = False    # escape boolean
        self.start = 0          # timestamp for start of fault
        self.status = []        # lines of status output
        self.action_mask = 16   # mask indicates changes needed for corretion
        self.DEBUG = False      # testing boolean

    # Method: check
    # Purpose: Evaluates if task is necessary
    # Input Arguments: None
    # Return Value: True if task is required for correction;
    #               False if system operation is good
    def check(self):
        if not self.running:
            if os.path.exists(FLAG):
                with open(FLAG, 'r') as f:
                    self.start = float(f.read())
                    self.status = ["High current detected"]
            elif ((self.inv.output_A_L1 is not None and
                 self.inv.output_A_L1 >= MAX_LINE_CURRENT) or
                (self.inv.output_A_L2 is not None and
                 self.inv.output_A_L2 >= MAX_LINE_CURRENT)):
                self.status = ["High current detected"]
            else:
                self.status = []

    # Method: do
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    #          If task takes longer than a period, then fix should start a thread
    #          running a def runner if the thread is not already running
    # Input Arguments: None
    # Return Value: None
    def do(self):
        if not self.running:
            self.runner = threading.Thread(target=self.run, daemon=True)
            self.runner.start()

    # Method: run
    # Purpose: Perform steps to correct unwanted behavior or add desired behavior
    # Input Arguments: None
    # Return Value: None
    def run(self):
        self.running = True
        try:
            # Loop gives the current a minute to clear 
            self.inv.forceOutputOff()
            if self.start == 0:
                self.start = time.time()
                if not os.path.exists(FLAG):
                    with open(FLAG, 'w') as f:
                        f.write(str(self.start))
                workingOnIt = True
                while self.running and workingOnIt and self.start != 0:
                    time.sleep(0.1)
                    if time.time() > self.start + 10 and \
                       not (self.inv.gen_relay_status & 1):
                        self.start = time.time()
                        workingOnIt = False
                    # avoid nuisance shutdowns
                    elif (self.inv.output_A_L1 < MAX_LINE_CURRENT and
                       self.inv.output_A_L2 < MAX_LINE_CURRENT and
                       time.time() < self.start + 55):
                        self.inv.setOutputRange()
                        os.remove(FLAG)
                        self.start = 0
                        self.running = False
                        self.status = []
                        return

            # Wait with output off for TIMEOUT minutes
            if time.time() < self.start + TIMEOUT :
                dt = datetime.datetime.fromtimestamp(self.start)
                self.status = ["High current - output off: %d:%02d" % (dt.hour, dt.minute)]
                self.log('error', 'action-oc', 'High current detected, L1= %sA, L2= %sA'
                      % (self.inv.output_A_L1, self.inv.output_A_L2))
                if not os.path.exists(FLAG):
                    with open(FLAG, 'w') as f:
                        f.write(str(self.start))
                workingOnIt = True
                while self.running and workingOnIt:
                    time.sleep(0.1)
                    if time.time() > self.start + TIMEOUT:
                        workingOnIt = False
                        self.status = []

            # cleanup after clear
            if self.status == [] or time.time() > self.start + TIMEOUT:
                self.status = ["High current - cleaning up"]
                self.inv.setOutputRange()
                os.remove(FLAG)
                self.start = 0
                self.status = []
                self.running = False

        except Exception:
            self.log('critical', 'action-oc', 'Thread crashed see /var/log/EVARC.log')
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time())+"\n")
                f.write(traceback.format_exc()+"\n")
            self.running = False
            

def main():
    import io
    from unittest.mock import patch

    # Dummy inverter and logger classes
    class DummyInverter:
        def __init__(self):
            self.output_A_L1 = 10  # Normal current
            self.output_A_L2 = 10
            self.output_off = False
            self.range_reset = False
            self.gen_relay_status = 273
    
        def forceOutputOff(self):
            self.output_off = True
            self.gen_relay_status = 272
            self.range_reset = True
    
        def setOutputRange(self):
            self.range_reset = False
            self.output_off = False

    class DummyLogger:
        def __call__(self, level, source, msg):
            #print(f"[{level}] {source}: {msg}")
            pass

    config = {
        'overcurrentMaxAmp': 28,
        'overcurrentDownSec': 600
    }

    fake_time = [1000000]

    def advance_time(seconds):
        fake_time[0] += seconds
        return fake_time[0]

    # Setup mocks
    fake_files = {}

    def open_side_effect(file, mode='r', *args, **kwargs):
        nonlocal fake_files
        if 'w' in mode:
            fake_files[file] = io.StringIO()
            return fake_files[file]
        elif 'r' in mode:
            if file in fake_files:
                fake_files[file].seek(0)
                return fake_files[file]
            raise FileNotFoundError
        else:
            raise ValueError("Unsupported mode")

    with patch("os.path.isfile", side_effect=lambda path: path in fake_files), \
         patch("builtins.open", side_effect=open_side_effect), \
         patch("os.remove", side_effect=lambda path: fake_files.pop(path)), \
         patch("os.path.exists", side_effect=lambda path: path in fake_files), \
         patch('time.time', side_effect=lambda: advance_time(1)), \
         patch('time.sleep', side_effect=lambda x: advance_time(x)):

        # Create objects
        inv = DummyInverter()  # Initially normal current
        log = DummyLogger()
        act = Overcurrent(inv, log, config)

        # Initial check: nothing abnormal
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)
        assert not act.running
        
        # Stimulate check: file
        fh = open_side_effect(FLAG, 'w')
        fh.write("999999")
        act.check()
        assert FLAG in fake_files, "Assure the file has been fake created"
        assert act.status == ["High current detected"]
        assert act.start == 999999, "Expected start seconds to be set from file"
        os.remove(FLAG)
        act.check()
        act.check()
        assert act.status == [], "Expected status == [], got "+str(act.status)

        # Stimulate check: Overcurrent
        inv.output_A_L1 = 30  # Set overcurrent condition
        act = Overcurrent(inv, log, config)
        act.check()
        assert act.status, "High current detected"

        # Run the action with mocked time
        act.do()
        assert act.runner.is_alive()
        assert act.start >= 1000000, "Expected start to be set; found "+str(act.start)

        # Wait for 60 sec for action to shutOffOutput
        advance_time(61)

        # Verify Output is off and FLAG is set
        assert "High current - output off" in act.status[0], "Expecting ouptut off mesg, got "+act.status[0]
        assert inv.output_off, "Expected inverter output to be shut off"
        assert inv.range_reset, "Expected output range to be reset"
        
        assert FLAG in fake_files, "Expected fault flag to be created"

        # Wait for 10 min for overcurrent to timeout
        advance_time(9*60)
        while act.running:
            advance_time(10)

        # Verify return to normal operation
        assert not inv.output_off, "Expected inverter output to be normal"
        assert FLAG not in fake_files, "Expected fault flag to be cleared"
        assert not act.running, "Expected thread to have completed"
        print("✅ Pass: Overcurrent sequence completed")

if __name__ == "__main__":
    main()
 
