#!/usr/bin/python3
import os
import fcntl
import sys
import time
import datetime
import threading
import queue
import socket
import signal
import subprocess

import database
import battery
import inverter
import heater
import light
import tracker
import weather
import canListener
import logging

if not os.path.isfile("arcConfig.py"):
    # Create arcConfig.py if does not exists
    with open('init.py', 'r') as file:
        code = file.read()
        exec(code)
import arcConfig

import actions

__version__ = '1.2.37'

clients = [] 
heat_proc = [None]
def signal_handler(sig, frame):
    global clients

    # Shut off heaters
    os.system("sudo mx-dio-ctl -o 1 -s 1")
    os.system("sudo mx-dio-ctl -o 2 -s 1")
    os.system("sudo mx-dio-ctl -o 3 -s 1")

    # Close monitors
    for t in clients:
        t.sendall(b'\x04')
        t.close()

    # Clear excess logs
    os.system("tail -n80 /var/log/EVARC.log > /tmp/EVARC.log")
    os.system("mv /tmp/EVARC.log /var/log/EVARC.log")
    if heat_proc[0] is not None:
        heat_proc[0].terminate()
    exit()

signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

# verify only one process exists else exit
lockfile = "/run/lock/EVARC.lock"
lock = open(lockfile, 'w')
try:
    fcntl.lockf(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
except IOError:
    print("EVARC is already running; exiting!")
    sys.exit(-1)

with open("/run/EVARC.pid", 'w') as f:
    f.write(str(os.getpid()))

# check for arc configuration
try:
    import arcConfig
except ImportError:
    print("Missing ARC Configuration or file corrupted.")
    sys.exit(-1)

# initiate logger for errors
try:
    from cysystemd.journal import JournaldLogHandler
    log = logging.getLogger("EVARC")
    logging.basicConfig(format="%(message)s")
    log.addHandler(JournaldLogHandler())
except ImportError:
    log = logging.getLogger("EVARC")
    logging.basicConfig(filename="/var/log/EVARC.log",
                        format='%(asctime)s %(message)s')
#log.setLevel(logging.DEBUG)
log.setLevel(logging.NOTSET)

# initiate database for logging and errors
db = database.Database()
log.warning("|EVARC| Starting EVARC v"+__version__)
db.create("CREATE TABLE error (id INTEGER PRIMARY KEY, timestamp "
          + "CONVERT_TIMESTAMP, device TEXT, level TEXT, message TEXT);")

def error(level, device, msg):
    """Logging function"""
    db.put("INSERT INTO error (timestamp, device, level, message) VALUES ("\
          + "%s, '%s', '%s', '''%s''');" % (time.time(), device, level, msg))
    exec("log.%s(\"|%s| %s\")" % (level, device, msg))

def dberror(level, device, msg):
    """Logging function"""
    exec("log.%s(\"|%s| %s\")" % (level, device, msg))

# create a socket for client connections
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('127.0.0.1', 57896))

if arcConfig.config['dcfc_iface'] is not None:
    ifStatus = subprocess.check_output(['ip', 'link', 'show', arcConfig.config['dcfc_iface']]).decode('utf-8')
    while "state DOWN" in ifStatus:
        # bring up CAN bus
        subprocess.run(["sudo", "ip", "link", "set", arcConfig.config['dcfc_iface'], "up", "type", "can", "bitrate", "80000"])
        ifStatus = subprocess.check_output(['ip', 'link', 'show', arcConfig.config['dcfc_iface']]).decode('utf-8')
        if "state DOWN" in ifStatus:
            while True:
                result = subprocess.run(["sudo", "ip", "link", "set", arcConfig.config['dcfc_iface'], "down"])
                if result.returncode == 0:
                    break
                time.sleep(1)

# Additional Helper Functions
def watchDog(timeout, buscuit):
    global main_thread_loop
    count = 0
    while count < timeout:
        time.sleep(1)
        if buscuit[0]:
            count = 0
            buscuit[0] = False
        else:
            count += 1
    error("critical", "EVARC", "Mainloop hanged!")
    sys.exit(1)

def connectClients(sock, clients):
    while True:
        sock.listen(5)
        cli_sock, addr = sock.accept()
        clients.append(cli_sock)
        print("Client added")

class spinner:
    def __init__(self, color):
        self.default = color
        self.i = -1
        self.j = -1
        self.v = ['o', 'O', '\x00\xb0']
        self.c = ["\x1b[38;5;160m", "\x1b[38;5;166m", "\x1b[38;5;220m",
                  "\x1b[38;5;47m", "\x1b[38;5;33m", "\x1b[38;5;93m"]
    def __add__(self, other):
        self.i = (self.i + 1) % len(self.v)
        self.j = (self.j + 1) % len(self.c)
        return self

    def __str__(self):
        return self.c[self.j]+self.v[self.i]+self.default
        

conf = arcConfig.config
conf['can_queue'] = queue.Queue()
## INITIAL PREPARATION & GLOBAL VARIABLES
db.addLogCallback(dberror)
batt = battery.Battery(db, error, spinner("\x1b[38;5;160m"), conf)
inv = inverter.Inverter(db, error, spinner("\x1b[38;5;220m"), conf)
lit = light.Light(db, error)
trk = tracker.Tracker(db, error, spinner("\x1b[38;5;47m"), conf)
wtr = weather.Weather(error)
het = heater.Heater(batt, inv, trk, db, error, arcConfig.heating, heat_proc)
lis = canListener.Listener(inv,trk, lit, error, conf)

## Link Battery Config to Inverter
inv.setParamsCallback(lambda: batt.getInvParams(wtr.summer()))
batt.setBusVCallback(lambda: inv.batt_V )
lit.setInit(lambda: inv.isOutputOn() if conf['dcfc_id'] is None else None)
wtr.setInit(lambda: (trk.latitude, trk.longitude))

## ACTION ACTOR
act = actions.Actor(batt, inv, trk, wtr, db, error)

## OUTPUT OFFSETS
batt.rowoffset = 0
inv.rowoffset = batt.outputlen - 2
trk.rowoffset = batt.outputlen - 1
trk.columnoffset = inv.outputwidth + 1
wtr.rowoffset = batt.outputlen + trk.outputlen
wtr.columnoffset = inv.outputwidth + 1
lit.rowoffset = batt.outputlen + trk.outputlen + wtr.outputlen + 4
lit.columnoffset = inv.outputwidth + 2
act.rowoffset = batt.outputlen + inv.outputlen - 3

# COMPILE HEADER FROM SUBS (
INV_HEAD = [ i for i in inv.HEADER.split("\n")]
TRK_HEAD = [ i for i in trk.HEADER.split("\n")]
WTR_HEAD = [ i for i in wtr.HEADER.split("\n")]
LIT_HEAD = [ i for i in lit.HEADER.split("\n")]

HEADER = batt.HEADER + "\n" + ("-" * inv.outputwidth) + "+"\
       + ("-" * (129 - inv.outputwidth)) + "\n"
for i in range(len(TRK_HEAD)):
    HEADER += INV_HEAD[i+1] + (" " * (inv.outputwidth - len(INV_HEAD[i+1])))
    HEADER += "| " + TRK_HEAD[i] + "\n"
HEADER += INV_HEAD[len(TRK_HEAD)+1] + (" " * (inv.outputwidth - len(INV_HEAD[len(TRK_HEAD)+1]))) + "|\n" 
INV_OFFSET = len(TRK_HEAD) + 2
HEADER += INV_HEAD[INV_OFFSET] + (" " * (inv.outputwidth - len(INV_HEAD[INV_OFFSET])))
HEADER += "+" + ("-" * (129 - inv.outputwidth)) + "\n"
INV_OFFSET += 1
for i in range(len(WTR_HEAD)):
    HEADER += INV_HEAD[i+INV_OFFSET] + (" " * (inv.outputwidth - len(INV_HEAD[i+INV_OFFSET])))
    HEADER += "| " + WTR_HEAD[i] + "\n"
INV_OFFSET += len(WTR_HEAD) + 2
HEADER += INV_HEAD[INV_OFFSET-2] + (" " * (inv.outputwidth - len(INV_HEAD[INV_OFFSET-2]))) + "|\n"
HEADER += INV_HEAD[INV_OFFSET-1] + (" " * (inv.outputwidth - len(INV_HEAD[INV_OFFSET-1])))
HEADER += "+" + ("-" * (129 - inv.outputwidth)) + "\n"
for i in range(len(LIT_HEAD)):
    HEADER += INV_HEAD[i+INV_OFFSET] + (" " * (inv.outputwidth - len(INV_HEAD[i+INV_OFFSET])))
    HEADER += "| " + LIT_HEAD[i] + "\n"
HEADER += INV_HEAD[-1] + (" " * (inv.outputwidth - len(INV_HEAD[-1]))) + "|\n"
HEADER += ("-" * inv.outputwidth) + "+" + ("-" * (129 - inv.outputwidth)) + "\n"
HEADER += act.HEADER + "                                                    \x1b[38;5;208mEVARC "
HEADER += str(arcConfig.config['arc'])
with open("bg.txt", 'w') as f:
    f.write(HEADER)

## start background services
db.start()
batt.start()
inv.start()
trk.start()
wtr.start()
act.start()
het.start()
lis.start()

spn = "\x1b[38;5;33m\x1b[%d;%df" % (batt.outputlen + inv.outputlen + 2, 105)

serv = threading.Thread(target=connectClients, args=(server_socket, clients,), daemon=True)
serv.start()

def main():
    treat = [ False ]
    wd = threading.Thread(target=watchDog, args=(30, treat), daemon=True)
    wd.start()
    while True:
        # PRINT DISPLAY
        for mod in [batt, inv, trk, wtr, lit, act]:
            disconnected = []
            out = mod.showData()
            for t in clients:
                try:
                    t.send(out.encode())
                except Exception:
                    disconnected.append(t)
            for t in disconnected:
                clients.remove(t)
                print("Client removed")
        for t in clients:
            t.send(bytes(spn+str(datetime.datetime.now()), 'utf-8'))

        # Check the threads
        if not db.runner.is_alive():
            with open("/var/log/EVARC.log", 'a+') as f:
                f.write(str(time.time()) + " database thread crashed...restarting thread\n")
            db.runner.join()
            db.runner.start()
        if not trk.runner.is_alive():
            error("error", 'EVARC',
                  "Tracker is not running...restarting thread")
            trk.runner.join()
            trk.start()
        if not inv.runner.is_alive() or (inv.actor is not None and not inv.actor.is_alive()):
            error("error", 'EVARC',
                  "Inverter is not running...restarting thread")
            inv.stop = True
            inv.runner.join()
            inv.actor.join()
            inv.stop = False
            inv.start()
        if not batt.runner.is_alive():
            error("error", 'EVARC',
                  "Battery is not running...restarting thread")
            batt.runner.join()
            batt.start()
        if not wtr.runner.is_alive():
            error("error", 'EVARC',
                  "Weather is not running...restarting thread")
            wtr.runner.join()
            wtr.start()

        if not het.runner.is_alive():
            error("error", 'EVARC',
                  "Heater is not running...restarting thread")
            het.runner.join()
            het.start()

        if not act.runner.is_alive():
            error("error", 'EVARC',
                  "Actions is not running...restarting thread")
            act.runner.join()
            act.start()

        if conf['dcfc_iface'] is not None and not lis.runner.is_alive():
            error("error", 'EVARC',
                  "Listener is not running...restarting thread")
            lis.runner.join()
            lis.start()

        time.sleep(0.4)
        # feed the watchdog
        treat[0] = True

if __name__ == "__main__":
    main()

