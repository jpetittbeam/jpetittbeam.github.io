import logging as l0gging
from cysystemd.journal import JournaldLogHandler
import time

class Logger():
    def __init__(self, db):
        self.log = l0gging.getLogger('EVARC')
        self.log.addHandler(JournaldLogHandler())
        self.log.setLevel(l0gging.DEBUG)
        self.db = db
        db.create("CREATE TABLE error (id integer primary key, timestamp"\
            + " convert_timestamp, device TEXT, level TEXT, message TEXT);")
        self.put_str = "INSERT INTO error (timestamp, device, level,"\
            + " message) VALUES (%s, '%s', '%s', '%s')"


    def debug(self, device, msg=None):
        if device not in ['inverter','battery','tracker','database','light']:
            if msg is not None:
                self.log.debug(device, msg)
            else:
                self.log.debug(device)
        else:
            message = "|%s| %s" % (device, msg)
            self.log.debug(message)
            self.db.put(self.put_str % (time.time(), device, 'DEBUG', msg))

    def info(self, device, msg=None):
        if device not in ['inverter','battery','tracker','database','light']:
            if msg is not None:
                self.log.debug(device, msg)
            else:
                self.log.debug(device)
        else:
            message = "|%s| %s" % (device, msg)
            self.log.info(message)
            self.db.put(self.put_str % (time.time(), device, 'INFO', msg))

    def warning(self, device, msg=None):
        if device not in ['inverter','battery','tracker','database','light']:
            if msg is not None:
                self.log.debug(device, msg)
            else:
                self.log.debug(device)
        else:
            message = "|%s| %s" % (device, msg)
            self.log.warning(message)
            self.db.put(self.put_str % (time.time(), device, 'WARNING', msg))

    def error(self, device, msg=None):
        if device not in ['inverter','battery','tracker','database','light']:
            if msg is not None:
                self.log.debug(device, msg)
            else:
                self.log.debug(device)
        else:
            message = "|%s| %s" % (device, msg)
            self.log.error(message)
            self.db.put(self.put_str % (time.time(), device, 'ERROR', msg))

    def critical(self, device, msg=None):
        if device not in ['inverter','battery','tracker','database','light']:
            if msg is not None:
                self.log.debug(device, msg)
            else:
                self.log.debug(device)
        else:
            message = "|%s| %s" % (device, msg)
            self.log.critical(message)
            self.db.put(self.put_str % (time.time(), device, 'CRITICAL', msg))
