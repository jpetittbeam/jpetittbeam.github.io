#curl -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "CMD+srvmove2+u+20" http://192.168.127.2/button.form

#curl -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "$fn_LoginAdmin=1364" http://192.168.127.2/button.form

import os
from flask import Flask, render_template, redirect, url_for, request
import sqlite3
import ast
import requests
import re
import time
import sys
import socket
from subprocess import check_output

if os.path.exists('/var/lib/EVARC'):
    sys.path.insert(0, '/var/lib/EVARC/')
    import arcConfig
    config = arcConfig.config
    motors = arcConfig.system['motors']
else:
    sys.path.insert(0, check_output(['bash', '-c', 'ls -tc /home/*/*/arcConfig.py']).split(b'\n')[0][:-12])
    import arcConfig
    config = arcConfig.Config()
    motors = config.motors

if os.path.exists('/home/moxa'):
    trk_ip = "192.168.3.2"
    port = 8001
else:
    trk_ip = "192.168.127.2"
    port = 80

__version__ = '0.0.3'
app = Flask(__name__)
app.secret_key = "Cairocoders-Ednalan"

ip = check_output(['ip', 'addr', 'show', 'eth0']).split(b'\n')[2].split()[1]
HOST = ip[:str(ip).rfind('.')-1] + b'2'
user = "admin"
password = "1364"

data = {}
trailer = ""
mode = ""


@app.route('/getStatus', methods=['GET'])
def getStatus():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", 1234)) 

    sock.settimeout(5)
    data = {}
    while True:
        try:
            sock_data, addr = sock.recvfrom(1234)
            data_list = sock_data.decode().split(",")
            print(data_list)
            if len(data_list) == 1:
                continue
            key = data_list[1].upper()
            value = data_list[-1][:-1]

            if key in data:
                break

            data[key] = value 

        except socket.timeout:
            print("No data received in the last 5 seconds.")
            return "Failed"
        except Exception as e:
            print(e)
    dataHTML = '''
    <table id="status" class="table table-bordered" style="font-size: max(1vw, 8px)">
        <tr><th>%s</th><th>%s</th><th>%s</th><th>%s</th><th>%s</th><th>%s</th></tr>
        <tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>
        <tr><th>%s</th><th>%s</th><th>%s</th><th>%s</th><th>%s</th><th>%s</th></tr>
        <tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>
    </table>
        '''%("STATE", "SERVICE", "TRK_AZ", "SUN_AZ", "STOP", "LOCAL_CLEAN",
        data["STATE"], data["SERVICE"],data["TRK_AZ"],  data["SUN_AZ"], data["STOP"], data["LOCAL_CLEAN"], 
        "ERROR", "WARNING", "LONGITUDE", "LATITUDE", "AUX_STATE", "SUN_EL",
        data["ERROR"], data["WARNING"], data["LONGITUDE"], data["LATITUDE"], data["AUX_STATE"], data["SUN_EL"])
    return dataHTML
        



@app.route("/")
def index():
    return render_template("index.html");

@app.route("/deployMethod")
def deployMethod():
    return render_template("deployMethod.html");

@app.route("/stowMethod")
def stowMethod():
    return render_template("stowMethod.html");

@app.route("/tracker")
def tracker():
    time.sleep(.5)
    global tn, data, trailer, mode
    newTrailer = request.args.get('trailer')
    if newTrailer == None:
        if trailer == "":
            return render_template("index.html")
    else:
        trailer = request.args.get('trailer')
    print(trailer)
    newMode = request.args.get('mode')
    if newMode == None:
        if mode == "":
            return render_template("index.html")
    else:
        mode = request.args.get('mode')
    print(mode)
    if trailer == "0":
        if mode == "stow":
            template = "oldTrailerStow.html"
        elif mode == "deploy":
            template = "oldTrailerDeploy.html"
    elif trailer == "1":
        if mode == "stow":
            template = "newTrailerStow.html"
        elif mode == "deploy":
            template = "newTrailerDeploy.html"
    elif trailer == "2":
        if mode == "stow":
            template = "kitStow.html"
        elif mode == "deploy":
            template = "kitDeploy.html"

    return render_template(template, mode=mode, trailer=trailer, motors=motors)


@app.route('/sendCommand', methods=['GET', 'POST'])
def sendCommand():
    global trk_ip
    if request.method == 'GET': 
        command = request.args.get("command")
        if str(command) == "ReloadData":
            return redirect(url_for('tracker'))
        command = command[4:].replace("+", " ")
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(command.encode(), (trk_ip, 56))
        print("sent command %s"%command)
        sock.close()
    elif request.method == 'POST':
        command = request.form["command"]
        command = command[4:].replace("+", " ")
        print("---"+str(command)+"---")
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(command.encode(), (trk_ip, 56))
        sock.close()
        print("sent command %s"%command)
    return redirect(url_for('tracker'));


@app.route('/rebootSystem')
def rebootSystem():
    os.system("sudo reboot now")
    return redirect(url_for('tracker'))

# @app.route("/rebootTracker")
# def rebootTracker():
#     command = "reboot"
#     print("rebooting")
#     sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#     sock.sendto(command.encode(), ("192.168.127.2", 56))
#     sock.close()
#     time.sleep(60)
#     return redirect(url_for('index.html'))


if __name__ == "__main__":
    app.run(debug=True,host='0.0.0.0',port=port)
