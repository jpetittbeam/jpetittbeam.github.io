# ~/.bashrc: executed by bash(1) for non-login shells.
# see /usr/share/doc/bash/examples/startup-files (in the package bash-doc)
# for examples

# If not running interactively, don't do anything
case $- in
    *i*) ;;
      *) return;;
esac

# don't put duplicate lines or lines starting with space in the history.
# See bash(1) for more options
HISTCONTROL=ignoreboth

# append to the history file, don't overwrite it
shopt -s histappend

# for setting history length see HISTSIZE and HISTFILESIZE in bash(1)
HISTSIZE=1000
HISTFILESIZE=2000

# check the window size after each command and, if necessary,
# update the values of LINES and COLUMNS.
shopt -s checkwinsize

# If set, the pattern "**" used in a pathname expansion context will
# match all files and zero or more directories and subdirectories.
#shopt -s globstar

# make less more friendly for non-text input files, see lesspipe(1)
#[ -x /usr/bin/lesspipe ] && eval "$(SHELL=/bin/sh lesspipe)"

# set variable identifying the chroot you work in (used in the prompt below)
if [ -z "${debian_chroot:-}" ] && [ -r /etc/debian_chroot ]; then
    debian_chroot=$(cat /etc/debian_chroot)
fi

# set a fancy prompt (non-color, unless we know we "want" color)
case "$TERM" in
    xterm-color|*-256color) color_prompt=yes;;
esac

# uncomment for a colored prompt, if the terminal has the capability; turned
# off by default to not distract the user: the focus in a terminal window
# should be on the output of commands, not on the prompt
#force_color_prompt=yes

if [ -n "$force_color_prompt" ]; then
    if [ -x /usr/bin/tput ] && tput setaf 1 >&/dev/null; then
	# We have color support; assume it's compliant with Ecma-48
	# (ISO/IEC-6429). (Lack of such support is extremely rare, and such
	# a case would tend to support setf rather than setaf.)
	color_prompt=yes
    else
	color_prompt=
    fi
fi

if [ "$color_prompt" = yes ]; then
    PS1='${debian_chroot:+($debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
else
    PS1='${debian_chroot:+($debian_chroot)}\u@\h:\w\$ '
fi
unset color_prompt force_color_prompt

# If this is an xterm set the title to user@host:dir
case "$TERM" in
xterm*|rxvt*)
    PS1="\[\e]0;${debian_chroot:+($debian_chroot)}\u@\h: \w\a\]$PS1"
    ;;
*)
    ;;
esac

# enable color support of ls and also add handy aliases
if [ -x /usr/bin/dircolors ]; then
    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"
    alias ls='ls --color=auto'
    #alias dir='dir --color=auto'
    #alias vdir='vdir --color=auto'

    #alias grep='grep --color=auto'
    #alias fgrep='fgrep --color=auto'
    #alias egrep='egrep --color=auto'
fi

# colored GCC warnings and errors
#export GCC_COLORS='error=01;31:warning=01;35:note=01;36:caret=01;32:locus=01:quote=01'

# some more ls aliases
#alias ll='ls -l'
#alias la='ls -A'
#alias l='ls -CF'

# Alias definitions.
# You may want to put all your additions into a separate file like
# ~/.bash_aliases, instead of adding them here directly.
# See /usr/share/doc/bash-doc/examples in the bash-doc package.

if [ -f ~/.bash_aliases ]; then
    . ~/.bash_aliases
fi

# enable programmable completion features (you don't need to enable
# this, if it's already enabled in /etc/bash.bashrc and /etc/profile
# sources /etc/bash.bashrc).
if ! shopt -oq posix; then
  if [ -f /usr/share/bash-completion/bash_completion ]; then
    . /usr/share/bash-completion/bash_completion
  elif [ -f /etc/bash_completion ]; then
    . /etc/bash_completion
  fi
fi
help_msg="""
EVARC HELP MENU:
-------------------------------------------------------------------------
help    - print this message
monitor - view realtime system data (ctrl-c to quit)
status  - view the status of the software
stop    - stop the software from running
start   - start the software if not running
restart - restart the software
service-start  - enter manual mode
 force-on      - (service mode only) Force output on
 force-off     - (service mode only) Force output off
 serivce-done  - (service mode only) Exit manual mode; Go to normal operatoion
swinst  - install new EVARC software from /tmp
version - show installed package versions
logs    - review software errors (arrow keys to navigate and q to quit)
logging - live stream of errors (ctrl-C to quit)
tracker - connect to the tracker
"""

alias help="echo -e \"\${help_msg}\""
alias monitor='sudo /root/monitor'
alias status='sudo systemctl status EVARC; ls -l /var/lib/EVARC/main.py'
alias stop='sudo systemctl stop EVARC'
alias start='sudo systemctl start EVARC'
alias restart='sudo systemctl restart EVARC'
alias swinst='sudo /root/sw_update'
alias version='dpkg -l | grep evarc'
alias logs='sudo journalctl -xeu EVARC'
alias logging='sudo journalctl -n 80 -fu EVARC'
alias service-start='sudo touch /home/service/service'
alias service-done='if [ -f /home/service/service ]; then echo done | sudo tee /home/service/service; fi'
alias force-on='if [ -f /home/service/service ]; then echo on | sudo tee /home/service/service; fi'
alias force-off='if [ -f /home/service/service ]; then echo off | sudo tee /home/service/service; fi'
if [ -d /home/moxa ]; then
    alias tracker='/usr/bin/telnet 192.168.3.2'
else
    alias tracker='/usr/bin/telnet 192.168.127.2'
fi
